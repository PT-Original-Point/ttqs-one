from pathlib import Path
import json, hashlib

ROOT = Path(__file__).resolve().parent
raw_path = ROOT / 'ANTIGRAVITY_MANUSCRIPT_RAW_0140_R01.md'
out_path = ROOT / 'MANUSCRIPT_0140_R01.md'
text = raw_path.read_text(encoding='utf-8-sig')
changes=[]

def between(start, end, replacement, label):
    global text
    i=text.index(start)
    j=text.index(end, i+len(start))
    text=text[:i]+replacement.rstrip()+"\n\n"+text[j:]
    changes.append(label)

# Correct organization identity and remove false tier/size language.
text=text.replace('屏東縣原住民原點關懷協會','屏東縣原始點關懷協會')
text=text.replace('（總樣本 80 人次）','（80 筆合成「使用者－年度」紀錄；不代表 80 名跨年度不同真人）')
text=text.replace('80 人次','80 筆使用者－年度紀錄')
text=text.replace('11.37%','11.36%')
text=text.replace('4 分標準佐證範例','第19指標之範例佐證文字（不代表機構評分）')
text=text.replace('4 分範例文字','第19指標範例文字（來源索引標示於4分層級；不代表機構評分）')
text=text.replace('指標 19（訓練成果評估—加分範例）','指標 19（I19-E29：證照／就業成果要求）')
text=text.replace('訓後三個月就業率（%）','證照／就業成果的適用率（依該文件來源與定義）')
text=text.replace('顯著成長','增加')
text=text.replace('之接納程度呈現穩步上升','在這組合成數據中逐期增加；不作統計顯著性或真實趨勢判斷')
text=text.replace('符合個人資料保護法，外部公開版遮蔽敏感欄位','不代表已完成個資法遵審查；真實資料使用前須由有權責者確認授權、最小化與保護措施')
text=text.replace('經 SHA-256 雜湊去識別化，身分證字號與姓名均已轉換為代號','本示範資料沒有姓名、身分證字號或其他真實識別資料；真實資料應由有權責者在本機建立不透明替代碼，對照表分開限權保管')
text=text.replace('（雜湊之身分識別碼）','（由權責者產生並本機保管對照表的不透明替代碼；不得直接公開識別值）')
text=text.replace('以 SHA-256 演算法進行雜湊加密，保留金鑰於保密伺服器。','使用不透明替代碼；真實識別值與對照表僅在授權本機環境處理。文件 SHA-256 僅用於檔案完整性，不是個資匿名化方法。')
text=text.replace('跨班比對身分字號雜湊，確保同一年度一人僅計一次。','由受授權人員在本機以受控對照表去重；公開版只保留替代碼。')
text=text.replace('原始資料庫日誌檔案雜湊 (SHA-256)','原始匯出檔完整性 SHA-256（不是個資去識別碼）')
text=text.replace('去識別化代碼<br>(Hash Key)','不透明替代識別碼<br>(REAL key kept locally)')
text=text.replace('以身分證雜湊鍵為基礎之年度單一母體查核名冊','以授權本機對照表及不透明替代碼建立年度單一母體查核名冊')
text=text.replace('無重複身分鍵之年度總母體清冊','無重複替代碼之年度總母體清冊')
text=text.replace('是否已防重合併？','是否依核定口徑防重？')
text=text.replace('分數與小數點運算','比率與小數位運算')
text=text.replace('分數與小數點運算','比率與小數位運算')
text=text.replace('經查其僅登錄點名，未於課後執行結案。','本示範資料只顯示有一項必要工作未完成；沒有成因資料，不能推定原因。')
text=text.replace('2025 年此落差已完全消除，活躍講師全數達成 100% 任務結案。','2025 年示範列中，5 名活躍講師有 5 名完成兩項示範工作；這不證明真實改善或改善原因。')
text=text.replace('初年度有一名行政人員因未落實交接未操作，後續年度已完全納入常態標準作業程序。','示範列顯示 2023 年有 1 名行政角色未活躍；沒有原因或後續實際制度資料，不能歸因於交接或作業程序。')
text=text.replace('學員為各年度主要未活躍（Active = 0）來源','在本組合成列中，學員未活躍列數較多')
text=text.replace('主要集中於課後滿意度與學習評估漏填（例如 2025 年有 3 位學員完成前 2 項任務但未填評估）。','2025 年示範列有 3 名活躍學員完成前兩項任務但未完成第三項；該資料只描述示範表中的工作代碼，不代表真實漏填原因。')

between('## 第三部分：負向鄰近指標釐清與邊界界定（Negative-Neighbor Distinctions）','## 第四部分：年度訓練資訊系統盤點表（SAMPLE 示範案例）', '''## 第三部分：相近佐證項目的界線

本件只回答「預先界定的訓練任務，有多少應使用者留下至少一筆實質系統作業」及其分母、期間與差距。它不以系統功能或其他成果代替使用率。

| 對照項目 | 可回答的問題 | 不可代替本件的內容 |
| :--- | :--- | :--- |
| 0064 / I14-E05《資訊系統化程度及檢索速度》 | 文件如何分類、保存及查找；是否具檢索效率資料 | 檔案查找速度不能當成系統使用人數或活躍使用分子 |
| 0140 / I19-E30（本件） | 應使用者母體、實質操作、使用普及率及角色落差 | 不證明檢索效率、課程效果或機構實際上線系統 |
| 0139 / I19-E29《證照通過率與就業率分析》 | 證照／就業成果如何界定、追蹤及呈現 | 證照或就業結果不能當成系統使用人數或操作記錄 |

以上相鄰文件只用於防止錯件；跨文件數字須有共同且已核實的來源鍵，否則不得拼接。''','replace neighbor section')

between('## 第四部分：年度訓練資訊系統盤點表（SAMPLE 示範案例）','## 第五部分：納入分母與實質使用之判定規則與決策流程', '''## 第四部分：年度系統盤點表（SAMPLE 示範）

下表所有值均為合成示例，只示範填表方式；不表示協會曾有此系統或課程。真實填表前先核實系統是否存在、資料是否可合法取得，以及任務是否由有權責者確認。

| 盤點欄位 | SAMPLE 示範值 | 真實填報時核對事項 |
| :--- | :--- | :--- |
| 系統／模組 | SAMPLE-TIS-01；示範用虛構標籤 | 填實際名稱與版本；找不到系統或授權來源即標 UNKNOWN/HOLD |
| 盤點期間 | SAMPLE：2023、2024、2025 三個日曆年度 | 寫明起訖日；比較期採相同定義 |
| 納入活動 | SAMPLE-COURSE-01、SAMPLE-COURSE-02、SAMPLE-COURSE-03 | 只列經核實且需用系統處理的課程／任務，不臆造實際課程名稱 |
| 目標角色 | SAMPLE：訓練行政、講師、學員 | 依真實作業與權責核定；角色不是協會現況聲明 |
| 分母來源 | SAMPLE：本文件附錄 A 的 80 筆使用者－年度列 | 真實版須以授權名冊界定；未用系統者仍納入分母 |
| 活躍判準 | SAMPLE：至少完成一個實質任務代碼 | 只登入、開帳號或改密碼不算實質使用 |
| 來源定位 | SAMPLE-LOG-<年度>-<替代碼> | 這是示例索引，不是真實檔案路徑或系統日誌 |
| 個資處理 | 本示範不含真實識別資料 | 真實版須先核權限、目的、最小化、保存與對照表保管；本文件不宣稱已完成法遵審查 |
| 排除與例外 | SAMPLE：非應使用角色不納入；原因需登錄 | 只有按預先規則排除；理由與核准權限需由機構查實 |

本件不指定產品、雲端服務、伺服器、資料庫名稱或實際協會課程。''','replace inventory table')

between('## 第五部分：納入分母與實質使用之判定規則與決策流程','## 第六部分：SAMPLE 系統架構與角色-必要任務矩陣', '''## 第五部分：納入分母與實質使用的判定

### 5.1 口徑與公式

1. **期間**：示範採三個日曆年度分別統計。正式使用時先書面固定起訖日期；不同期間或不同任務定義不得直接比較。
2. **合格應使用者（分母）**：在該期間內，依經核實的作業規則被指派至少一項須由訓練資訊系統完成的任務之不重複人員。每人每年只計一次；沒有帳號、未登入或沒有操作者仍留在分母。非應使用角色只有按事前規則及可查核理由排除。
3. **活躍使用者（分子）**：合格應使用者在期間內至少完成一項實質任務，且有相符的操作紀錄。只有開帳號、登入頁面、改密碼或瀏覽頁面不計入。
4. **普及率**＝活躍使用者 ÷ 合格應使用者 × 100%。必列分子、分母、期間、角色與小數位。
5. **全任務完成者**：該角色在期間內完成 Blueprint 所列全部示範必要任務，並有對應紀錄。真實任務須由機構權責者先確認，不能由本示範代為核定。
6. **合格者完成率**＝全任務完成者 ÷ 合格應使用者 × 100%；**活躍者完成率**＝全任務完成者 ÷ 活躍使用者 × 100%。兩種分母要分開標示；分母為零時列 N/A 並說明。
7. **百分點變化**＝後期百分率 − 前期百分率。相對變化另用 `(後期−前期) ÷ 前期 × 100%`；前期為零則列 N/A。兩者不可混稱。
8. 百分率採四捨五入 half-up 至小數點後二位；彙總必須由附錄 A 列資料重算。

### 5.2 判定步驟

1. 是否有經核實、且在本期要求該角色使用系統的任務？否：按明確理由記排除；是：進下一步。
2. 此人是否已在本期計入？是：合併為同一使用者－年度列；否：列入分母。
3. 是否存在至少一筆符合定義的實質任務紀錄？否：`active=0`；是：`active=1`。
4. 是否完成該角色全部預先定義任務？否：`complete=0`；是：`complete=1`。
5. 母體、任務或來源未能查實：標 `UNKNOWN/HOLD`，不估填或排除。

### 5.3 判定示例（均為 SAMPLE）

| 情境 | 分母 | 活躍 | 全任務完成 | 判定理由 |
| :--- | :---: | :---: | :---: | :--- |
| 講師只登入看課表，沒有完成實質任務 | 1 | 0 | 0 | 登入不算實質作業 |
| 同一學員在同年度兩個班期都需用系統 | 1 | 依交易列 | 依任務 | 同一人每年去重一次；跨班任務按事前規則彙整 |
| 被指派任務但未開帳號 | 1 | 0 | 0 | 未使用者仍納入分母 |
| 外部訪視者只查閱評核資料、未被指派訓練任務 | 0 | 0 | 0 | 不屬本件預先界定的應使用人口；須記錄排除理由 |
| 學員完成報名與學習確認，尚未完成課後評估 | 1 | 1 | 0 | 有實質操作，但未完成全部示範任務 |

退訓、離任或角色變更依事前明定的母體判定日處理；不得臨時用「未滿三分之一」等未有來源的門檻刪除分母。''','replace denominator and decision section')

between('## 第六部分：SAMPLE 系統架構與角色-必要任務矩陣','## 第七部分：數據萃取、去識別化、防重與異常處理機制', '''## 第六部分：SAMPLE 角色與必要任務矩陣

以下任務純為計算示範；不宣稱是協會現行規定。正式使用前，先與經授權且現行的作業規範逐項核對，若沒有可核實流程，須先標 `UNKNOWN/HOLD`。

| SAMPLE 角色 | 示範必要任務數 | 任務代碼 | 任務例 | 可核對紀錄欄位（示意） |
| :--- | :---: | :--- | :--- | :--- |
| 訓練行政 ADMIN | 3 | `COURSE_SETUP`; `ELIGIBILITY_CHECK`; `CLOSEOUT_EXPORT` | 建立課程與名冊；確認參訓資格；完成結案匯出 | 替代碼、期間、任務代碼、完成狀態、時間 |
| 講師 INSTRUCTOR | 2 | `ATTENDANCE_OR_ASSESSMENT`; `SESSION_CLOSEOUT` | 記錄出席或評量；完成授課結案 | 替代碼、期間、任務代碼、完成狀態、時間 |
| 學員 LEARNER | 3 | `ENROLMENT_CONFIRM`; `LEARNING_ACK`; `COURSE_EVALUATION` | 確認報名；完成學習確認；完成課後評估 | 替代碼、期間、任務代碼、完成狀態、時間 |

真實系統的欄位名稱依實際產品核實；不可使用此表中的虛構資料表或欄位名稱作為現況證據。''','replace role matrix')

between('## 第七部分：數據萃取、去識別化、防重與異常處理機制','## 第八部分：2023–2025 年普及率與完成率統計表與計算驗證', '''## 第七部分：資料整理、隱私與例外處理

### 7.1 真實資料取得程序
1. 先核實系統與權限存在；由獲授權角色以最小必要欄位取得指定期間資料。不要預設系統、資料庫或伺服器存在。
2. 先固定母體、角色、期間與任務清單，再抽取相應名冊及操作紀錄；保留原始檔於受權限保護的本機來源位置。
3. 只把完成實質工作的紀錄分類為活躍；登入、開帳號、密碼重設及頁面瀏覽不作分子。
4. 以本機受控的不透明替代碼合併同年跨班資料；重新核算唯一使用者與任務完成數。對照表不進入公開 DOCX 或 GitHub。
5. 留下來源定位、檔案完整性指紋、匯出時間、處理規則與例外紀錄。檔案 SHA-256 僅驗證位元組完整性，不是個資去識別方法。

### 7.2 個資與資料最小化
本示範只有 `SYN-*` 合成代碼，不含真實姓名、身分證字號、聯絡方式或帳號。真實使用前須由有權責者核定蒐集目的、授權、最小欄位、存取者、保存期限與安全刪除方式；識別值與替代碼對照表分開限權保管。直接對身分證字號作未加密雜湊，不應被描述為匿名化或法遵證明。本文件未作正式個資法遵審查。

### 7.3 例外與對帳
- 重複交易只計一次任務完成；重複使用者在同一期間只計一次分母與活躍分子。
- 未開帳號或沒有操作的合格者仍留在分母。
- 退訓、離任、跨角色或任務變更須依事前明定的判定日與角色規則處理；無規則時 `HOLD`，不得事後挑選分母。
- 若活躍人數大於合格分母、完成數大於活躍數、任務代碼不在核定清單，先停止出表並調節來源。
- 對帳紀錄至少包含日期、替代碼、異常、證據定位、處置依據、覆核角色與狀態；不填未經授權的人名或簽名。''','replace data handling section')

# Correct one relative change in the retained calculation table and clarify sample scope.
text=text.replace('**2025 年現況**','**2025 年 SAMPLE**')
text=text.replace('**2024 年進展**','**2024 年 SAMPLE**')
text=text.replace('**2023 年基準**','**2023 年 SAMPLE**')
text=text.replace('三年總計 (Pool)','三年合計（使用者－年度列）')
text=text.replace('三年期別對比與百分點變動彙整表','三個合成年度之比率變化表')
text=text.replace('全體 80 筆示範樣本總匯總：活躍 62 筆（77.50%），完成 52 筆（65.00%），運算勾稽完全吻合。','80 筆為使用者－年度紀錄；跨年度不代表 80 名不同真人。由附錄 A 重算：活躍 62/80（77.50%），全任務完成 52/80（65.00%）。')

between('## 第九部分：趨勢分析與角色落差診斷（Trend & Role-Gap Analysis）','## 第十部分：SAMPLE 改善行動計畫（Action Plan）', '''## 第九部分：合成數據的趨勢與角色差異

### 9.1 合成年度比較

[Word 組版時插入圖 1：SAMPLE 普及率與全體合格者完成率折線圖；來源為附錄 A 的合成列資料]

在這組示範數據中，普及率由 2023 的 60.00%（12/20）至 2024 的 78.57%（22/28），再至 2025 的 87.50%（28/32）。合格者全任務完成率分別為 45.00%（9/20）、64.29%（18/28）、78.13%（25/32）。這些數值只描述此合成資料，不是機構實績，也未作統計顯著性檢定。

### 9.2 角色差異
- **ADMIN**：普及率 2/3、3/3、3/3；合格者全任務完成率 2/3、3/3、3/3。示範列沒有未完成的活躍行政使用者；不可由此推論真實制度已改善。
- **INSTRUCTOR**：普及率 2/4、4/5、5/6；合格者全任務完成率 1/4、3/5、5/6。2023 示範資料中有 1 名活躍講師只完成 1/2 任務；原因未提供。2025 示範資料中 5 名活躍講師均完成 2/2 任務；不代表真實改善。
- **LEARNER**：普及率 8/13、15/20、20/23；合格者全任務完成率 6/13、12/20、17/23。2025 示範資料有 3 名活躍學員完成 2/3 任務；資料只指出尚缺 `COURSE_EVALUATION`，未提供原因。

### 9.3 解讀界限
角色人數、比例或工作代碼的差異只用於示範如何找出需查的環節。沒有真實來源、期間可比性與成因資料，不得把差異解讀成協會績效、改善成效或因果關係。''','replace trend and role analysis')

between('## 第十部分：SAMPLE 改善行動計畫（Action Plan）','## 第十一部分：真實數據置換指南與查核暫緩/修訂/駁回條件', '''## 第十部分：示範改善行動計畫（尚未核定）

下列是依合成列資料設計的可操作示例；責任角色、期限與目標均需由機構有權責者依現況核實，不能視為協會已採行。

| SAMPLE 落差 | 行動示例 | 責任角色（待核） | 時點 | 可量測檢核 | HOLD／修訂條件 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| 講師有實質操作但未完成全部必要任務 | 下期課程試行結案提醒清單；逐項顯示尚缺任務，完成後抽查紀錄 | 課程承辦角色（是否存在待核） | 每班結束後 5 個工作日內 | 比較下期講師全任務完成數／應完成人數；示範目標 ≥90%，須在真實使用前核定 | 沒有真實任務清單或紀錄，HOLD；逾期即列例外，不自動宣稱改善 |
| 學員完成 2/3 示範工作 | 提供可選的現場協助或等效紙本備援流程；補登後保留來源與時間 | 學員支援角色（是否存在待核） | 課程末段及結訓後對帳時 | 單獨計算課後評估完成率；不得把其他任務完成率代稱為問卷填答率 | 授權或網路處理方式未核實，HOLD；不得自行建立帳號或蒐集額外資料 |
| 同年度跨班重複列入風險 | 在本機以核定的替代碼規則去重，保存調節前後筆數 | 資料管理權責角色（待核） | 每期彙整前 | 重複使用者列為 0；保留例外與人工覆核紀錄 | 無可用且受控的替代碼，HOLD；不得以未加密雜湊身分證字號取代 |

計畫完成與否應由真實收據確認。此表沒有核准人、簽名、實際到期日或已完成證據。''','replace action plan')

between('## 第十一部分：真實數據置換指南與查核暫緩/修訂/駁回條件','## 第十二部分：評核查核清單與佐證索引對照表（Reviewer Checklist & Evidence Locator）', '''## 第十一部分：真實資料替換與內部品質退件條件

### 11.1 合成事實替換清單

| 合成項目 | SAMPLE 值 | 真實替換所需來源 | 安全替換與核對 |
| :--- | :--- | :--- | :--- |
| 年度與起訖日 | 2023–2025 | 有權責者確認的實際盤點期間及適用課程範圍 | 固定口徑並記錄變更；不得把合成年度當實際辦訓年度 |
| 系統名稱與任務 | SAMPLE-TIS-01、示範 task code | 真實產品／模組及已核定的作業任務 | 找不到系統或任務授權時保留 UNKNOWN/HOLD |
| 使用者－年度列 | SYN-* 替代碼 | 受授權的應使用名冊與操作來源 | 本機建立不透明替代碼；對照表隔離保管，不上傳公開分支 |
| 活躍／完成標記 | 0/1 SAMPLE 欄位 | 可核對的實質操作紀錄及任務清單 | 從來源逐列重算，排除只有登入或帳號建立的紀錄 |
| 彙總數與結論 | 12/20、22/28、28/32 等 SAMPLE | 真實來源列與期間定義 | 由真實列重算，不把樣本比例搬成實績 |
| 改善方案及狀態 | 未核定 SAMPLE 方案 | 有權責者核准的真實紀錄及執行證據 | 未取得簽核、紀錄或效果證據即標 UNKNOWN/HOLD |

### 11.2 本件建議的內部檢核處置

這是候選文件的內部品質控制，不代表 TTQS 官方處分或協會既有制度。

- **HOLD**：真實系統、應使用名冊、任務定義、來源授權、期間或去重方式未能核實；保留 SAMPLE，不輸出 REAL 結論。
- **REVISE**：公式、分母、角色任務、資料欄位或捨入有可修正的不一致；只修受影響欄位並重算。
- **REJECT**：以登入／開帳號充當活躍使用；剔除未操作的合格者；分子大於分母；跨期口徑拼接；捏造系統、人物、簽章、核准、實績或評分。
- **可送下一內部覆核**：來源與公式經本機逐項核對後，才交獨立 exact-SHA reviewer；本表自身不核定正式評分、不取代 Human 正式接受。''','replace replacement and rejection section')

between('## 第十二部分：評核查核清單與佐證索引對照表（Reviewer Checklist & Evidence Locator）','## 第十三部分：可直接操作之空白填報表單與工作日誌（Blank Operational Forms）', '''## 第十二部分：使用前覆核清單與證據位置

| 覆核點 | 可操作的核對問題 | 本候選狀態 | 真實替換所需證據 |
| :--- | :--- | :--- | :--- |
| 官方映射 | DOCX 0140 是否仍對 I19-E30、157 index 154、官方第9頁？ | SOURCE 已對照；正式接受未授予 | 當前官方來源與 crosswalk |
| 母體 | 每人每年是否只列一次？未使用者是否留在分母？ | SAMPLE 規則；REAL=UNKNOWN/HOLD | 授權名冊、事前定義的納入／排除表 |
| 活躍判準 | 是否要求至少一筆實質任務，而不是只有登入？ | SAMPLE 規則；REAL=UNKNOWN/HOLD | 經授權的操作紀錄 |
| 計算 | 是否由附錄 A 80 筆 user-year rows 重算出所有結果？ | SAMPLE 數值已做確定性重算；尚非獨立語意驗收 | 來源列、重算收據、exact SHA reviewer |
| 隱私 | 是否有直接識別資訊或不當公開對照表？ | 本候選示範列為合成；真實隱私覆核未做 | 有權責者的授權與本機資料保護檢核 |
| 鄰近項目 | 是否把檢索效率或 I19-E29 成果誤作使用率？ | 文中已有項目界線；獨立審查待做 | 跨文件來源鍵（若有） |
| 行動計畫 | 是否將 SAMPLE 建議誤寫為已核定／已執行？ | 方案明示尚未核定 | 真實授權、行動紀錄及後續成效 |
| Word 與接受 | 字體、分页、所有页面及 exact-SHA review 是否通過？ | 由組版與視覺QA收據填寫；本檔不代稱 PASS | Word 原生 render、全頁檢查、獨立 exact-SHA 收據 |
''','replace review checklist')

text=text.replace('表 13.1：年度訓練資訊系統使用普及率資料擷取登記表（空白）','表 13.1：年度訓練資訊系統使用普及率資料擷取登記表（空白）')
text=text.replace('系統主管（Training Administrative Supervisor）','訓練行政權責角色（SAMPLE；實際職稱待核）')
text=text.replace('原始日誌存放索引','合成來源索引（非真實路徑）')
text=text.replace('SEC-SRV01/LOGS/TIS/TIS_TRANS_EXPORT_2023-2025.csv','SAMPLE-LOG-<年度>-<替代碼>（示範索引，非路徑）')
text=text.replace('課後滿意度與學習評估漏填','示範必要任務未完成')
text=text.replace('依法應使用系統者','依本 SAMPLE 口徑應使用系統者')
text=text.replace('法定/規定培訓任務','預先定義且經核實的必要培訓任務')
text=text.replace('法定必要系統任務','角色所需的預先定義系統任務')
text=text.replace('所有法定必要系統任務','所有角色必要系統任務')
text=text.replace('法定/標準工作代碼','SAMPLE 工作代碼')
text=text.replace('法定或流程任務','示範流程任務（真實流程待核）')
text=text.replace('法定/標準工作代碼','SAMPLE 工作代碼')
text=text.replace('依法','依事前核實的作業規則')
text=text.replace('經核准之排除對象','按事前規則排除的對象')
text=text.replace('經主管核定','由實際有權責者核定')
text=text.replace('未經主管簽核','未依實際授權完成覆核')
text=text.replace('經協會理事會或主管核定','由機構依現行權責確認')
text=text.replace('由協會訓練主管及秘書長正式核定','由機構實際有權責者依其授權確認')
text=text.replace('人名代號','合成替代碼')
text=text.replace('個案識別代碼 (case_id)','SAMPLE 使用者－年度代碼 (case_id)')
text=text.replace('總樣本','總使用者－年度列數')
text=text.replace('總匯總','彙總')
text=text.replace('已具體完成','供試用')
text=text.replace('全篇數據計算經多重勾稽完全精確','SAMPLE 數據已由附錄列資料確定性重算；獨立語意審查及正式接受仍待完成')
text=text.replace('全文業已嚴格依據勞動部勞動力發展署 TTQS 訓練機構版第 19 項指標規範要求編撰完竣。','本文件是 DOCX 0140 / I19-E30 的候選示範稿；正式內容仍須通過獨立 exact-SHA 審查及 Human 正式接受。')
text=text.replace('供機構行政人員及評核委員查考使用。','可供行政人員依真實來源核實後試用；目前所有成果數字均為 SAMPLE/SYNTHETIC。')

# Remove the model-generated 80-row table; the Word assembler will insert the canonical, hash-bound CSV/register.
appendix='## 附錄：完整 80 筆 SAMPLE 去識別化個案數據清冊（Complete 80-Row Sample Dataset Register）'
if appendix in text:
    text=text[:text.index(appendix)] + '''## 附錄 A：完整 SAMPLE 使用者－年度資料

完整 80 筆列資料由組版程序直接載入同資料夾 `SYNTHETIC_USER_DATASET_0140_R01.csv`；逐事實替換清冊載入 `SYNTHETIC_REPLACEMENT_REGISTER_0140_R01.csv`。DOCX 附錄以這兩份 exact-SHA 資料產生，不採用 Worker 回覆內重排的資料列。每列均是 SAMPLE/SYNTHETIC，不代表跨年度不同真人。

## 結語與查核聲明

本件提供一套可填寫、可重算、可查核的訓練資訊系統使用普及率示範口徑。所附系統、課程、角色任務、操作索引與數據均為合成資料；目前沒有可核實的協會實際系統或使用成果來源，因此 `REAL=UNKNOWN/HOLD`。正式評分與 Human 接受尚未授予。'''
    changes.append('replace model-generated appendix with deterministic source-data insertion')

# Rewrite unsafe/invented lines remaining by exact phrase replacement.
text=text.replace('（雲端整合培訓資訊系統）','（純合成系統標籤；不指定產品或部署型態）')
text=text.replace('涵蓋教務、教學與學員端模組','模組名稱只作示範，須依實際系統核實')
text=text.replace('Apache/IIS Access Logs','網頁瀏覽或登入事件')
text=text.replace('未滿開課時數三分之一即合法退訓者，應檢附核准簽呈，並自應使用分母與分子同步移除，獨立記載於備查清冊。','退訓、離任或角色變更按事前定義的判定日與任務範圍處理；沒有已核實規則時標 UNKNOWN/HOLD，不自行移除分母。')
text=text.replace('依規定必須透過','依已核實任務定義須透過')
text=text.replace('規定之培訓任務','事前定義的培訓任務')
text=text.replace('規定必要任務清單','SAMPLE 必要任務清單')
text=text.replace('規定任務','SAMPLE 任務')
text=text.replace('標準作業程序（SOP）完全勾稽','經實際核實且有權責的作業規則逐項對照')
text=text.replace('資料庫 `crs_class`、`chk_qual`、`exp_close` 資料表生成更新紀錄。','示範紀錄欄位：替代碼、期間、任務代碼、完成狀態及時間；實際欄位依系統核實。')
text=text.replace('資料庫 `att_score_log`、`cls_sign_log` 存有講師數位送出戳記。','示範紀錄欄位：替代碼、任務代碼、狀態與時間；非真實資料表名稱。')
text=text.replace('資料庫 `stu_reg_cfm`、`stu_study_log`、`stu_eval_ans` 寫入完成紀錄。','示範紀錄欄位：替代碼、任務代碼、狀態與時間；非真實資料表名稱。')
text=text.replace('經系統自動寄發提醒通知','由有權責角色確認的提醒方式通知')
text=text.replace('系統自動寄發提醒通知','由有權責角色確認的提醒方式通知')
text=text.replace('高齡/數位弱勢學員','需要額外使用協助的學員')
text=text.replace('於實體最後一堂課保留 15 分鐘，由隨班助教以平板電腦或手機引導現場完成線上評估。','提供自願的操作說明及等效替代方式；先確認無障礙、設備與資料授權。')
text=text.replace('2026 年每班期最後一堂課','每一示範班期結束前（實際時程待核）')
text=text.replace('2026 年第一季初','下一示範期資料彙整前（實際時程待核）')
text=text.replace('人事部門進行個別輔導','指定的權責角色檢視原因並依核定流程處理')
text=text.replace('身分證字號雜湊','受控不透明替代碼')
text=text.replace('保留金鑰於保密伺服器','對照表僅於授權本機環境分開限權保管')
text=text.replace('顯著之','示範資料中的')
text=text.replace('此趨勢顯示合格受測群體對系統實質功能之接納程度呈現穩步上升。','此合成資料只呈現比例增加；不代表真實接納程度或統計顯著性。')
text=text.replace('反映使用者不僅「開始使用」，且越來越高比例能「走完全部規定作業」。','僅描述合成資料中全任務完成比例提高；不代表真實使用行為或改善原因。')
text=text.replace('資料庫原始匯出之 Transaction Log','經授權來源匯出的實質操作紀錄')
text=text.replace('檢附資安稽核核可的 CSV/SQL 匯出檔','保存經授權匯出且可追溯的資料檔')
text=text.replace('以 SHA-256 演算法進行雜湊加密，保留金鑰於保密伺服器。','以受控不透明替代碼代替直接識別值；保留對照表於授權本機位置。')
text=text.replace('保留金鑰於保密伺服器','對照表於本機分開限權保管')
text=text.replace('全數使用虛擬編碼','本示範使用合成編碼')
text=text.replace('【通過查核】<br>轉入正式評核佐證卷宗','【可進下一內部覆核】<br>仍須獨立 exact-SHA 審查與 Human 正式接受')
text=text.replace('立即作廢退件，全表不予採認','本文件內部退回修正；不代替 TTQS 官方評定')
text=text.replace('凍結程序，限期補正佐證','保留 UNKNOWN/HOLD，取得必要來源後再分析')
text=text.replace('限期 7 個工作日內重新計算並修正文本後重送','由有權責者設定修訂期限，重新計算並記錄改動')
text=text.replace('全案暫緩評核，待補正原始憑證與權限審查後始得復會。','本候選資料維持 UNKNOWN/HOLD；取得來源與授權前不作真實結論。')
text=text.replace('檢附正式年度開班核定函文','提供經核實的期間／範圍來源；如無則列 UNKNOWN/HOLD')
text=text.replace('檢附軟體授權合約書、系統使用授權證明或官方公文','提供可核實的系統／授權來源；不假設存在採購或部署')
text=text.replace('以 SHA-256 演算法進行雜湊加密','使用受控不透明替代碼；SHA-256 只用於檔案完整性檢查')
text=text.replace('系統交易日誌（Transaction）','授權來源的實質操作紀錄')
text=text.replace('四捨五入至小數點後兩位','依半入規則四捨五入至小數點後兩位')
text=text.replace('實體簽核完成之公文掃描檔','有權責者的真實授權紀錄；不得補造簽核原件')
text=text.replace('均已防重合併','是否按核定口徑去重')
text=text.replace('（80筆示範數據運算無誤）','（由附錄 A 作確定性重算；獨立審查另列）')
text=text.replace('（示範數據全數去識別化）','（本候選只含合成列；真實個資覆核尚未完成）')
text=text.replace('分數與小數點運算','比率與小數位運算')
text=text.replace('分母母體人數','合格應使用者分母')
text=text.replace('主管／秘書長','經核實的授權角色')
text=text.replace('機構首長／秘書長（核定與行動批示）','經核實的授權角色（是否具此職權須依章程／權限核實）')
text=text.replace('雜湊加密','替代碼化')
text=text.replace('SAMPLE/SYNTHETIC（合成示範數據）','SAMPLE/SYNTHETIC（合成示範數據）')

# Replace erroneous named sample courses wherever any remain.
text=text.replace('照顧服務員專班、原鄉多元培力研習班、數位行銷應用班','SAMPLE-COURSE-01、SAMPLE-COURSE-02、SAMPLE-COURSE-03')

# Make candidate status and non-acceptance unambiguous.
text=text.replace('**正式評核採認狀態**：`NOT_GRANTED`（尚未獲得官方正式採認評分）','**正式評核／Human 接受狀態**：`NOT_GRANTED`（本候選未獲正式採認或 Human 接受）')
text=text.replace('現階段真實佐證狀態','本候選真實佐證狀態')

out_path.write_text(text, encoding='utf-8')
# Review for known unsupported concrete identifiers and unsafe privacy claims.
forbidden = ['屏東縣原住民原點關懷協會','SEC-SRV01','照顧服務員專班','原鄉多元培力研習班','數位行銷應用班','資料表 `crs_class`','身分證雜湊鍵','以 SHA-256 演算法進行雜湊加密','符合法個人資料保護法']
remaining=[x for x in forbidden if x in text]
report={
  'source_sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest(),
  'candidate_manuscript_sha256':hashlib.sha256(out_path.read_bytes()).hexdigest(),
  'candidate_chars':len(text),
  'change_groups':changes,
  'remaining_forbidden_tokens':remaining,
  'relative_rate_2024_2025_corrected':'+11.36%',
  'manual_disposition':'FAIL_REVISE_REQUIRED: source inventions and unsupported assertions removed; independent semantic review still pending',
  'real_status':'UNKNOWN/HOLD',
  'formal_acceptance':'NOT_GRANTED'
}
(ROOT/'MANUSCRIPT_REPAIR_RECEIPT_0140_R01.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
if remaining:
    raise SystemExit('Forbidden assertions remain: '+repr(remaining))
print(json.dumps(report,ensure_ascii=False,indent=2))
