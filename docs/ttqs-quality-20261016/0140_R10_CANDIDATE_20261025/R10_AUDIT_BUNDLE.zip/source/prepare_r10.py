from pathlib import Path
import shutil, hashlib, json
base=Path(r'E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016')
r09=base/'0140_I19-E30_CANDIDATE_R09_20261025'
r10=base/'0140_I19-E30_CANDIDATE_R10_20261025'
src02=base/'0140_I19-E30_SOURCE_PREP_R02_20261025'
src03=base/'0140_I19-E30_SOURCE_PREP_R03_20261025'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected='49afdcfa11b6f91952590995b4c0152d76271b2169b2a4433bb08bbbba46db4e'
r09doc=r09/'candidate'/'0140__訓練資訊系統使用普及率盤點與分析表_R09.docx'
if sha(r09doc)!=expected: raise SystemExit('R09 candidate SHA changed; abort R10 preparation')
if src03.exists(): raise SystemExit(f'Refusing to overwrite source prep {src03}')
shutil.copytree(src02,src03)
worker=src03/'worker'
old=worker/'MANUSCRIPT_0140_R09.md'; new=worker/'MANUSCRIPT_0140_R10.md'
if not old.exists() or new.exists(): raise SystemExit('Unexpected manuscript state in R03 prep')
shutil.copy2(old,new); old.unlink()
for name in ['candidate','source','receipts','review','renders']:
    (r10/name).mkdir(parents=True,exist_ok=True)
# Reuse only unchanged source mapping, dataset, summary, and replacement register.
for name in ['SOURCE_MAPPING_0140_R06.json','SYNTHETIC_USER_DATASET_0140_R01.csv','SAMPLE_PERIOD_SUMMARY_0140_R01.csv','SYNTHETIC_REPLACEMENT_REGISTER_0140_R07.csv']:
    matches=list(src03.rglob(name))
    if not matches: raise SystemExit('Missing reusable source '+name)
    print(name,sha(matches[0]),matches[0])
# Clone builder and retarget it to the isolated R10 source/output namespace.
rb=r09/'source'/'build_0140_docx_r09.py'
build_text=rb.read_text(encoding='utf-8')
build_text=build_text.replace('SOURCE_PREP_R02_20261025','SOURCE_PREP_R03_20261025').replace('CANDIDATE_R09_20261025','CANDIDATE_R10_20261025').replace('MANUSCRIPT_0140_R09.md','MANUSCRIPT_0140_R10.md').replace('R09','R10')
old_pat='    pat=re.compile(r"(\\*\\*.*?\\*\\*|"+code_re+r"[^"+code_re+r"]+"+code_re+r")")'
new_pat='    italic_re=r"(?<!\\*)\\*(?!\\*)(?:[^\\s*\\n](?:[^*\\n]*?[^\\s*\\n])?)\\*(?!\\*)"\n    pat=re.compile(r"("+code_re+r"[^"+code_re+r"]+"+code_re+r"|\\*\\*.*?\\*\\*|"+italic_re+r")")'
if old_pat not in build_text: raise SystemExit('Expected add_inline pattern not found; no DOCX built')
build_text=build_text.replace(old_pat,new_pat,1)
old_branch='''        elif chunk.startswith(tick) and chunk.endswith(tick):
            run=p.add_run(chunk[1:-1]); set_run_font(run,base_size,None,"314E68",italic,"Aptos")'''
new_branch='''        elif chunk.startswith("*") and chunk.endswith("*") and not chunk.startswith("**"):
            run=p.add_run(chunk[1:-1]); set_run_font(run,base_size,base_bold,base_color,True)
        elif chunk.startswith(tick) and chunk.endswith(tick):
            run=p.add_run(chunk[1:-1]); set_run_font(run,base_size,None,"314E68",italic,"Aptos")'''
if old_branch not in build_text: raise SystemExit('Expected add_inline branch not found')
build_text=build_text.replace(old_branch,new_branch,1)
(r10/'source'/'build_0140_docx_r10.py').write_text(build_text,encoding='utf-8')
# Adapt the deterministic R09 QA to R10, add exact R09 parent freeze and markdown-italic rendering checks.
qa=(r09/'source'/'qa_0140_r09_comprehensive.py').read_text(encoding='utf-8')
qa=qa.replace('CANDIDATE_R09_20261025','CANDIDATE_R10_20261025').replace('SOURCE_PREP_R02_20261025','SOURCE_PREP_R03_20261025').replace('_R09.docx','_R10.docx').replace('MANUSCRIPT_0140_R09.md','MANUSCRIPT_0140_R10.md').replace('R09','R10')
anchor='check("R08_unchanged",sha(r08)=="a6feeb119c14731b63c92833411721e6613db5a011a26f8e38334de9ecacc970",{"sha256":sha(r08)})'
insert=anchor+'\nr09=Path(r"E:\\\\TTQS\\\\TTQS_ONE_CODEX_RUNTIME\\\\WORK\\\\QUALITY_REBUILD_20261016\\\\0140_I19-E30_CANDIDATE_R09_20261025\\\\candidate\\\\0140__訓練資訊系統使用普及率盤點與分析表_R09.docx")\ncheck("R09_unchanged",sha(r09)=="49afdcfa11b6f91952590995b4c0152d76271b2169b2a4433bb08bbbba46db4e",{"sha256":sha(r09)})'
if anchor not in qa: raise SystemExit('QA R08 unchanged anchor missing')
qa=qa.replace(anchor,insert,1)
anchor2='check("no_unsupported_real_or_approval_claims",'
idx=qa.find(anchor2)
if idx<0: raise SystemExit('QA real-claim anchor missing')
italic_check='''check("markdown_italics_rendered_without_literal_markers",full.count("*")==full.count("SYN-*"),{"asterisks_in_extracted_docx":full.count("*"),"legitimate_SYN_wildcard_count":full.count("SYN-*"),"visible_markdown_markers_absent":full.count("*")==full.count("SYN-*")})\n'''
qa=qa[:idx]+italic_check+qa[idx:]
(r10/'source'/'qa_0140_r10_comprehensive.py').write_text(qa,encoding='utf-8')
# Copy unchanged source-mapping evidence and prior exact-SHA review text as provenance, not as R10 review.
for f in (r09/'source').glob('*'):
    if f.name.startswith('SOURCE_MAPPING'):
        shutil.copy2(f,r10/'source'/f.name)
resp=r09/'review'/'OPENCODE_R09_STDOUT.jsonl'
if resp.exists(): shutil.copy2(resp,r10/'review'/'OPENCODE_R09_STDOUT_HISTORICAL.jsonl')
# Seed manifest only with stable source facts; all R10 acceptance fields reset.
m=json.loads((r09/'MANIFEST_R09.json').read_text(encoding='utf-8'))
m.update({"work_id":"TTQS-0140-I19-E30-R10","candidate_revision":"R10","parent_candidate_revision":"R09","parent_docx_sha256":expected,"visual_review":"PENDING","independent_semantic_review":"PENDING_R10_EXACT_SHA","docx_sha256":"PENDING","docx_bytes":0,"build_receipt_sha256":"PENDING","comprehensive_qa_sha256":"PENDING","comprehensive_qa_status":"PENDING","review_packet_sha256":"PENDING","review_packet_receipt_sha256":"PENDING","targeted_changes":["Change only the deterministic inline Markdown parser so single-asterisk emphasis renders as Word italics; leave manuscript, 80-row SAMPLE dataset, chart inputs, and replacement register unchanged."],"unchanged_manuscript_content_from_R09":True,"unchanged_80_row_dataset":True,"unchanged_replacement_register":True,"R09_parent_sha256":expected})
(r10/'MANIFEST_R10.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(r10/'README_R10.md').write_text('# DOCX 0140 R10 candidate\n\n- Mapping: DOCX 0140 -> I19-E30 -> official 157-item index 154; printed checkbox serial: UNKNOWN.\n- Parent R09 SHA-256: '+expected+'.\n- R10 changes only Word rendering of single-asterisk Markdown emphasis; manuscript text and content are unchanged from R09.\n- The 80-row SAMPLE dataset, chart inputs, and replacement register are reused byte-identically.\n- Replacement register: 82 data records (80 user-year + 2 control) plus 1 header = 83 physical lines.\n- Status: CANDIDATE; REAL=UNKNOWN/HOLD; formal acceptance NOT_GRANTED.\n- Native Word render, complete visual inspection, and independent R10 exact-SHA delta review are pending.\n',encoding='utf-8')
print('PREPARED',r10)