from pathlib import Path
from docx import Document
import hashlib,json,re
r08=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_CANDIDATE_R08_20261025")
r10=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_CANDIDATE_R10_20261025")
docx=r10/"candidate"/"0140__訓練資訊系統使用普及率盤點與分析表_R10.docx"
manuscript=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_SOURCE_PREP_R03_20261025\worker\MANUSCRIPT_0140_R10.md")
builder=r10/"source"/"build_0140_docx_r10.py"
dataset=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_SOURCE_PREP_R03_20261025\SYNTHETIC_USER_DATASET_0140_R01.csv")
register=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_SOURCE_PREP_R03_20261025\SYNTHETIC_REPLACEMENT_REGISTER_0140_R07.csv")
template=(r08/"review"/"OPENCODE_R08_REVIEW_PACKET.md").read_text(encoding="utf-8")
marker="## Exact text extracted from the R08 DOCX\n"
dataset_marker="## Canonical 80-row SAMPLE dataset CSV\n"
head,tail=template.split(marker,1)
old_body,suffix=tail.split(dataset_marker,1)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
doc=Document(str(docx))
parts=[]
para_index=0
for p in doc.paragraphs:
    para_index+=1
    if p.text.strip():
        parts.append(f"[P{para_index}] {p.text}")
for i,t in enumerate(doc.tables,1):
    parts.append(f"\n[TABLE {i} | {len(t.rows)} rows | {len(t.columns)} columns]")
    for row in t.rows:
        cells=[]
        for c in row.cells:
            s=" / ".join(x.strip() for x in c.text.splitlines() if x.strip())
            cells.append(s.replace("|","\\|"))
        parts.append("| "+" | ".join(cells)+" |")
    parts.append("[/TABLE]")
new_body="\n".join(parts)+"\n\n"
head=head.replace("R08","R10")
head=re.sub(r"Candidate DOCX path: .*", lambda m: "Candidate DOCX path: "+str(docx), head, count=1)
head=re.sub(r"Candidate bytes: [0-9,]+", f"Candidate bytes: {docx.stat().st_size:,}", head, count=1)
head=head.replace("a6feeb119c14731b63c92833411721e6613db5a011a26f8e38334de9ecacc970",sha(docx))
head=head.replace("127,755",f"{docx.stat().st_size:,}")
head=head.replace("b8ab8a6709ca1bed0526401c14396985f786735ec37e61956c8265a9dde8c4d8",sha(manuscript))
head=head.replace("eae8f5c14d6a9c2759915bb38fc731a5a4271c503a739c461c6713c199529e82",sha(builder))
head=head.replace(
 "## Exact text extracted from the R10 DOCX",
 "## Exact text extracted from the R10 DOCX")
note=(
 "\n\n### R10 targeted recheck\n"
 "R08 findings to verify on this candidate: (a) section-12 checklist cells must use training-officer language rather than internal pipeline terminology; "
 "(b) section 9.2 must state active-but-incomplete instructor and learner cases across all three SAMPLE years; "
 "(c) the replacement register count must distinguish 82 data records from the header, for 83 physical lines. "
 "Confirm from the extracted content and supplied source rows. Review text semantics, mappings, all arithmetic and case distributions. "
 "The host computed the candidate binary SHA shown above and extracted the full document text from that exact local path immediately afterward. "
 "This packet reviewer has no local file or shell access, so it must not claim to have recomputed the binary SHA. "
 "Native Word rendering and visual inspection are a separate gate.\n"
)
head=head.replace("\n## Review instructions\n","\n## Review instructions\n",1)
# Add the targeted instructions after the existing seven-item review list without changing prior authority text.
body_intro = new_body + note
suffix = dataset_marker + suffix
suffix=suffix.replace(
 "## Replacement register CSV (82 rows including header and control rows)",
 "## Replacement register CSV (82 data records: 80 user-year + 2 control; 83 physical lines including header)")
packet=head+marker+body_intro+suffix
if f"Candidate DOCX SHA-256: {sha(docx)}" not in packet or f"Candidate bytes: {docx.stat().st_size:,}" not in packet: raise SystemExit("R10 packet header does not bind exact candidate metadata")
out=r10/"review"/"OPENCODE_R10_REVIEW_PACKET.md"
out.write_text(packet,encoding="utf-8",newline="\n")
receipt={
 "work_id":"TTQS-0140-I19-E30-R10-REVIEW-PACKET",
 "docx_sha256":sha(docx),
 "docx_bytes":docx.stat().st_size,
 "review_packet_sha256":sha(out),
 "review_packet_bytes":out.stat().st_size,
 "manuscript_sha256":sha(manuscript),
 "builder_sha256":sha(builder),
 "dataset_sha256":sha(dataset),
 "register_sha256":sha(register),
 "register_data_records":82,
 "register_physical_lines":len(register.read_bytes().splitlines()),
 "paragraphs_extracted":para_index,
 "tables_extracted":len(doc.tables),
 "table_rows_extracted":sum(len(t.rows) for t in doc.tables),
 "reviewer_tool_access":"NO_TOOLS_NO_FILE_ACCESS",
 "binary_sha_independently_recomputed_by_reviewer":"NO",
 "status":"READY_FOR_INDEPENDENT_TEXT_SEMANTIC_REVIEW"
}
rpath=r10/"review"/"R10_REVIEW_PACKET_RECEIPT.json"
rpath.write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({**receipt,"packet_path":str(out),"receipt_sha256":sha(rpath)},ensure_ascii=False,indent=2))