from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
FILES = [
    "DOCX_BUILD_RECEIPT_0140_R10.json",
    "source/build_0140_docx_r10.py",
    "source/make_r10_review_packet.py",
    "source/prepare_r10.py",
    "source/qa_0140_r10_comprehensive.py",
    "source/package_r10_audit_bundle.py",
    "source/SOURCE_MAPPING_0140_R09.json",
    "source/MANUSCRIPT_0140_R09.md",
    "source/SYNTHETIC_USER_DATASET_0140_R01.csv",
    "source/SYNTHETIC_REPLACEMENT_REGISTER_0140_R07.csv",
    "candidate/SAMPLE_RATE_TREND_0140_R10.png",
    "candidate/0140__訓練資訊系統使用普及率盤點與分析表_R10.docx",
    "receipts/R10_COMPREHENSIVE_QA_0140.json",
    "receipts/R10_VISUAL_PAGE_DIFF.json",
    "renders/WORD_PAGES/0140_R10_page-08.png",
    "renders/WORD_PAGES/0140_R10_page-09.png",
    "renders/WORD_PAGES/0140_R10_page-12.png",
    "renders/WORD_PAGES/0140_R10_page-15.png",
    "renders/WORD_RENDER_RECEIPT_0140_R10.json",
    "renders/WORD_RENDER_STATE_0140_R10.json",
    "review/OPENCODE_R10_PROMPT.txt",
    "review/OPENCODE_R10_REVIEW_PACKET.md",
    "review/R10_REVIEW_PACKET_RECEIPT.json",
    "review/OPENCODE_R10_REVIEW_RESPONSE.md",
    "review/R10_SEMANTIC_REVIEW_RECEIPT.json",
    "review/OPENCODE_R10_LAUNCH.json",
    "review/OPENCODE_R10_STDOUT.jsonl",
    "review/OPENCODE_R10_STDERR.txt",
    "review/OPENCODE_R10_SESSION_EXPORT_SANITIZED.json",
]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    inventory = []
    for relative in FILES:
        path = ROOT / relative
        if not path.is_file():
            raise FileNotFoundError(path)
        inventory.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path)})

    manifest_path = ROOT / "MANIFEST_R10.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["visual_receipt_sha256"] = sha256(ROOT / "receipts/R10_VISUAL_PAGE_DIFF.json")
    manifest["semantic_review_receipt_sha256"] = sha256(ROOT / "review/R10_SEMANTIC_REVIEW_RECEIPT.json")
    manifest["semantic_review_original_sha256"] = sha256(ROOT / "review/OPENCODE_R10_REVIEW_RESPONSE.md")
    manifest["audit_evidence_files"] = inventory
    manifest["audit_bundle_contents_note"] = (
        "Bundle contains the standalone candidate DOCX, full manuscript/data/register sources, chart, "
        "build and QA code/receipts, four rendered pages covering changed emphasis, the operational checklist and chart page, "
        "and original OpenCode review packet, response, session output and receipts. The visual receipt "
        "lists SHA-256 values for all 29 locally inspected pages."
    )
    write_json(manifest_path, manifest)

    readme_path = ROOT / "README_R10.md"
    readme_path.write_text(
        "# DOCX 0140 R10 candidate\n\n"
        "- Mapping: DOCX 0140 -> requirement I19-E30 -> official 157-item index 154; printed checkbox serial: UNKNOWN.\n"
        "- Exact candidate SHA-256: de9525e42a391d0ed002d23d54d5a9b9c1e042f7c194b71f00b61bd98ff48c16.\n"
        "- R10 changes only Word rendering of paired single-asterisk emphasis; manuscript text, 80-row SAMPLE data, chart inputs and replacement register are unchanged from R09.\n"
        "- The audit bundle contains the source manuscript, dataset, replacement register, source mapping, build/QA code, receipts, four rendered pages showing changed emphasis, the operational checklist and chart, and original OpenCode review materials. The complete 29-page Word PDF remains in the Windows candidate folder.\n"
        "- Deterministic technical/content QA: PASS, 21/21 checks.\n"
        "- Native Microsoft Word render: PASS, 29 pages; PDF SHA-256 03a9e7c8efd30beb81f0882bb6995211bff2bd6a6e487f0c45ff2c28117cfdd5.\n"
        "- Visual review: PASS, all 29 pages individually inspected; exact page image hashes and R09 pixel-diff results are in receipts/R10_VISUAL_PAGE_DIFF.json.\n"
        "- Independent OpenCode CLI v2 text semantic review: PASS, bound to the candidate SHA. It reports three LOW wording recommendations and one chart OBS; the chart values were checked in the separate visual review. The three LOW items remain non-blocking and are not represented as repaired.\n"
        "- Reviewer did not recompute the DOCX binary SHA or inspect page images; host and Word-render receipts separately bind those artifacts.\n"
        "- Replacement register: 82 data rows (80 SAMPLE user-year rows plus two control rows) and one header = 83 physical lines.\n"
        "- Status: CANDIDATE only; REAL evidence UNKNOWN/HOLD; formal acceptance NOT_GRANTED.\n",
        encoding="utf-8",
    )

    bundle = ROOT / "R10_AUDIT_BUNDLE.zip"
    archive_files = ["README_R10.md", "MANIFEST_R10.json", *FILES]
    with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for relative in archive_files:
            zf.write(ROOT / relative, arcname=relative)

    with zipfile.ZipFile(bundle, "r") as zf:
        bad_member = zf.testzip()
        if bad_member:
            raise ValueError(f"Corrupt ZIP member: {bad_member}")
        for item in inventory:
            data = zf.read(item["path"])
            if hashlib.sha256(data).hexdigest() != item["sha256"]:
                raise ValueError(f"ZIP member differs from inventory: {item['path']}")
        for relative in ("README_R10.md", "MANIFEST_R10.json"):
            if zf.read(relative) != (ROOT / relative).read_bytes():
                raise ValueError(f"ZIP metadata mismatch: {relative}")

    receipt = {
        "work_id": "TTQS-0140-I19-E30-R10-AUDIT-BUNDLE",
        "candidate_docx_sha256": "de9525e42a391d0ed002d23d54d5a9b9c1e042f7c194b71f00b61bd98ff48c16",
        "bundle_file": bundle.name,
        "bundle_sha256": sha256(bundle),
        "bundle_bytes": bundle.stat().st_size,
        "included_files": len(archive_files),
        "verification": "PASS: archive CRC and all included evidence hashes match their local sources",
        "excluded": "The complete 29-page PDF and other 25 PNG page images remain in the Windows candidate folder. The bundle includes pages 8, 9, 12, and 15; all 29 image hashes are in the visual receipt.",
    }
    write_json(ROOT / "receipts/R10_AUDIT_BUNDLE_RECEIPT.json", receipt)
    print(json.dumps({
        "manifest_sha256": sha256(manifest_path),
        "readme_sha256": sha256(readme_path),
        "bundle_sha256": sha256(bundle),
        "bundle_bytes": bundle.stat().st_size,
        "bundle_receipt_sha256": sha256(ROOT / "receipts/R10_AUDIT_BUNDLE_RECEIPT.json"),
        "candidate_docx_sha256": sha256(ROOT / "candidate/0140__訓練資訊系統使用普及率盤點與分析表_R10.docx"),
        "verified_members": len(archive_files),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
