# Writer request: DOCX 0126 / I19-E14, manuscript R01

Return one complete, evaluator-readable Traditional Chinese analysis report manuscript only. Do not output a plan, meta-commentary, outline-only response, code, or claims that the association already conducted this survey. Use the supplied current SOURCE PACKET and UNIQUE BLUEPRINT as controlling content authority. The archived R02 body is prohibited as a template and is intentionally not supplied.

The deliverable is a usable analysis report for a small volunteer association with no assumed HR department. Make its subject unmistakably post-training salary survey and analysis, not job-use tracking (0125/I19-E13) or market/customer value analysis (0127/I19-E16). Keep the official sentence exact. Start with purpose, reader, survey window, key result scope, and SAMPLE/SYNTHETIC status.

Required content: executive summary; cohort, contact, consent, pairing, comparability and verification method; fixed baseline and 90-day follow-up windows; privacy/minimum-access controls; complete 12-person synthetic flow; a six-person paired salary table with all specified IDs and amounts; formulas and step-by-step calculations; totals, individually increased/unchanged/decreased counts and denominators; descriptive modest-rise definition of 0%<increase<=5% clearly marked as a report-only grouping, not an official score threshold; aggregate weighted salary change 2,500/211,000=1.1848%; segment comparison with n and limits; chart-ready values and plain-language chart reading; evidence strength and non-causal limitations; actionable recommendations with role owners, deadlines and follow-up criteria; a separate blank REAL-only survey/form and source-evidence checklist; item-level synthetic replacement register; official requirement-to-page/table locator; version, privacy, hold/reopen and approval boundaries.

Use the exact numeric vector in the Blueprint. Recompute every figure. Do not silently alter any input, denominator, date window or classification. Missing permission, nonresponse, unverified self-report, missing baseline, and no salary opportunity must remain separate; never treat missing as zero. Salary change is descriptive, not caused by training. No real names, actual pay slips, employer attestations, association approvals, signatures or real data. Every synthetic locator must say it is simulated, not an actual file. Any reusable form must be clearly separate from the completed synthetic demonstration and must not contain invented REAL entries.

Include the complete 12-case synthetic disposition: six verified paired cases; one no salary opportunity; two not authorized; one nonresponse; one self-reported but unverified HOLD; one missing baseline. This sums to 12. The six paired cases and exact base/follow-up figures are listed in the Blueprint; reproduce them faithfully and show all calculations and denominator rules.

The report-only small-increase grouping is strictly a descriptive band. Do not present it as an official TTQS threshold. State that the sample is invented solely to demonstrate the method and does not report Original Point Association performance.

Write full connected prose around the tables, explain decisions and follow-up steps, and avoid generic filler. If a critical element cannot be supported by the supplied source, say so precisely and retain SAMPLE status; do not invent external facts.

--- AUTHORITATIVE SOURCE PACKET ---
# DOCX 0126 / I19-E14 專屬來源包 R01

## 權威與精確對應

- 專案：TTQS ONE；交付文件編號：0126；官方方框編號：I19-E14。兩種編號不可互換。
- 官方方框原文：**進行訓後薪資調查，部份訓後學員微幅調薪。**
- 官方查核佐證文件資料表：第 8 頁；本機 PDF 文字抽取確認原文存在（空白與 PDF 換行正規化後比對），不是視覺逐像素驗證。
- 對應正式交付名稱：`0126__訓後薪資變化調查與分析表.docx`。
- 文類：分析／評估報告，必須呈現訓後薪資調查的資料口徑、可重算分析、限制與決策，不可做成一般薪資名冊或泛用成果報告。

## 來源定位與版本

- 本機官方 PDF：`SOURCES\TTQS查核佐證文件資料表-訓練機構版 (2).pdf`；SHA-256 `805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709`。
- PDF 第 8 頁（pypdf index 7）文字抽取 SHA-256：`57c6b33d70b665bd41b8d58ff58f5c0d78f9c2c751ccd9c6dd1b740b2fbf374e`；抽取 681 字元；官方原句移除空白後精確存在。
- GitHub PR #92 候選分支來源基準：`dda88f97bd24844c8c718800f0a096f488fd9df3`。
- 官方 PDF GitHub 路徑 `quality-review/0037_R07/inputs/official_source.pdf` 的 Git blob SHA：`9c7621decdad585b743bf2b3d949ee5518b7bee0`；這是 Git blob SHA，不是檔案 SHA-256。
- 目前 142 文件 Blueprint 輸入：`CONTROL\BLUEPRINT_CURRENT.jsonl`；本機 SHA-256 `406d0495365d0970dcf8113a42842663b8a54372a4e204cc492b7c3f8156ef3e`；PR 分支同路徑 Git blob SHA `cab446ede479001334289d18062e6b8bb2340dc3`。0126 精確 JSON 列 SHA-256 `bc640157d7f6e462de26a1b021af414be182b737319df3573ebbdfed34813cc6`，逐欄複本見 `BLUEPRINT_ROW_0126_I19-E14.json`。
- 本機 129→142 對照表 SHA-256：`1ddfbb608bcad25170683ddb42a1dbb27bafa6f1f35ff0498f1b8d75b24f0679`；本輪未取得其 GitHub 原始位元組，故只作本機 crosswalk 證據，不冒稱遠端讀回。

## 專屬範圍與鄰件排除

本件只回答「有同意且薪資資料可驗證的訓後學員，在一致追蹤期間是否出現薪資變化、幅度如何，以及資料支持到什麼證據強度」。

- 0125 / I19-E13 是所學運用於職務的追蹤紀錄；職務運用不等同薪資變化，本件不能代替其觀察紀錄。
- 0127 / I19-E16 是目標市場及顧客價值量化效益；市場／顧客指標不得混入個人薪資結果。
- 本件不能推論協會整體績效、就業品質、訓練因果或所有學員薪資提升。

## 資料使用界線

目前沒有提供可驗證的協會訓後薪資 REAL 原始資料、受訪同意、薪資證明、正式核准或第三方原件。任何初稿數字必須逐項標為 `SAMPLE / SYNTHETIC ONLY`，以匿名角色碼示範完整方法，並列 replacement register。不得把示範薪資、日期、樣本、調查回覆、核准或成效說成原始點協會實績。未獲授權的個資及薪資證明不得上傳公開 GitHub。

## 歷史版本隔離

歷史檔 `1905_0126__I19-E14__01__訓後薪資變化調查與分析表__R02.docx` SHA-256 `14b0cd010606b9f609b829c525378c14c00cf73d510ec7370bc6dc7bae13ae45`；20 段落、7 表格、抽取文字約 1,153 字元。該檔只供檔案沿革識別；Blueprint 規定 `historical_body_use=PROHIBITED`，不得複製、改寫或作新稿模板；本輪未找到它的現行 exact-SHA QA 收據。

## 建置前必需條件

Writer 必須先依 `UNIQUE_BLUEPRINT_0126_I19-E14_R01.md` 產生完整正文，至少包括方法、完整合成明細、公式逐步計算、分群、圖表數據、限制、決策和 replacement register。只交標題、空白問卷或摘要即退件。完成文字後由 Windows Word 建立 DOCX，並分別作技術／逐頁視覺與獨立 exact-SHA 語意驗收。

--- UNIQUE BLUEPRINT ---
# DOCX 0126 / I19-E14 專屬 Blueprint R01

## 文件識別與目的

- 文件 ID：0126；官方 checkbox：I19-E14；兩者不可互作。
- 題名：訓後薪資變化調查與分析表。
- 官方要求（不改寫）：「進行訓後薪資調查，部份訓後學員微幅調薪。」（官方資料表第 8 頁）
- 文類：分析／評估報告。讀者為協會訓練行政人員、主管與評核委員。報告需回答「調查誰、如何建立前後配對、多少資料可核驗、薪資變化如何分布、能作出何種有限結論、接下來由誰補什麼證據」。
- 主要輸出：薪資調查作業規則、匿名受訪資料字典、完整 SAMPLE 分析、可重算表、圖表、結論與行動追蹤。

## 專屬分析口徑

1. 固定分析單位為完成同一訓練的單一學員；同一學員的基準與追蹤月薪必須成對、同幣別、同薪資週期、同工時／全職當量口徑，並可合法驗證。
2. 必須先列全體完訓母數、接觸／邀請、同意、有效配對、未回覆、拒絕／未授權、缺基準、失業或不可比薪資、未驗證等流程；只在同意且有有效配對的分母計薪資變化。拒答、未回覆、缺值不得當作零變動。
3. 個人薪資變化額 = 追蹤月薪 − 基準月薪；個人變化率 = 變化額 ÷ 基準月薪 × 100%。基準月薪為零或資料口徑不一致時列 N/A 並剔除配對分析，記原因。
4. 成果率 = 有效配對中符合明確薪資結果條件的人數 ÷ 有效配對人數；同時報上升、不變、下降人數與分母。任何「微幅」區間只能明確標成此報告的描述性分組界線，不能冒稱官方評分門檻。
5. 總額變化率 =（有效配對追蹤月薪總和 − 基準月薪總和）÷ 基準月薪總和。不得與「個人變化率的平均」混稱；若展示兩者，必須各自命名並交代權重。
6. 薪資變動與訓練的因果歸因須另有設計及證據；單組前後比較只描述時間上的配對差異，不得寫成「訓練造成加薪」。通膨、職等、工時、產業與外部薪資變動均是可能混雜因素。

## 完整 SAMPLE 工作例（所有值皆為合成）

SAMPLE 規則：僅為版型與公式測試，不代表原始點協會或任何真實個人。建議設定 12 名合成完訓者、固定追蹤窗（例如課後第 90 日；日期一律明標 2026-xx-xx SYNTHETIC），薪資統一使用新臺幣月薪、同一月工時口徑。完整分析明細須顯示每一合成 ID、同意／可比／驗證狀態、基準月薪、追蹤月薪、變化額、個人變化率、結果分類、排除或 HOLD 理由。

建議合成配對明細（後續可用於一致性計算，不能改值不更新所有彙總）：

| 合成 ID | 基準月薪 | 追蹤月薪 | 變化額 | 變化率 | 分類 |
|---|---:|---:|---:|---:|---|
| SYN-0126-01 | 32,000 | 33,000 | +1,000 | +3.1250% | 上升；描述性微幅區間 |
| SYN-0126-02 | 28,000 | 28,500 | +500 | +1.7857% | 上升；描述性微幅區間 |
| SYN-0126-03 | 40,000 | 40,000 | 0 | 0.0000% | 不變 |
| SYN-0126-04 | 36,000 | 37,000 | +1,000 | +2.7778% | 上升；描述性微幅區間 |
| SYN-0126-05 | 30,000 | 29,000 | -1,000 | -3.3333% | 下降 |
| SYN-0126-06 | 45,000 | 46,000 | +1,000 | +2.2222% | 上升；描述性微幅區間 |

核算基準總額 211,000、追蹤總額 213,500、差額 +2,500；加權總額變化率 2,500 ÷ 211,000 = 1.1848%。有效配對 n=6；上升 4/6=66.7%，不變 1/6=16.7%，下降 1/6=16.7%；在本報告描述性 0% 至 +5% 區間的微幅上升為 4/6=66.7%。四捨五入至小數一位；總額變化率四位。這些是完整合成展示值，不能作協會成果。

12 人母數流程也須列清楚，合成分布可設定為：6 筆有效已同意配對；1 筆追蹤期無薪資機會；2 筆未授權納入；1 筆未回覆；1 筆自陳但未驗證（HOLD）；1 筆缺基準薪資。合計 12。不得將 6 筆配對分析結果外推為 12 人或整體學員成果；各排除類別須保留數量與後續補證方式。

## 專屬章節順序

1. 首頁：30 秒內說清目的、讀者、調查週期、結論範圍及 SAMPLE/REAL 狀態。
2. 決策摘要：官方要求、目前可回答問題、樣本與最重要限制。
3. 調查方法：母體、邀請／同意、基準時間、追蹤時間、資料取得方式、薪資可比條件、個資權限。
4. 流程與資料品質：12 人狀態流向、拒答／無回覆／缺值／未驗證處理。
5. 指標與計算：欄位字典、公式、分母、四捨五入、無效配對規則。
6. 合成逐筆表與彙總：逐人重算、上升／不變／下降分類、月薪總額及變化率。
7. 分析圖表：至少一張基準與追蹤薪資配對圖或變化分布圖；圖表數值必須與表格完全一致；小樣本只作描述。
8. 分群／差異：依同一組合成資料分層（例如基準薪資帶）；每格列 n；不得作過度推論。
9. 發現與證據強度：描述結果、可支持主張、不能支持主張、升級 REAL 所需原始文件。
10. 建議與追蹤：具名角色（職務角色，不是真人姓名）、可操作措施、期限、指標、補證責任。
11. REAL 空白調查工具：與合成示範分開，列詢問項目、選項／不答、授權、配對 ID、薪資證明種類、驗證／排除規則；不得預填示範值或簽章。
12. SAMPLE/REAL 替換清冊、來源索引、版本與隱私控制。

## 必備表格與圖

- 欄位字典：欄位、定義、格式、來源、分母角色、驗證方式、敏感程度、缺值處理。
- 12 人資料狀態流向表：每類人數與進入／排除有效配對分母的理由。
- 6 筆合成配對明細表：基準、追蹤、變動額、變動率、分類、可核對的合成定位。
- 計算核對表：各列小計、總額、加權變化率、各類 n/N；可由手算重現。
- 分群比較表：分組定義、基準 n、變動方向、每組限制；避免小樣本誤導。
- 發現—證據—限制—建議—責任角色—期限—追蹤指標閉環表。
- 官方要求—正文頁表定位—使用結果—核對者／日期欄（模板欄位，不預填真實核准）。
- 至少一圖：軸標、單位、期間、n、SAMPLE 標示，且不隱去下降或不變列。

## 遞交／退件門檻

- 任一數字不能從逐筆表重算、混淆有效配對分母與完訓母數、隱藏拒答／缺值／不利結果，立即退件。
- 把描述性微幅區間冒稱官方門檻、把前後差異宣稱為訓練因果、或把合成資料寫成 REAL，立即退件。
- 沒有調查方法、授權／隱私處理、資料品質、完整母數流向、逐步公式、限制、可採取決策或 replacement register，退件。
- 將 I19-E13 職務運用、I19-E16 市場／顧客價值內容混作薪資成果，退件。
- 空白問卷或範本不能取代已完成 SAMPLE 分析案例；反之，SAMPLE 不能冒充 REAL 正式原件。
- DOCX 內容完整後，技術、字級、渲染逐頁視覺、精確 SHA 語意複核各自驗收；任何 PASS 都綁定同一最終 DOCX SHA。

## 事實與權限邊界

REAL 升格至少需原始薪資證明／依法可驗證紀錄、學員明確同意、訓練完成與追蹤連結、資料最小化及存取依據、抽取／計算記錄、合法覆核。薪資是敏感個資；未授權原件不得公開上傳 GitHub。不得偽造真人姓名、薪資單、雇主核章、協會決議或調查已執行之事實。候選狀態標示 `SAMPLE / SYNTHETIC ONLY`、`REAL EVIDENCE NOT PROVIDED`、`FORMAL ACCEPTANCE NOT GRANTED`。

## Crosswalk / rejection of nearest neighbors

- I19-E13 / 0125：職務運用追蹤；不以薪資變動取代是否將所學用於工作。
- I19-E16 / 0127：市場及顧客價值量化效益；不把薪資變化當市場／顧客價值指標。
- Official row source: current `BLUEPRINT_CURRENT.jsonl` row 126; source-row SHA-256 `bc640157d7f6e462de26a1b021af414be182b737319df3573ebbdfed34813cc6`.