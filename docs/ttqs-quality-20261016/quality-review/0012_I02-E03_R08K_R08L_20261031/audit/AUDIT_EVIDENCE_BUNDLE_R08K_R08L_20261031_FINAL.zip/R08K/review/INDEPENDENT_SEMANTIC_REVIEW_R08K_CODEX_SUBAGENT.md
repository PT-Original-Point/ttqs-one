# Independent semantic review — 0012 R08K

Verdict: PARTIAL. This read-only review is bound to candidate SHA-256 `f9fd00602f4a7474247ae9b546a2ea86af57008c7dbcfdeb00e2fc9b146a2aa5`. Reviewer context: Codex subagent `01a190cc-536d-7732-a7e3-c21fa4bd285c` (Hubble), separate from the document builder. Model identity: UNKNOWN. Formal acceptance: NOT GRANTED.

## Finding

- F-02 locator error, §10.3 “受理／完整度” row: the text says the completeness metric is distinct from the “§12” formal-source verification completion rate. That metric is actually in the §10.3 monthly-report metrics table, row “正式來源核驗完成率”; §12 is the synthetic replacement register. The metric distinction is clear, but the cross-reference is wrong. Correct the locator to §10.3 or identify the row directly.

## Other scoped checks

- F-01: the §11.1 three-column table connects the official item to procedure/form fields and sample attachment indexes, distinguishes SAMPLE indexes from REAL source requirements, and specifies UNKNOWN/HOLD for missing evidence. It states that operational fields are the document's design, not extra official requirements.
- F-03/F-04: the §12 SYN-043–068 groupings match the register; the §13 status bullet preserves the SAMPLE/SYNTHETIC, unadopted, unannounced, pending-governance and no-effect boundaries.
- Genre is operational: application and review fields, role separation, decision controls, calculations, notification, appeal and follow-up. The body distinguishes I02-E03 from I02-E02 market positioning and I02-E04 annual course publication, and remains identifiable without its title.
- Sample arithmetic recomputes: E=6,000; U=6,000; B=1,200; remaining sample budget=5,800. P=0 is explicitly an assumption; payment evidence remains UNKNOWN and the case remains HOLD.
- The reviewer inspected the full body, all 18 tables, the 68-entry synthetic register, and header/footer text. R08J-to-R08K changes were checked; the register is text-identical. The parent R08J PASS was inherited only for unchanged content, with its actual model identity UNKNOWN; changed content was reviewed directly.
- Official PDF SHA-256 and Blueprint row SHA-256 match the expected source values. Technical and visual QA were outside this semantic review.

The document remains SAMPLE/SYNTHETIC. This is not evidence of an adopted policy, actual eligibility, authorized rates, budget, approval or actual attachments.