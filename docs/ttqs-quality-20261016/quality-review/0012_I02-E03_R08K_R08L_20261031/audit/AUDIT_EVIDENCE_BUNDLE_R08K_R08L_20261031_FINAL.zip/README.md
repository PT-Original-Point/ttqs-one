TTQS ONE 0012 / I02-E03 audit package for R08K and R08L.

R08K SHA-256: f9fd00602f4a7474247ae9b546a2ea86af57008c7dbcfdeb00e2fc9b146a2aa5; independent semantic result PARTIAL because the §10.3 metric note pointed to §12.
R08L SHA-256: 529bd78f6a0013ac1e42af2b2c0ee854db91d6ceea5925831420617037ea910f; the only DOCX XML change fixes the pointer to §10.3. Technical, Word-native visual and independent exact-SHA semantic results PASS.
Both candidates remain SAMPLE/SYNTHETIC. Formal association acceptance is NOT GRANTED; REAL evidence remains UNKNOWN/HOLD. Worker dispatch failures and original responses are preserved below.
