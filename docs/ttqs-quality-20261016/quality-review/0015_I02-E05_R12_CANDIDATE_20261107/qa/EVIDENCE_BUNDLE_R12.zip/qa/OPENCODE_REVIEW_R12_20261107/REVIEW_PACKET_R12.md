TTQS ONE bounded independent semantic/usability review
work_id: TTQS-0015-W1-SCOPED-SEMANTIC-R12-20261107
project_id: TTQS_ONE
doc_id / requirement_id: 0015 / I02-E05
candidate: 0015_I02-E05_R12.docx
candidate_sha256: c6ffeea28b9bfd28d78ca90724221dbcef600516c647aa12a47fc1ab41cfa96f
candidate_text_projection_sha256: 791b75a8fc2899a7cbb325e861688de6c459f54f31a58dc294383bfd17b5880c
review_scope_projection_sha256: e48d4d4ecd638f39c8b92e852ef79bfcd5e27cff83165cb881c09fed7162624d
parent_candidate_sha256: 2eb5ba8e29662bc9f02bc319ec5a98b1b7c336c59a120613ea661a591b4cb256
source_packet_sha256: 3776e7d9c3378cad23dbe83a246566b352dafbba6fdeece388855b85c19ee477
official_source_pdf_sha256: 805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709
replacement_register_sha256: e9f6a0316c632873ccc1fbc6bad18dd4a0dc912d46a85895a6876be2cc2526b9
blueprint_current_jsonl_sha256: 406d0495365d0970dcf8113a42842663b8a54372a4e204cc492b7c3f8156ef3e
blueprint_seed_142_sha256: 280783e0df4dc0b7aaaf4a8fbe826bc65e9ed9c683146eea1dfd25c0ae1c92e0
blueprint_row_15_current_matches_source_packet: True
blueprint_row_15_sha256_declared_by_packet: e8e2a3cd98d2f5249b72ae9c36b32177682367315b95c39fbb72b794702fd160
blueprint_row_16_id_and_title: 0016 / I02-E05 / 0016__課程EDM完整文案.docx
blueprint_row_16_genre: 專屬佐證紀錄｜課程EDM完整文案
candidate_page_count: 22
candidate_table_count: 19
replacement_register_rows: 81
forbidden_placeholder_phrase_scan_matches: 0

OFFICIAL REQUIREMENT (page 1; exact source text):
客戶提出的課程需求的相關表單 （文件），而揭露的呈現方式， 可以為EDM、海報、網站網頁等方式加以呈現。

UNIQUE BLUEPRINT ROLE FOR 0015:
Title: 0015__客戶需求評估與回覆表.docx
Genre: 分析／評估報告｜客戶需求評估與回覆表
Purpose: 本件專屬焦點：客戶需求評估與回覆表；需直接回應的官方佐證要求為：客戶提出的課程需求的相關表單 （文件），而揭露的呈現方式， 可以為EDM、海報、網站網頁等方式加以呈現。；產出一份可實際執行、可閱讀並可追溯的專屬成品；本分件職責與同要求其他分件清楚分開。
Evidence role: 呈現方法、完整合成或已驗證結果、分析、限制及可追溯決策；不得冒充實績。 本文件只擁有 I02-E05 的直接紀錄／分析口徑；不得吞併其他要求的事實。
Required sections: 摘要、用途與決策問題；官方要求及分析範圍；資料來源、樣本與納入排除；指標定義、分母與計算方法；完整示範資料及逐步計算；分群／趨勢／差異結果；圖表解讀及品質限制；發現、原因與證據強度；結論與可執行建議；責任人、期限與追蹤指標；合成資料聲明及真實替換清單；附件索引、覆核與版本
Required figures/tables: 資料欄位—定義—分母—來源—限制字典；合成明細／彙總結果與逐步計算；分群比較／差距優先排序矩陣；結論—證據—建議—責任—追蹤指標表；官方要求—結果—證據位置—覆核追溯表
Required cross-references: 同要求分件 0014, 0016, 0017；相鄰要求 I02-E04, I03-E01；共用原始來源時只引用核實結果，不複製別份文件正文。

DISTINCT SAME-REQUIREMENT DELIVERABLE 0016:
Title: 0016__課程EDM完整文案.docx
Genre: 專屬佐證紀錄｜課程EDM完整文案
Purpose: 本件專屬焦點：課程EDM完整文案；需直接回應的官方佐證要求為：客戶提出的課程需求的相關表單 （文件），而揭露的呈現方式， 可以為EDM、海報、網站網頁等方式加以呈現。；產出一份可實際執行、可閱讀並可追溯的專屬成品；本分件職責與同要求其他分件清楚分開。
Evidence role: 保存此項要求專屬的原始紀錄或證據索引；不代替第三方原件。 本文件只擁有 I02-E05 的直接紀錄／分析口徑；不得吞併其他要求的事實。

PRIOR R11 FULL REVIEW FINDING (historical):
The R11 reviewer observed that §7.1/Table 13 listed five course units and per-unit hours during a SAMPLE HOLD state. It recommended keeping only the six-hour aggregate feasibility estimate during HOLD, deferring any unit names/hour allocations until HOLD is lifted, and reconciling §9 register facts SYN-057 through SYN-062. The reviewer reported no formal acceptance; actual model was UNKNOWN.

R12 CANDIDATE EXCERPTS — exact text extracted from the candidate bytes:
§3.2 scoring table:
ROW0: 評估面向 | 權重 | SAMPLE 分數 | 算式 | 加權分 | SAMPLE 證據強度與說明
ROW1: 需求與目標對齊 | 20 | 4 | 20 × 4 ÷ 5 | 16 | P；需求成果具體，但沒有真實申請原件
ROW2: 課程設計可行性 | 15 | 4 | 15 × 4 ÷ 5 | 12 | P；僅於硬性關卡核證及有權角色核決通過後，才可提出 6 小時初步架構；仍須實際設計覆核
ROW3: 講師專長與可用性 | 15 | 3 | 15 × 3 ÷ 5 | 9 | M；未提供講師資格或時段證明，僅保留待證條件
ROW4: 時段與執行安排 | 10 | 4 | 10 × 4 ÷ 5 | 8 | P；SAMPLE／SYNTHETIC 情境假設；僅知期望週次，確切日期未定
ROW5: 預算與成本資源 | 15 | 3 | 15 × 3 ÷ 5 | 9 | P；僅有合成估算，不是核價或報價
ROW6: 場地與可近用性 | 10 | 2 | 10 × 2 ÷ 5 | 4 | M；容量、設備和無障礙需求未確認
ROW7: 設備、資料與隱私安排 | 10 | 4 | 10 × 4 ÷ 5 | 8 | P；示範課程採合成練習資料，實案仍須核定資料使用方式
ROW8: 成效檢核與追蹤 | 5 | 4 | 5 × 4 ÷ 5 | 4 | P；成果指標可設計，尚無真實成效資料
ROW9: 合計 | 100 |  | (80＋60＋45＋40＋45＋20＋40＋20) ÷ 5 | 70／100 | 8 項均已評分；已核實真實事實 0／8

§3.3 decision rules:
ROW0: 分數／條件 | 決策 | 必填理由及下一步
ROW1: 80–100 且所有必要關卡有有效證據、權限完成 | 接受 | 界定範圍、日期、價格、期限及允許承諾；只引用已核實證據
ROW2: 65–79，缺口可在明確期限內解除，且僅先行設計不會造成承諾 | 附條件接受 | 逐項列條件、責任角色、期限、解除證據；限制交接範圍
ROW3: 45–64，或決策所需的關鍵需求、授權或資源證據不足以進行下一步 | HOLD | 列出缺件、補件方式、責任角色和重開條件；不得暗示已接案
ROW4: 0–44，或證據已確認需求不能合法／安全／可行地完成且無可接受補救 | 拒絕 | 引用具體證據和理由；可提出縮小範圍或替代方案，但不得承諾替代方案
ROW5: 任意分數，但法律／安全／個資／簽核權限等硬性關卡未過 | HOLD；若已證明無可行補救則拒絕 | 硬性關卡優先於分數；不得用高分抵銷

§7.1 / handoff table:
ROW0: 交接欄位 | SAMPLE 內容 | 僅在重評核准交接後，設計角色回傳
ROW1: 交接鍵／來源 | SAMPLE-HOLD-001；僅供補件追蹤，不是設計交接鍵 | 接收時間、交接包版次及缺件
ROW2: 需求摘要 | Excel 資料整理與視覺化；12 人；6 小時；初階至中階 | 是否理解需求；歧義及需再問事項
ROW3: 需求成果目標（供評估） | SAMPLE 需求目標示例（非課程設計成果）：樞紐分析圖、解讀 3 項 KPI、行動摘要；核實受訓需求後才可轉為課程目標 | 每項成果對應的教學活動及評量證據
ROW4: 可行性總時數估算（非課程設計） | SAMPLE 可行性總量估算：合計 6 小時；此為資源容量參考，不是課程單元設計、派工或交付。HOLD 期間不指定單元名稱或各單元時數。 | HOLD 解除、需求核實並取得有權核決後，才逐項核定單元、時數、活動、教材及總時數；此前不得拆分課程單元或派設計工作。
ROW5: 交付限制 | SAMPLE HOLD；日期、場地、講師、設備及無障礙條件均未核實，不得啟動設計；核證與授權核決完成後重新評估 | 列明能力／資源缺口與解除證據；核證及授權前維持 HOLD，不派設計工作
ROW6: 成本限制 | NT$38,500 未稅為情境估算；不是報價 | 按核准費率重算並提供可核對成本依據；不得沿用 SAMPLE 單價
ROW7: 決策限制 | SAMPLE HOLD；硬性關卡或授權核決未完成；暫不接受，不啟動設計或交接 | 核證關卡並取得有權核決後重判；此前不得設計、定稿、排課、報價、簽約或發布
ROW8: SAMPLE 設計角色回覆示例 | SAMPLE：設計角色未收件、未接受草案或啟動設計；待硬性關卡核證及有權核決後重新判定是否派工 | 實案由實際接收角色回覆「收件／退回」、日期、版本、缺件及責任
ROW9: 回傳期限 | SAMPLE：僅於正式交接後 2 個工作日內回覆收件或缺件；本案 HOLD 期間無設計交接及回傳期限 | 逾期由評估承辦追蹤；期限為流程建議值，實案須改用核准期限

§7.2 context:
本案例目前為 HOLD，尚未完成設計前置交接；補件追蹤鍵不代表設計交接，亦未派發或接受設計工作。只有硬性關卡有來源證據、有權角色完成核決並重新判定可行後，才可建立新交接鍵、指派設計工作並依核准範圍回收回執；此流程完成仍不等於課程定稿或客戶接受。
若設計角色回傳時數不足、成果不可評量、資源不可用或成本超出需求，評估承辦須重開受影響的評分面向，保留原決策，更新證據及版本，再產生新回覆草稿。任何條件解除須附原始證據及覆核；不能只把狀態改成「完成」。

§9 register table relevant rows:
ROW54: SYN-054 | SAMPLE 個案決策：HOLD；硬性關卡及授權核決未核實；暫不接受，不啟動設計或交接 | §3.3、§4、§5、§7 | 真實分數、各項硬性關卡、授權核決及解除條件的來源證據 | 有權核決角色
ROW57: SYN-057 | 已撤銷（R12；舊 SAMPLE 假設不再採用）：HOLD 期間未指定課程單元名稱或各單元時數配置。 | §7.1 | HOLD 解除、需求核實並取得有權核決後形成的正式課程設計版本；逐單元內容與時數核定前不得替換為 REAL。 | 課程設計角色
ROW58: SYN-058 | 已撤銷（R12；舊 SAMPLE 假設不再採用）：HOLD 期間未指定課程單元名稱或各單元時數配置。 | §7.1 | HOLD 解除、需求核實並取得有權核決後形成的正式課程設計版本；逐單元內容與時數核定前不得替換為 REAL。 | 課程設計角色
ROW59: SYN-059 | 已撤銷（R12；舊 SAMPLE 假設不再採用）：HOLD 期間未指定課程單元名稱或各單元時數配置。 | §7.1 | HOLD 解除、需求核實並取得有權核決後形成的正式課程設計版本；逐單元內容與時數核定前不得替換為 REAL。 | 課程設計角色
ROW60: SYN-060 | 已撤銷（R12；舊 SAMPLE 假設不再採用）：HOLD 期間未指定課程單元名稱或各單元時數配置。 | §7.1 | HOLD 解除、需求核實並取得有權核決後形成的正式課程設計版本；逐單元內容與時數核定前不得替換為 REAL。 | 課程設計角色
ROW61: SYN-061 | 已撤銷（R12；舊 SAMPLE 假設不再採用）：HOLD 期間未指定課程單元名稱或各單元時數配置。 | §7.1 | HOLD 解除、需求核實並取得有權核決後形成的正式課程設計版本；逐單元內容與時數核定前不得替換為 REAL。 | 課程設計角色
ROW62: SYN-062 | SAMPLE 可行性總量估算：合計 6 小時；僅作資源容量估算，HOLD 期間未拆分單元時數、不派工、不交付。 | §7.1 | 解除 HOLD 並完成核准後的課程設計版本逐項加總覆核；核准前本估算不代表課程設計或 REAL 資料。 | 課程設計角色
ROW70: SYN-070 | 設計角色未收件、未接受草案或啟動設計；取得證據並由有權角色核決後，重新判定是否派工 | §7.1 | 實際交接系統紀錄及設計角色回覆；不得把示範回執當實際交接 | 評估承辦／設計角色

CURRENT EXTERNAL REPLACEMENT REGISTER ROWS:


REVIEW QUESTIONS (limited to the change/dependency scope):
1. Is the prior R11 concern closed without leaving a course-unit allocation or design assignment during HOLD?
2. Is the six-hour value clearly only a SAMPLE capacity estimate, consistently aligned across §3.2 scoring, the decision gate, §7.1/§7.2, and §9 register?
3. Do retired SYN-057..SYN-061 and current SYN-062/SYN-070 read consistently between DOCX and replacement register, without contradictory active facts?
4. Does the sample decision and text preserve HOLD, authorization and SAMPLE/REAL boundaries, and avoid implying the course was designed, accepted, published or performed?
5. Does the 0015 evaluation/reply role remain distinct from 0016's EDM copy role?

ROLE / STOP CONDITIONS:
Independent read-only scoped review. Do not edit any files. Do not claim an independently verified candidate hash: candidate and projection hashes above were computed by the dispatcher from local bytes. Do not re-review unchanged unrelated sections; do not declare whole-document acceptance or TTQS formal acceptance. Return exactly one verdict: PASS_SCOPED or REPAIRABLE. If REPAIRABLE, give each actionable issue with exact table/section locator, severity and minimum repair. Record any ambiguity as UNKNOWN, not PASS.
