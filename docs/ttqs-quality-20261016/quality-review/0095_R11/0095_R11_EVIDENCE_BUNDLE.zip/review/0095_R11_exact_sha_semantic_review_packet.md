# DOCX 0095 R11 exact-SHA independent semantic review packet

## Binding and limitations

Project TTQS_ONE; DOCX 0095 = official I18-E02; official checkbox: 建立目標客戶及學員滿意度調查機制（系統及流程面）。 This is a CANDIDATE only. DOCX SHA-256: 6fa3f1e3eed3827eb40d7f6916d3e759b2abd3ca8c9dd7525f0dd084df22f420 (263773 bytes). Word-exported PDF SHA-256: 7c2a636b2dd58586366055914eeda5ddf3bb22aa36d2d40e0e962bda35f375d6 (44 pages). Manuscript SHA-256: 8e861e06011d9e7f214533e7ba14d75f58352a77bbfb559cd606a8772f7f2955. Synthetic replacement register SHA-256: df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee (211 data rows). Manifest SHA-256: 45357ed001e8720a129883924630e9d8125f9dc9e0a9f7fd1cefc2d774008c28. Official requirement extract SHA-256: e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02. Official indicator-18 scoring extract SHA-256: c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf. Unique Blueprint row SHA-256: 9a22b3acd4bdafb15f18c15ee89088f4fb5ee334bfef9a1917fcc5740b7979c2. Source binding SHA-256: a7d21355b9ff0d9510ab0c5f178ac0d9f2560cb2adb96be8135530a5c0fd5efc.

This review is packet-only: reviewer receives extracted manuscript/PDF text and evidence below, not binary file access. Do not claim independent DOCX/PDF rehashing, file-system access, re-rendering, visual inspection, or provider identity attestation. Candidate exact SHA is the supplied review target and must be echoed exactly to bind the verdict.

## Review task and rubric

Independently review this current R11 candidate against official I18-E02 and the unique Blueprint. Do not inherit builder PASS or prior review verdicts. Read the full packet. Return JSON only. Use PASS only if no material semantic defect remains in supplied evidence; PARTIAL if a material/evidence-limited issue remains; FAIL for wrong official requirement/genre, material contradictions, unsupported REAL claims, unsafe forms, or unusability. Candidate remains CANDIDATE, not formal acceptance.
Check: (1) requirement/checkbox/ID/genre binding, title-blind identifiability, and separation from negative neighbors 0094/I18-E01 and 0096/I18-E03; (2) system/process satisfaction survey mechanisms for target customers and learners, including sampling frames, invitation/delivery/return, validity, scales, N/A, withdrawn/incomplete, privacy, aggregation, reporting and hold/reject criteria; (3) whether two respondent populations stay distinct and whether every calculation has correct numerator, denominator, rounding, suppression, and missing-data rules; (4) whether the mechanism is directly usable by a small volunteer association, with realistic blank REAL fields and proposed controls clearly not represented as implemented; (5) all 211 register keys, categories, arithmetic and §10 reconciliation, including 205 retained from R06, three retired pooled/combined metrics, six added UNKNOWN classes, 53 derived synthetic metrics; (6) spot-check register page locators against the supplied current 44-page PDF text, especially prior R09 findings and the 13 R11 locator corrections; (7) cross-document case consistency and SAMPLE/SYNTHETIC vs REAL boundaries; no invented association approvals, signatures, people, execution, or third-party originals; (8) all prior R08/R09/R10 material findings and R11 patch response—disposition each with exact current section/page/table/key locator, or mark UNKNOWN if evidence insufficient; (9) mathematical consistency and practical rejection/hold conditions; (10) remaining material contradictions, omissions, or unsupported claims.
Return a single JSON object with keys: overall_verdict, reviewed_docx_sha256, review_scope, criteria (array of {criterion,verdict,exact_locator,finding}), prior_finding_disposition (array of {id,disposition,exact_locator,rationale}), blocking_findings, nonblocking_findings, material_arithmetic_checks, unknowns, reviewer_limitations, provider_model_identity. Echo reviewed_docx_sha256 exactly or verdict is unbound.

## Official requirement page 6

6 
項目 評核指標項目 
內涵說明（以下為
例，但不以此為
限） 
常見參考佐證資料 
（並註明資料來源及頁碼） 
3分 依修正決定，
進行課程改善有具
體成效。 
 其他： 
17b 
學習
評估 
0分 未執行。 
1分 執行考試或實作
評量。 
2分 有考試或實作報
告或其他具體學習，
將結果及缺失彙整分
析納入結案報告中，
作為下次課程規劃之
修正依據。 
3分 依修正決定，進
行課程改善有具體成
效。 
 考試紀錄、學員心得報告、照片
與紀錄、訓後學員職涯規劃建議
表。 
 對課程評量及學員建議進行檢討
與紀錄。 
 結案報告書、課後訓練機構的課
程檢討行動計畫查核紀錄。 
 其他： 
17c 
行為
評估 
0分 未執行。 
1分 協助客戶執行課
後行動計畫評估。 
2分 有機制並能展現
辦理或追蹤客戶執行
之相關紀錄。 
3分 相關紀錄能展現
具體成效。 
 學員訓後動態調查表。 
 參訓學員 的學習成果實施行動計
畫表追蹤紀錄。 
 派訓單位主管對參訓學員的學習
成效評估表。 
 知識管理社群討論。 
 神秘客實地稽核 （外部稽核 ）課
後機制等。 
 其他： 
17d 
 成果評
估 
0分 未執行。 
1分 協助客戶評估訓
練成效是否達成組織
或工作之需求。 
2分 有機制並能展現
辦理或追蹤客戶評估
之相關紀錄。 
3分 相關紀錄能展現
具體成效。 
 訓後調查表。 
 就業及考照追蹤紀錄。 
 品質不良率下降統計表。 
 派訓單位主管對參訓學員的學習
成效評估表。 
 學員就業證明。 
 感謝函。 
 學員訓後雇主問卷調查表。 
 其他： 
 
18.訓練系統的一
般性功能─目標
客戶及學員的評
價 
評分標準： 
1分 目標客戶及學員
認為訓練有部分效
果，然而未有具體紀
錄及評量。 
2分 目標客戶及學員
認為訓練有達成能力
提升的效果。 
3分 目標客戶及學員
認為訓練有績效改善
1分之常見參考佐證資料： 
 口述目標客戶及學員認為訓練有
其功能，僅有滿意度調查，但未
有具體紀錄及評量。 
 建立目標客戶及學員滿意度調查
機制（系統及流程面） 。 
 感謝函。 
 其他： 
2分之常見參考佐證資料： 
 問卷調查等顯示目標客戶及學員

## Official scoring form indicator 18 page 4

行之相關紀錄。
                         3分 相關紀錄能展現具體成效。
            17d 成果評估     0分 未執行。
                         1分 協助客戶評估訓練成效是否達成組
                         織或工作之需求。
                         2分 有機制並能展現辦理或追蹤客戶評
                         估之相關紀錄。
                         3分 相關紀錄能展現具體成效。
         18. 訓練系統的一般性功   評分標準：
         能               1分 目標客戶及學員認為訓練有部分效
         ─目標客戶及學員的評價     果，然而未有具體紀錄及評量。
                         2分 目標客戶及學員認為訓練有達成能
                         力提升的效果。
                         3分 目標客戶及學員認為訓練有績效改
                         善的效果。
                         4分 目標客戶及學員認為訓練有顯著具
                         體績效。
         19. 訓練系統的市場功能   評分標準：
         ─目標市場及顧客的價值     1分 目標市場及顧客價值均有提升，然
         創造              而未有具體紀錄及評量。
                         2分 目標市場及顧客價值均有部分提升
                         效果。
                         3分 目標市場及顧客價值均有一定程度
                         提升的效果。
                         4分 目標市場及顧客價值均有顯著具體
                         的提升績效。
額外加分     1.於「上次通過評核日起至本次接受     TTQS評核日」期間，通過職
          能導向認證之課程，每通過1門加0.5分。
         1.於「上次通過評核日起至本次接受     TTQS評核日」期間，持續辦
          理取得職能導向認證之課程，每辦理1班加0.5分，每門職能導向
          認證課程以辦理1班為限。
         2.以上額度外加分機制每次評核最高加2分。

總分

評核委員簽名                         評核委員簽名








                              4

## Unique Blueprint row and source binding

```json
{
  "deliverable_id": "0095",
  "requirement_id": "I18-E02",
  "final_filename": "0095__建立目標客戶及學員滿意度調查機制（系統及流程_分析報告.docx",
  "document_genre": "分析／評估報告｜建立目標客戶及學員滿意度調查機制（系統及流程_分析報告",
  "document_purpose": "本件專屬焦點：建立目標客戶及學員滿意度調查機制（系統及流程_分析報告；需直接回應的官方佐證要求為：建立目標客戶及學員滿意度調查機制（系統及流程面）。；產出一份可實際執行、可閱讀並可追溯的專屬成品；本分件職責與同要求其他分件清楚分開。",
  "primary_user_or_reader": "供主管與決策者讀取資料、理解計算、判斷差距並採取具體決策。",
  "evidence_role": "呈現方法、完整合成或已驗證結果、分析、限制及可追溯決策；不得冒充實績。 本文件只擁有 I18-E02 的直接紀錄／分析口徑；不得吞併其他要求的事實。",
  "source_of_truth": "官方查核佐證表精確原文『建立目標客戶及學員滿意度調查機制（系統及流程面）。』，表內頁次 6，讀取狀態 PDF_TEXT_EXACT_PAGE_MATCH；REQ_157_MAP 對應 I18-E02；本行文件名稱與 ID 以 R04 142 交付 crosswalk/seed 為準。Phase2 歷史 Blueprint 僅作需求拆解參考，絕非可複製正文或現行標題權威。",
  "required_sections": "摘要、用途與決策問題；官方要求及分析範圍；資料來源、樣本與納入排除；指標定義、分母與計算方法；完整示範資料及逐步計算；分群／趨勢／差異結果；圖表解讀及品質限制；發現、原因與證據強度；結論與可執行建議；責任人、期限與追蹤指標；合成資料聲明及真實替換清單；附件索引、覆核與版本",
  "required_tables_or_figures": "資料欄位—定義—分母—來源—限制字典；合成明細／彙總結果與逐步計算；分群比較／差距優先排序矩陣；結論—證據—建議—責任—追蹤指標表；官方要求—結果—證據位置—覆核追溯表",
  "required_fields_or_questions": "分母是誰？；資料來自何處？；未回覆如何處理？；此成果能否合理歸因於訓練？；本文件中哪一段/哪一表直接證明：「建立目標客戶及學員滿意度調查機制（系統及流程面）。」？；目前證據強度對應哪一分級？缺什麼資料才可升到下一級？；分析母數及排除說明；計算口徑與四捨五入；建議決策及適用限制；合成事實替換登錄鍵",
  "required_calculations_or_analysis": "成果率=符合成果人數/可評估人數；變化率=(後測或後期-前測或前期)/前測或前期；滿意度正向率=4–5分有效回答/有效回答總數。不得稱為組織實績。",
  "required_cross_references": "同要求分件 無；相鄰要求 I18-E01, I18-E03；共用原始來源時只引用核實結果，不複製別份文件正文。",
  "real_data_required": "升格為 REAL 前逐項取得可核實來源：正式日期；真實人名/角色；核准/簽章；真實班次/課程；實際數字/比例；真實附件與檔案位置。在無原件時標示 SAMPLE/SYNTHETIC；合成事實須登錄 replacement register，不得宣稱機構實績。",
  "third_party_evidence_required": "若結論依賴外部機關／第三方／真人正式簽章或證書，必須由合法來源取得可核對原件；本文件可提供清楚索引與合成流程示範，絕不代製、仿簽、補作或冒充第三方正式原件。",
  "prohibited_fabrication": "不得把擬真工作稿標成REAL；不得偽造核准、簽章、真人參與、辦訓、成績、成果或不存在的外部事實。；不得將舊檔內容、示範數據、未查證Drive候選或歷史草案標成 REAL；不得偽造核准、簽章、真人參與、辦訓、成績、成果、外部證據或來源定位。",
  "title_blind_test": "遮蔽本件標題、檔名與編號，只讀正文應可由專屬機制辨認為『建立目標客戶及學員滿意度調查機制（系統及流程_分析報告』並證明『建立目標客戶及學員滿意度調查機制（系統及流程面）。』；若可無修改移作其他要求即失敗。",
  "negative_choice_neighbors": "0094《口述目標客戶及學員認為訓練有其功能，僅有滿意_可直接使用成品》（I18-E01）：應證明不同工作物；本件不得代替、合併或複製其專屬事實。\n0096《感謝函_可直接使用成品》（I18-E03）：應證明不同工作物；本件不得代替、合併或複製其專屬事實。",
  "acceptance_tests": "移除標題及檔名後，讀者可由正文專屬欄位、操作或分析辨認為『建立目標客戶及學員滿意度調查機制（系統及流程_分析報告』，且能指出直接回應『建立目標客戶及學員滿意度調查機制（系統及流程面）。』的頁節／表格。\n逐項呈現官方要求、資料來源、記錄欄位、判定、證據定位及覆核；官方原文不被歷史草案改寫。\n依本文件文類實際可用：問卷含題目選項量尺；SOP含角色、輸入、判斷、控制點、異常和輸出；會議紀錄含議題、證據、決議、責任、期限；報告含資料、分母、公式、逐步計算、限制和決策。\n若沒有可驗證 REAL 資料，提供前後一致、完整填入的 SAMPLE/SYNTHETIC 案例；不得用空表、待填、待核或未來式充當完成品。\n每一項合成日期、角色、數字、比例、金額、決議、來源路徑與結果皆有逐事實替換簿記錄鍵、所在文件／頁表／欄位及真實替換方式。\n絕不偽造第三方原件、真人簽名、核准、出席、證書、政府、銀行、會計或外部機構事實；需要該等原件時只說明所需原件與取得路徑。\n所有公式可由展示數據重算；分母、單位、期間、四捨五入及N/A條件清楚，交叉引用不重複創造相異版本。\n對照負向鄰項，正文可拒絕至少兩個錯誤近鄰；指出可核對的差異欄位或章節。\n首頁30秒內說明目的、讀者、使用時點、操作、輸出和SAMPLE／REAL狀態；無評核工程內部術語。\n正文可供日常協會作業及評核閱讀；標題層級、欄位、步驟、表格能直接執行，無複製同儕 DOCX 正文。\n字體下限：正文至少10.5pt、表格至少9.5pt；資訊不足時加頁，不縮小字體。\n來源定位與交叉引用使用本 Blueprint 登錄的官方頁次／文件 ID；所有結論不超出來源支持範圍。",
  "document_role": "analysis_report",
  "official_requirement_text": "建立目標客戶及學員滿意度調查機制（系統及流程面）。",
  "official_checkbox_text": "建立目標客戶及學員滿意度調查機制（系統及流程面）。",
  "official_evidence_table_page": "6",
  "official_source_readback_status": "PDF_TEXT_EXACT_PAGE_MATCH",
  "official_visually_checked_pages": "",
  "requirement_deliverable_siblings": "0095",
  "docx_body_template_policy": "FROM_SOURCE_ONLY; old body is discovery evidence only and prohibited as rebuild template; Wave005 R3 0031-0040 quality-height references only; Wave001-004 tainted; old Wave005 invalid; Wave006 prohibited.",
  "synthetic_population_rule": "缺 REAL 即生成完整連貫 SAMPLE/SYNTHETIC worked example；事實粒度一筆一列登錄 SYNTHETIC_REPLACEMENT_REGISTER，含值、類型、定位、替換原件與責任；不得留待填或冒充 REAL。",
  "historical_blueprint_source": "f8f4f12faffcc159f4c6b25755f3facce321e28544ae314f48d948052cfbe63e",
  "historical_body_use": "PROHIBITED",
  "source_map_notes": "129 exact official requirement rows + reconciled 142-ID crosswalk; official source PDF and exact Drive readback evidence are recorded in runtime SOURCE/CONTROL maps."
}
```

```json
{
  "project_id": "TTQS_ONE",
  "doc_id": "0095",
  "requirement_id": "I18-E02",
  "official_checkbox": "建立目標客戶及學員滿意度調查機制（系統及流程面）。",
  "official_source_page": 6,
  "queue_state": "PENDING",
  "queue_attempts": 0,
  "blueprint_row_sha256": "9a22b3acd4bdafb15f18c15ee89088f4fb5ee334bfef9a1917fcc5740b7979c2",
  "official_page6_excerpt_sha256": "e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02",
  "official_source_pdf_sha256": "805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709",
  "writer_packet_sha256": "7bd986c0ca304f14d48aeab7f30cb32eb946805ff3d45e6fb2bcd3104721ca20",
  "state": "READY_FOR_TEXT_ONLY_WRITER_DISPATCH",
  "truth_boundary": "SAMPLE/SYNTHETIC only; actual association system and records UNKNOWN / NOT PROVIDED",
  "neighbor_binding": {
    "0093": "I17D-E07",
    "0094": "I18-E01",
    "0096": "I18-E03"
  }
}
```

## R08 historical independent review and R09/R10 finding histories

```json
{
  "R08_response": {
    "overall_verdict": "PARTIAL",
    "reviewed_docx_sha256": "e9322191eb70554311f506db2eedf0800c1e786012a6b854cbe4b31864ce31a1",
    "review_scope": "Packet-only independent semantic review of DOCX 0095 / I18-E02 R08 candidate, performed without shell, filesystem, browser, GUI, DOCX-binary rehash or independent visual inspection. All verdicts are derived from the packet-supplied R08 Word-exported PDF text (43 pages), the supplied R08 replacement-register CSV body, the supplied manifest, the Unique Blueprint and source binding, and the R07 historical finding list. The DOCX SHA-256 e9322191…ce31a1 is bound as the item under review as supplied by the packet; the reviewer did not and cannot independently rehash the DOCX binary. Reviewer re-derived every quantitative claim from the raw rows displayed in §6.1, §6.2 and §6.4 and re-verified register arithmetic from the CSV body reproduced in the packet.",
    "criteria": [
      {
        "criterion": "1. Requirement and genre: official I18-E02 wording, DOCX 0095 mapping, analysis-report genre, title-blind identification, separation from 0094/I18-E01 and 0096/I18-E03",
        "verdict": "PASS",
        "exact_locator": "§1.2 PDF p.2; §1.3 PDF pp.2–3; §1.4 PDF p.4; §9.1–§9.4 PDF p.38; document header/狀態宣告 PDF p.1; §10.2 PDF p.43",
        "finding": "The official checkbox text 建立目標客戶及學員滿意度調查機制（系統及流程面）。 is quoted verbatim in §1.2 (PDF p.2) with official page 6, readback status PDF_TEXT_EXACT_PAGE_MATCH and source SHA 805386b7…4709, and the official indicator-18 score bands1–4 are quoted verbatim in §1.3 (PDF p.2) with a distinct source SHA 9d253829…83684 and an explicit statement that the two official documents have different roles (p.2) — matching the packet's two distinct official extracts. DOCX 0095 / I18-E02 mapping is stated at PDF p.1, p.2 and p.4. Genre is analysis/evaluation report with proposal status declared in the 狀態宣告 block (p.1). Title-blind identification holds: the body is full of mechanism-specific artefacts no other requirement would carry (dual-track Tool-A/Tool-B instruments, LEARN_*/CUST_* field dictionary, POP_INVITED/POP_RETURNED/POP_VALID counting boundaries, §6.3.3 分軌 restriction, §9.3/§9.4 neighbour deltas). Separation from 0094 and 0096 is explicit at §1.2 (p.2), §9.1 (p.38), §9.3 and §9.4 (p.38), and the document states it does not reproduce, replace or fabricate their artefacts."
      },
      {
        "criterion": "2. Unique Blueprint: required sections, tables/figures, required questions, worked case, traceability, direct usefulness, acceptance tests; whether the R07 missing-figure issue is resolved and whether the figure is interpreted without merging populations",
        "verdict": "PASS",
        "exact_locator": "§7.2 附圖 A PDF pp.33–34 (title, panel content, 呈現規則, 警示, 資料界限, alt text); §1–§10 PDF pp.1–43; §5.1/§5.2 PDF pp.20–22; §6.3 PDF pp.27–28; §8.4/§8.5 PDF pp.36–38; §9.5 PDF pp.39–41; §10 PDF pp.41–43",
        "finding": "The R07 no-figure issue (NB-R07-09) is resolved in R08: §7.2 附圖 A (PDF pp.33–34) now specifies a two-panel positive-rate bar comparison on a shared 0–100% axis with per-panel n labels, explicit rendering rules (no threshold/target/trend lines; panels distinguished by title/position/labels, not colour alone), an explicit non-merge warning and a text alternative. The figure is interpreted without merging populations: the 警示 block states the two tracks have different n (14 vs 5) and must not be combined, weighted or compared across tracks, and the customer panel's five equal 80.0% bars must not imply an ordering. All Blueprint required_sections are present (§1 summary/scope/official mapping; §2 scope; §3 sources/sample; §4.3 field dictionary; §5.1/§5.2 denominators and formulas; §6 worked example with step arithmetic; §7 group/trend/gap results; §7.3/§7.4 figure interpretation and quality limits; §8.4/§8.5 findings, owners, deadlines, metrics; §9.5/§10 synthetic declaration, replacement list, attachment index, review and version). Required tables are present (field dictionary §5.1; raw detail + step-by-step §6.1–§6.4; priority matrix §7.2; tracking table §8.5; official-requirement-to-evidence table §1.4). Required questions are answered: denominator (§5.1), source (§3.2/§9.5), nonresponse handling (PDF p.9, p.20, §6.1), attribution boundary (§7.4, p.34), direct-evidence pointer (§1.4 row 1 and §9.5), evidence-strength ladder (§1.3, pp.2–3), rounding (§5.2, p.22), replacement-register keys (§10). The acceptance test forbidding merged populations is met: §6.3.3 (PDF p.28) was rewritten to forbid aggregating or cross-comparing learner and customer results, and three combined/pooled derived keys were retired from the register (manifest retired_r08_rows; §10 and §10.1 note on p.41)."
      },
      {
        "criterion": "3. R07 finding closure: independent reassessment of all ten historical findings against R08 evidence",
        "verdict": "PARTIAL",
        "exact_locator": "See r07_finding_disposition array; R08 evidence at §1.4 PDF p.4, §4.1 PDF pp.10–11, §4.2 PDF pp.14–15, §7.1 PDF p.31, §7.2 PDF pp.31–33, §6.3.2 PDF p.28, §10/§10.1 PDF pp.41–42, §10.2 PDF pp.42–43",
        "finding": "Eight of the ten R07 findings are closed in R08 (NB-R07-02, -03, -04, -05, -06, -07, -09, -10), one is partially closed (NB-R07-01: the §1.4 locator rows were re-anchored but the new spans are now inconsistent with the current pagination and with the document's own section locations — see the criterion-9 finding), and one remains open as an evidence-bound item (NB-R07-08: register/manifest lineage and the R06 208-row base remain producer-asserted and unverifiable without filesystem or binary access). NB-R07-08 in isolation is informational, but the newly introduced §1.4 page-span drift is a live, reproducible locator defect and keeps the overall disposition PARTIAL."
      },
      {
        "criterion": "4. Numerical integrity: recomputation of populations, invitation/return/valid counts, item sums/means, 4–5 positive counts/rates, rankings, gap calculations, follow-up outcomes, denominators, rounding, missingness, suppression",
        "verdict": "PASS",
        "exact_locator": "§6.1 raw matrix PDF pp.24–25; §6.2 raw matrix PDF pp.25–26; §6.3.1 PDF p.27; §6.3.2 PDF pp.27–28; §6.4/§6.4.1 PDF pp.29–30; §7.1 PDF p.31; §7.2 PDF pp.31–33; §5.2 rounding rules PDF p.22",
        "finding": "All displayed values recompute exactly from the supplied raw rows. Learner (n=14 valid): L-01 sum 57 mean 4.07 positive 11 → 78.6%; L-02 sum 56 mean 4.00 positive 11 → 78.6%; L-03 sum 55 mean 3.93 positive 10 → 71.4%; L-04 sum 56 mean 4.00 positive 11 → 78.6%; L-05 sum 58 mean 4.14 positive 12 → 85.7%. Customer (n=5): C-01 sum 21 mean 4.20 positive 4 → 80.0%; C-02 sum 20 mean 4.00 positive 4 → 80.0%; C-03 sum 20 mean 4.00 positive 4 → 80.0%; C-04 sum 21 mean 4.20 positive 4 → 80.0%; C-05 sum 21 mean 4.20 positive 4 → 80.0%. Rates: learner return 15/18 = 83.3%, validity 14/15 = 93.3%, customer return 5/6 = 83.3%, validity 5/5 = 100.0%, customer valid-return share 5/6 = 83.3%. Follow-up: Σpre51, Σpost 85, n=12, Δabs 2.83, Δrel 66.7%, pass 9/12 = 75.0%; the 12 + 2 = 14 reconciliation holds. Rounding follows the §5.2 rule (means/Δabs 2 dp, rates/Δrel 1 dp, no re-rounding of intermediates). Positive-count enumerations in §6.3.1 match the raw matrix member-by-member. §7.2 gaps recompute against the stated group baselines (learner L-0585.7%/4.14 → L-03 gap 14.3 pp and 0.21; L-02/L-04 7.1 pp and 0.14; L-01 7.1 pp and 0.07; customer C-02/C-03 0.0 pp and 0.20). The §7.2 scenario (excluding SYN-L14: n=13, sum 53, mean 4.08, 10/13 = 76.9%, gap 8.8 pp and 0.07) recomputes correctly. The dense-rank rule (2)(3)(4) is applied consistently and yields P1 L-03, P2 L-02/L-04, P3 L-01, P4 L-05 and, for the customer track, P1 C-02/C-03, P2 C-01/C-04/C-05. N/A and missingness are never treated as zero (§4.3 p.19; §5.1 p.20; §6.4 p.29 states the 2 unpaired cases are excluded, not scored as failures). The 2 unpaired learners are correctly excluded from the paired denominator (12, not 14). Suppression rule n<5 is stated as a proposal and is not violated by any published sub-result. No unlike groups are combined anywhere in the analysis; the three pooled keys were retired."
      },
      {
        "criterion": "5. Instruments and operations: usability of Tool-A and Tool-B, consent/notice, eligibility, scale, N/A, blank/incomplete/withdrawn/invalid/valid states, dated delivery/return, delivery window/reminder, population boundaries, privacy/storage, aggregation, hold/reject criteria, proposed-vs-implemented distinction",
        "verdict": "PASS",
        "exact_locator": "§4.1 PDF pp.10–13 (consent block p.10; field partition p.10; REAL blank 班次編號/培訓日期/實際填答日期 p.11; 5-point scale + N/A p.11; item matrix L-01–L-05 + Q-06/Q-07 p.12; eligibility check 受評者是否實際參與本次課程 p.12; completeness + 回收後表單處理狀態 p.13); §4.2 PDF pp.13–17 (consent p.14; 目標客戶／聯絡窗口代碼 REAL blank + 填答人角色 p.14; 指定目標客戶聯絡窗口 qualification + 邀請發送日期／送達日期／實際填答日期／回收日期 REAL blanks p.15; C-01–C-05 + Q-06 p.16; completeness + status codes p.16–17); §2.2 stages4–6 PDF p.5; §3.2 PDF pp.7–8; PDF p.9 counting-boundary block; §5.1 PDF pp.20–21; §8.1 PDF p.35; §8.2–§8.3 PDF p.35",
        "finding": "Both instruments are usable as-is: consent/notice blocks on p.10 and p.14, a stated 5-point scale with N/A (p.11, p.16), two-page assembly warnings (p.11, p.15), free-text items, a respondent role field and a designated-contact qualification field (p.14–15), manager-only validity block with 撤回／待補正之未完成／無效／有效 as an explicit mutually exclusive single choice plus a NONRESPONSE instruction that must not be selected on the form (p.13, p.17), REAL blank date fields on both tools (p.11, p.15), and a hold/reject mechanism in §3.2 P-04/P-05/P-06 and §8.1 (hold, exclude-single-form, suppress-subgroup, do-not-promote-to-REAL rows). The delivery window and reminder are stated as proposals with explicit non-assertion (p.9, p.1, §2.2 stage 4). Population boundaries, privacy, storage and retention are handled as UNKNOWN/proposals (§2.4 p.6; §8.3 p.35). Every proposed control is separated from an implemented system by explicit language (文件狀態宣告 p.1; §1.1 p.1; §2.4 p.6; §5.1–§5.2 p.20–22; §6 p.23; §8.1 p.35; §10.2 p.43)."
      },
      {
        "criterion": "6. SAMPLE/REAL boundary and replacement register: no fabricated association/third-party facts, synthetic facts visibly marked, register rows reconcile to claims, missing REAL evidence remains UNKNOWN with a safe replacement path",
        "verdict": "PASS",
        "exact_locator": "文件狀態宣告 PDF p.1; §4.1 p.10 (三區塊說明); §4.1 p.11; §4.2 p.14–15; §6 p.23; §8.1 p.35 (不得升格 REAL row); §9.5 pp.39–41; §10 p.41; §10.1 pp.41–42; §10.2 p.43; register CSV body (all rows) and manifest",
        "finding": "No association people, signatures, approvals, courses, respondents, decisions or storage locations are asserted. Roles are labelled PROP-0095-ROLE-CRD/COL/ANL/DEC and explicitly stated as candidate functional labels, not persons (§3.1 p.6; §9.5 row 1 p.39; §10.2 p.43). Synthetic values (SYN-TRN-01, 2026-07-11, 2026-08-10, 6 hours, the 19 respondent rows, 24 paired scores) are labelled SAMPLE/SYNTHETIC at every occurrence, and the two forms print REAL blank fields for the class number, training date, response date and (Tool-B) dispatch/delivery/return dates. The register body reconciles to the claims: each learner score row maps 1:1 to a §6.1 cell (70 rows), each customer score row to a §6.2 cell (25 rows), 24 follow-up rows to §6.4, and 40 derived keys (20 learner + 20 customer SUM/MEAN/POSN/POSRATE) to §6.3.1–§6.3.2; 13 UNKNOWN keys cover organisation, respondent roles, nonresponse reasons, invalid form identity and other scores, real system, real responses, author/reviewer identity, approval/signature, formal effective date, real course/cohort, improvement originals, and attachment/storage location. Every UNKNOWN key carries real_source_status NOT_PROVIDED and a replacement instruction. No third-party original, signature, certificate, government/bank/audit fact or organisation name is fabricated."
      },
      {
        "criterion": "7. Actionability and decision value: usable SOP, data dictionary, calculations, risks, ranked priorities, decision criteria, owner/deadline/metric fields and follow-up; recommendation versus authorisation/completed execution",
        "verdict": "PASS",
        "exact_locator": "§3.1 p.6; §3.2 P-01–P-10 pp.7–8; §2.3 p.5–6; §5.1–§5.2 pp.20–22; §6.3–§6.4.1 pp.27–30; §7.2 pp.31–33; §8.1–§8.3 p.35; §8.4 PDCA 五階段 pp.36–37; §8.5 pp.37–38; §9.5 pp.39–41",
        "finding": "The report supplies a ten-step SOP with inputs, controls, outputs and hold/reject criteria (§3.2), a nine-field data dictionary with denominator/numerator/source/exclusion limits (§5.1), six reproducible formulas with rounding and N/A guards (§5.2), a fully worked step-by-step example (§6.3, §6.4.1), a reproducible ranking rule with displayed ranks, gap metrics and a single-observation sensitivity note (§7.2 p.33), risk and control boundaries (§8.1–§8.3), a five-stage PDCA with stage-entry conditions and hold/close criteria (§8.4), and a fill-in tracking table with separate responsibility-function, owner, deadline and status fields plus field-entry rules and three blank TRK rows (§8.5 p.37). Recommendation is kept distinct from authorisation and execution throughout (p.1, p.2, p.6, p.35, p.38, p.43), and §8.4/§8.5 explicitly record cause and adoption as UNKNOWN."
      },
      {
        "criterion": "8. Negative-neighbour and title-blind test: can the body be repurposed unchanged to 0094 or 0096; concrete body-level distinctions; at least two wrong neighbours rejected",
        "verdict": "PASS",
        "exact_locator": "§1.2 p.2; §2.1–§2.4 pp.5–6; §3.1–§3.2 pp.6–8; §4.1/§4.2 pp.10–17; §4.3 pp.17–19; §5.1–§5.2 pp.20–22; §6.3.3 p.28; §9.1 p.38; §9.3 p.38; §9.4 p.38",
        "finding": "The body cannot be repurposed to 0094 (口述訪談／評量工具，I18-E01) or 0096 (感謝函, I18-E03) without modification. 0094 would require oral-interview records and an assessment instrument; 0095 contains a dual quantitative survey mechanism, a formula library, a ranking matrix and an abstract analysis-report genre, with §9.3 expressly stating it does not pass interview statements, interviewees or real oral material off as this report's survey results. 0096 would require a thank-you letter with an issuer and an original; 0095 is a mechanism analysis with §9.4 expressly refusing to impersonate, manufacture or back-fill 0096's original. Two wrong neighbours are rejected in the body with checkable differences (§9.3 and §9.4, both at p.38), plus a third non-neighbour distinction for 0093/I17D-E07 marked as an unverified internal index only (§9.1–§9.2 p.38). This satisfies the Blueprint acceptance test 對照負向鄰項…正文可拒絕至少兩個錯誤近鄰."
      },
      {
        "criterion": "9. Cross-reference and traceability: page locators against the supplied 43-page export, CSV row keys versus claims and appendix, official/source/Blueprint anchors, version history, and no stale R07 locations cited as current",
        "verdict": "PARTIAL",
        "exact_locator": "§1.4 evidence-locator table PDF p.4 (row 1 third column; row 2 third column; row 3 third column; row 4 third column); §9.5 row 3 PDF p.39; §10 R08 補充說明 (3) PDF p.41; §1.2 PDF p.2; §1.3 PDF pp.2–3; §10.2 PDF pp.42–43; register CSV document_location column; manifest page_locator_basis",
        "finding": "Official anchors are correct and current: §1.2 gives the official source PDF SHA805386b7…4709 and page 6; §1.3 gives the scoring-form SHA 9d253829…83684 and page 4, with the two documents' different roles made explicit (p.2), so the R07-era ambiguity does not persist. The Blueprint row SHA 9a22b3ac…97c2 matches the supplied binding exactly. §9.5 row 3 and the register key UNK-0095-UNK_FORMAL_EFFECTIVE_DATE now point to REAL blank date fields that genuinely exist (§4.1 實際填答日期 on PDF p.11; §4.2邀請發送日期／送達日期／實際填答日期／回收日期 on PDF p.15), so the R07 traceability failure on that key is fixed. Customer derived-metric rows were corrected to PDF p.28, which matches §6.3.2's actual location (p.28), closing NB-R07-05. However, the §1.4 evidence-locator table on PDF p.4 contains page spans that do not match the current pagination or the document's own sections: row 3 lists §6.1–§6.4 → PDF pp.23–30 (correct) but §7.1–§7.2 → PDF pp.31–34 (correct) while row 1 lists §4.1–§4.3 → PDF pp.10–19 (whereas §4.1 opens on PDF p.10 and §4.2 opens on p.13, and §4.3 runs p.17–19) and §5.1–§5.2 → PDF pp.20–22 (whereas §5.1 opens on PDF p.20 and §5.2 opens on p.22); row 2 lists §2–§3 → PDF pp.5–9 but §3.2's table ends on PDF p.8 and PDF p.9 is the 回收狀態與計數界線 block plus the §4 chapter opening, so the span over-covers; and row 4 lists §6.3.3–§6.4 → PDF pp.28–30, §7.3–§7.4 → PDF pp.33–34 (whereas §7.3 actually opens on PDF p.34 and §7.4 on PDF p.34), §8 → PDF pp.35–38, §9.5 → PDF pp.39–41 (whereas §9.5 opens on PDF p.39 and ends on p.41) and §10 → PDF pp.41–43. The specific, checkable failure is row 4: §7.3–§7.4 is cited to PDF pp.33–34 although7.3 and 7.4 both appear on PDF p.34 and PDF p.33 contains only the §7.2 sensitivity note and the 附圖 A heading. A reader following the §1.4 spans would open PDF p.33 looking for §7.3/§7.4 and find instead the tail of the §7.2 matrix; likewise §5.2 and §4.2 spans point to pages that do not contain those headings. The spans are directionally correct and the document itself warns that page anchors must be re-verified on re-export (PDF p.5 and p.41), so no reader is materially misled, but the table is not exactly itemised. The register's own document_location values are current and consistent (learner derived keys → p.27, customer derived keys → p.28, rates → pp.27–28, follow-up → pp.29–30, count keys → pp.24–26), and the version history (R05–R08) records the R06 and R07 DOCX SHAs as historical targets and states that R08 does not retroactively rewrite them (PDF p.43); no stale R07 page number is cited as a current locator."
      },
      {
        "criterion": "10. Semantic usability and risk: contradictions, unsupported policy/legal assertions, ambiguous fields, unusable forms, overclaims, missing required inputs, layout-related readability risk visible in the supplied text",
        "verdict": "PARTIAL",
        "exact_locator": "§4.1 PDF pp.10–11 (本文件沒有提供已核定的班次編號 block vs 示範班次代號 SYN-TRN-01 and 示範培訓日期 2026-07-11); §4.2 PDF pp.14–15 (示範填答日期 2026-07-11 vs REAL blank dates); §5.2 PDF p.22; §7.2 PDF p.31–33; §8.3 PDF p.35; §9.5 PDF p.39; §1.3 PDF pp.2–3; §10.2 PDF p.43",
        "finding": "No overclaim, no fabricated legal or policy assertion, and no unusable form was found: the document refuses to assert legal retention periods, current storage, approval, signatures, committee existence, adopted status or official score levels (§2.4 p.6; §8.3 p.35; §8.1 p.35; §1.3 p.3; §10.2 p.43), and the instruments are printable with unambiguous REAL vs SAMPLE field partitioning (p.10–11, p.14–15). Two residual semantic risks remain. First, the §4.1 wording 本文件沒有提供已核定的班次編號 (p.10) is immediately followed by a printed 示範班次代號 SYN-TRN-01 (p.11), and Tool-A still prints a pre-filled 示範培訓日期 2026-07-11 alongside a blank REAL 培訓日期, while Tool-B prints a pre-filled 示範填答日期 2026-07-11 next to four blank REAL date fields; the R08 form now labels these explicitly as SAMPLE／SYNTHETIC 合成值 and adds an instruction not to back-fill the sample date into the REAL fields, which materially reduces the R07 misreading risk, but the literal claim that the document contains no class identifier sits immediately above a printed identifier. Second, the §1.4 locator drift described under criterion 9 means the document's own audit-trail table can send a reader to a page that does not contain the cited section heading, which is a traceability rather than a truth defect. No conclusion in the document exceeds the support of its cited source rows, and the reviewer saw no material layout-related readability risk in the supplied text beyond noting that table-heavy pages (pp.4, 26, 31–32, 37) cannot be assessed for column fit, orphan headings or font-size compliance without the rendered pages."
      }
    ],
    "r07_finding_disposition": [
      {
        "id": "NB-R07-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 evidence-locator table, PDF p.4, rows 1–4, third column (文件證據定位); compared against actual headings on PDF pp.10, 13, 17, 20, 22, 28, 34, 35, 39, 41",
        "rationale": "The R07 defect (two imprecise spans in row 1 and row 3) was rewritten in R08, so the original pointer is gone, but the replacement is not correctly itemised either and introduces a new error: row 4 maps §7.3–§7.4 to PDF pp.33–34 while both 7.3 and 7.4 appear only on PDF p.34 (PDF p.33 holds the §7.2 sensitivity note and the 附圖 A heading); row 1 maps §4.1–§4.3 to pp.10–19 although §4.2 opens on p.13 and §4.3 on p.17, and maps §5.1–§5.2 to pp.20–22 although §5.2 opens on p.22; row 2 maps §2–§3 to pp.5–9 although the §3.2 table ends on p.8 (p.9 carries the counting-boundary block and the §4 chapter opening). Spans remain directionally correct, and the document itself instructs re-verification on re-export (PDF p.5, p.41), so this is a precision/tightening item rather than a wrong pointer — consistent with R07's own characterisation."
      },
      {
        "id": "NB-R07-02",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF p.11 (實際填答日期（REAL，空白欄位）); §4.2 PDF p.15 (邀請發送日期／送達日期／實際填答日期／回收日期, all REAL blank); §9.5 row 3 PDF p.39; register key UNK-0095-UNK_FORMAL_EFFECTIVE_DATE; §10 R08 補充說明 (1) PDF p.41",
        "rationale": "Tool-B now carries four separate REAL blank date fields (dispatch, delivery, actual response, return) that directly evidence the 5-working-day delivery and day-3 reminder window in §1.1 and §2.2 stage 4, and Tool-A carries a REAL blank 實際填答日期. The register key's document_location was corrected from the non-existent '§4.2 Tool-B real response-date and return-date fields；PDF pp. 10–11, 32' to the fields that actually exist, now anchored at PDF pp. 11, 15, 39, 41, and §9.5 row 3 was updated to the same anchors. A register-to-document traceability check on this key now succeeds."
      },
      {
        "id": "NB-R07-03",
        "disposition": "CLOSED",
        "exact_locator": "§7.1 comparison table, PDF p.31, row 正向率最低項目 (目標客戶端 cell) and row 正向率最高項目 (目標客戶端 cell); §7.2目標客戶端序位之解讀界線, PDF p.33",
        "rationale": "The customer cell now reads 五項並列 4/5＝80.0%（無相對最低項目） and the highest-item cell reads 五項並列 4/5＝80.0%（無相對最高項目）, i.e. the tie is stated explicitly as 'no relative lowest item' rather than substituting a unanimity statement, and the learner cell still names 實作演練價值 (71.4%). The R07 requirement that the cell say so explicitly is met, and the §7.2 interpretation note on p.33 adds that the customer ordering arises solely from the mean (4.00 vs 4.20) and must not be read as lower satisfaction or lower positive rate."
      },
      {
        "id": "NB-R07-04",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 視覺化就緒表格：指標差距與優先改善排序矩陣, PDF pp.31–33 (排序規則 (1)–(6); 學員端 P1–P4 on pp.31–32; 目標客戶端 P1/P2 on p.32; 解讀界線 and 低分回覆計數與敏感度註記 on p.33); §7.2 附圖 A, PDF pp.33–34; §8.4 PDF pp.36–37; §8.5 PDF p.37",
        "rationale": "§7.2 now carries an explicit, reproducible ranking rule (within-group only; positive rate ascending; then mean ascending; ties share a dense rank; comparator is the group's own highest item), displayed sequence numbers (P1–P4 for learners, P1–P2 for the customer track), gap columns expressed as percentage-point and mean differences against a stated comparator, and a sensitivity note with a worked scenario excluding SYN-L14 (n=13, mean 4.08, 10/13 = 76.9%, gap narrowing to 8.8 pp and 0.07) showing the ordering is stable and explicitly not authorised as an exclusion. The chart element R07 also flagged is now supplied as 附圖 A with an interpretation block and alt text (pp.33–34), and §8.4/§8.5 keep cause, owner, deadline and status as UNKNOWN/blank with fill-in fields and rules."
      },
      {
        "id": "NB-R07-05",
        "disposition": "CLOSED",
        "exact_locator": "Register rows SYN-0095-CUSTOMER-C-01-SUM through SYN-0095-CUSTOMER-C-05-POSRATE (document_location '§6.3.2 …；PDF p. 28'); §6.3.2 PDF p.28; §6.3.2 rate rows (PDF p.28) and §6.3.2 opening R_ret/R_val (PDF pp.27–28)",
        "rationale": "All twenty customer derived-metric rows now cite PDF p. 28, which is where §6.3.2's item sums, means, positive counts and rates actually appear. The customer return/validity rates are correctly anchored to pp. 27–28 (R_ret/R_val printed at the p.27/p.28 boundary) and the valid-return share 5/6 = 83.3% is separately keyed and anchored to p.28. The one-page-early anchor error is corrected; no learner row was disturbed (all learner derived rows correctly cite p.27)."
      },
      {
        "id": "NB-R07-06",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF pp.10–11 (【本文件沒有提供已核定的班次編號】 block, 班次編號 REAL blank, 示範班次代號 SYN-TRN-01, 培訓日期 REAL blank, 示範培訓日期 2026-07-11, 實際填答日期 REAL blank, 填答說明); §4.2 PDF pp.14–15 (示範填答日期 2026-07-11 next to four REAL blank date fields and the 填答說明 forbidding back-filling the sample date)",
        "rationale": "R08 converts the R07 ambiguity into an explicit two-column design: every value-bearing field is paired with a labelled REAL blank field (class number, training date, response date on Tool-A; dispatch, delivery, response, return dates on Tool-B), the sample values are renamed 示範班次代號／示範培訓日期／示範填答日期 and flagged as SAMPLE／SYNTHETIC 合成值／非實際辦訓日期, and the instructions state that the sample date must not be entered into the REAL fields and that REAL fields are left blank by the sample. The R07 remedy ('blank 填答日期 or an explicit 示範日期 note') is therefore realised in substance. Minor residue: the sentence 本文件沒有提供已核定的班次編號 still precedes a printed SYN-TRN-01, which is semantically accurate (the identifier is not an approved class number) but stylistically tight."
      },
      {
        "id": "NB-R07-07",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF p.12 (受評者是否實際參與本次課程（資格核對）: 是／否) and p.13; §4.2 PDF p.15 (本填答人是否為貴單位之指定目標客戶聯絡窗口或經授權代表: 是／否／待核; 提供評價之工作接觸) and p.16; §3.2 P-05 PDF p.7; PDF p.9 counting-boundary block; §5.1 MISSING_ITEM PDF p.20; §4.1/§4.2 回收後表單處理狀態 PDF pp.13, 17",
        "rationale": "R08 adds eligibility/screening fields that R07 found absent: Tool-A now records whether the respondent actually attended the course (screening for P-01's population boundary) and Tool-B records whether the respondent is the designated target-customer contact or authorised representative plus the nature of work contact. The disposition codes are also separated: NONRESPONSE is explicitly excluded from the form's single-choice status and must be logged on the invitation/delivery roster, while WITHDRAWN, INCOMPLETE_PENDING_CORRECTION, INVALID and VALID are declared mutually exclusive single-choice states with a counting rule that counts each physically returned form once as POP_RETURNED regardless of later state. P-05 in §3.2 and the p.9 boundary block repeat the same rule. Both instruments are therefore now self-capturing for the exclusion and return criteria R07 flagged as log-only."
      },
      {
        "id": "NB-R07-08",
        "disposition": "OPEN_INFORMATIONAL",
        "exact_locator": "§10 PDF p.41 (CSV and manifest SHA-256 values; 211 rows / 13 columns; 205 retained + 6 new − 3 retired); §10.1 PDF pp.41–42 (attachments A, A-1, A-2, A-3, B, C, D, E); §10 R08 補充說明 (3) PDF p.41; manifest (row_count 211, column_count 13, unique_register_key true, fact_status_counts, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows)",
        "rationale": "The R08 lineage arithmetic is internally consistent and recomputes: 205 retained R06 keys + 6 new UNKNOWN keys − 3 retired combined/pooled keys = 208 R06 keys total, but the R08 file has 211 rows because SYN-0095-CUSTOMER_VALID_RETURN_SHARE was newly added as a separately keyed derived metric, giving 205 + 6 + 1 (new) − 3 (retired) = 209 … and the manifest declares r08_current_rows_from_r06 = 205 with 6 added and 3 retired; the document text at p.41 states the same 205 + 6 − 3 framing, which does not by itself account for the extra SYN-0095-CUSTOMER_VALID_RETURN_SHARE row. This is a minor narrative/completeness tension in the lineage description, not an arithmetic error in the delivered register, whose row_count211 and fact_status_counts (134 SYNTHETIC_FACT + 13 UNKNOWN_NOT_PROVIDED + 7 PROPOSED_CONTROL + 4 PROPOSED_ROLE + 53 DERIVED_SYNTHETIC_METRIC = 211) sum correctly and whose13 columns and unique register_key are stated consistently. Independent verification of the R06 file's own 208 rows, of the 805386b…/ba5e5e1c…/7d90e5af…/9d253829… SHA-256 values, of the DOCX/PDF/CSV/manifest digests, and of the manifest against the delivered artefacts remains impossible without filesystem or binary access; the manifest itself defers the exact PDF SHA binding to a separate visual-QA receipt (attachment E, p.42, R08 receipts 待執行), so the claim rests on packet-internal consistency only, exactly as in R07."
      },
      {
        "id": "NB-R07-09",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 附圖 A, PDF pp.33–34 (圖 A 標題; 圖 A 圖面內容 with left panel learner n=14 and right panel customer n=5; 圖 A 呈現規則; 圖 A 警示; 圖 A 資料界限; 圖 A 文字替代說明)",
        "rationale": "R08 now supplies a specified, interpreted figure element: a two-panel positive-rate bar comparison on a shared 0–100% horizontal axis with per-panel n labels, explicit rendering constraints (no threshold/target/trend lines; panels distinguished by heading, position and labels rather than colour alone), a data-limits statement that all values are SAMPLE/SYNTHETIC and may not serve as approval, performance determination or improvement evidence, and a draft alt text. The figure is interpreted without merging populations: the 警示 block states the different n (14 vs 5), forbids combining, weighting or cross-track comparison, and forbids implying a ranking among the customer items that are all80.0%. The Blueprint's 圖表解讀 element is thereby met as a figure with interpretation, not only as table reading."
      },
      {
        "id": "NB-R07-10",
        "disposition": "CLOSED",
        "exact_locator": "§10.2 PDF p.43 (closing paragraph on compiler/reviewer/adoption authority and signatures = UNKNOWN; historical R06 SHA 71398b10… and R07 SHA ba6100f3…; R08 receipts binding); §10.1 Attachment E, PDF p.42 (R08 receipts 待執行); §1.4 candidate-status column, PDF p.4 (PROPOSED / SYNTHETIC); §9.5 row 1, PDF p.39; register key UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY",
        "rationale": "R08 preserves the boundary in a strengthened form: the closing paragraph states that the association's compiler, formal reviewer and adoption authority and their signatures are UNKNOWN, forbids passing tool routes or system output off as association personnel, approval or signature, requires the independent semantic review result to be taken from external receipts bound to this version's DOCX SHA, and states that R08 does not retroactively rewrite R06/R07 documents, artefacts or receipts; the version table records R05, R06, R07 and R08 with the R06 and R07 DOCX SHAs as historical targets. Attachment E records that R08 technical, visual and semantic receipts have not yet been produced (待執行) and that the R07 response is a R07-version artefact, not an R08 receipt, so the §1.4 PROPOSED / SYNTHETIC status column continues to describe candidate state rather than acceptance. Nothing in the document asserts review, approval or acceptance."
      }
    ],
    "blocking_findings": [],
    "nonblocking_findings": [
      {
        "id": "NB-R08-01",
        "severity": "LOW_MEDIUM",
        "title": "§1.4 evidence-locator table contains page spans that do not match the current pagination, including §7.3–§7.4 cited to PDF pp.33–34 while both sections are on PDF p.34 only",
        "locator": "§1.4 table, PDF p.4, rows 1–4, third column (文件證據定位); affected headings at PDF pp.13 (§4.2), 17 (§4.3), 22 (§5.2), 28 (§6.3.2), 34 (§7.3, §7.4), 35 (§8.1), 39 (§9.5), 41 (§10)",
        "finding": "Row 4 maps §7.3–§7.4 to PDF pp.33–34 although 7.3 and 7.4 are both printed on PDF p.34 and PDF p.33 carries only the §7.2 sensitivity note and the 附圖 A heading; row 1 maps §4.1–§4.3 to pp.10–19 (section starts at pp.10, 13, 17) and §5.1–§5.2 to pp.20–22 (§5.2 starts at p.22); row 2 maps §2–§3 to pp.5–9 although §3.2's table ends on p.8 and p.9 is the counting-boundary block plus the §4 chapter opening. Directionally correct and self-limited by the document's re-export warning (PDF p.5, p.41), so this is a precision defect in the audit trail, not a false pointer, but it is the document's primary traceability table and should be itemised per section start/end."
      },
      {
        "id": "NB-R08-02",
        "severity": "LOW",
        "title": "Register lineage description in §10 does not account for the newly added SYN-0095-CUSTOMER_VALID_RETURN_SHARE row",
        "locator": "§10 PDF p.41 (R08 補充說明 (3) and the §10 body: '205 個仍適用之 R06 鍵保留，6 個 UNKNOWN 升格索引鍵新增 … 移除 3 個不再使用的合併／合併正向率衍生鍵'); manifest fields r08_current_rows_from_r06205, r08_added_unknown_index_rows 6, retired_r08_rows[3], row_count 211; register row SYN-0095-CUSTOMER_VALID_RETURN_SHARE (PDF p.28)",
        "finding": "The declared row arithmetic (205 + 6 − 3 = 208) does not reach the delivered 211 rows: SYN-0095-CUSTOMER_VALID_RETURN_SHARE is an additional R08-derived key that appears in the CSV but is not counted in either the retained, added or retired sets in the §10 narrative or the manifest's added/retired lists. The CSV's own totals are internally consistent (134 + 13 + 7 + 4 + 53 = 211, 13 columns, unique register_key), so no claim is false; the lineage sentence is simply incomplete relative to the delivered file and should add one '新增' key."
      },
      {
        "id": "NB-R08-03",
        "severity": "LOW",
        "title": "§4.1 still states the document contains no approved class identifier immediately above a printed synthetic class code and a pre-filled sample training date",
        "locator": "§4.1 PDF pp.10–11 (【本文件沒有提供已核定的班次編號】 block; 示範班次代號 SYN-TRN-01; 示範培訓日期 2026-07-11; REAL blanks); §4.2 PDF p.15 (示範填答日期 2026-07-11 beside four REAL blank date fields)",
        "finding": "R08 has fully realised the substance of the R07 remedy (paired REAL blank fields, explicit SAMPLE labels, instructions forbidding back-filling the sample date), so the residual risk is stylistic rather than evidential: the literal wording sits one line above a filled-in identifier and date on both instruments. A one-line qualifier such as '除示範合成值外，本文件未載入任何已核定班次編號' would remove the residual chance of a prefilled sample value being read as an administration fact."
      },
      {
        "id": "NB-R08-04",
        "severity": "INFORMATIONAL",
        "title": "R08 review receipts are not yet produced and the manifest's PDF page-anchor basis is deferred to an external visual-QA receipt",
        "locator": "§10.1 Attachment D and Attachment E, PDF p.42; §10 R08 補充說明 (2), PDF p.41; manifest page_locator_basis and state CANDIDATE_QA_PENDING",
        "finding": "Attachment D binds the Word-exported PDF SHA and page count only through a companion final-QA list, and Attachment E records the R08 technical, visual and semantic receipts as 待執行. The candidate's own QA chain is therefore open at R08, which is consistent with the packet's CANDIDATE state and with §10.2's prohibition on self-declaring PASS; it is recorded here as a workflow state, not a defect in the document body."
      },
      {
        "id": "NB-R08-05",
        "severity": "INFORMATIONAL",
        "title": "Improvement candidate's robustness still rests on a 14-respondent synthetic sample, and the customer track's n=5 gives each respondent20 percentage points of influence",
        "locator": "§7.2 sensitivity note, PDF p.33 (L-03 sensitivity scenario; customer n=5 每題各 1 份非正向回覆，其分數值未逐筆識別); §7.3 items 1–4, PDF p.34; §6.4, PDF p.29 (12 of 14 paired)",
        "finding": "R08 now discloses both sensitivities (the L-03 single-2-point case and the 20-point-per-respondent effect on the customer track), keeps causes UNKNOWN and forbids inferring group differences, and §8.4/§8.5 keep cause, owner, deadline and status as UNKNOWN/blank. The residual limitation is inherent to the synthetic design and is stated in the document rather than concealed; it requires no change other than continued presentation as SAMPLE/SYNTHETIC."
      }
    ],
    "material_arithmetic_checks": [
      {
        "check": "Learner population: invited 18 = returned 15 + nonresponse 3; returned 15 = valid 14 + invalid 1; valid n=14 = 12 paired + 2 unpaired",
        "recomputed": "18 = 15 + 3; 15 = 14 + 1; 14 = 12 + 2 — all three identities hold",
        "verdict": "PASS",
        "locator": "§6.1 PDF p.24; §6.4 PDF p.29; §6.4.1 PDF p.30"
      },
      {
        "check": "Customer population: invited 6 = returned 5 + nonresponse 1; returned 5 = valid 5 + invalid 0",
        "recomputed": "6 = 5 + 1; 5 = 5 + 0 — holds",
        "verdict": "PASS",
        "locator": "§6.2 PDF p.25; §6.3.2 PDF p.27"
      },
      {
        "check": "Learner return rate 15/18 and validity rate 14/15, rounding to 1 dp",
        "recomputed": "83.333… → 83.3%; 93.333… → 93.3%",
        "verdict": "PASS",
        "locator": "§6.3.1 items 1–2, PDF p.27; register SYN-0095-LEARNER_RETURN_RATE / SYN-0095-LEARNER_VALID_RATE"
      },
      {
        "check": "Customer return rate 5/6, validity rate 5/5, valid-return share 5/6",
        "recomputed": "83.333… → 83.3%; 100.0%; 83.333… → 83.3% — matches, and the document correctly distinguishes the third from a validity rate (PDF p.28)",
        "verdict": "PASS",
        "locator": "§6.3.2 items 1–2 and the additional line, PDF pp.27–28; register SYN-0095-CUSTOMER_RETURN_RATE / SYN-0095-CUSTOMER_VALID_RATE / SYN-0095-CUSTOMER_VALID_RETURN_SHARE"
      },
      {
        "check": "Learner item sums L-01..L-05 recomputed from the §6.1 raw matrix (14 rows, pp.24–25)",
        "recomputed": "L-01 = 57; L-02 = 56; L-03 = 55; L-04 = 56; L-05 = 58 — all match the document's stated sums",
        "verdict": "PASS",
        "locator": "§6.1 PDF pp.24–25; §6.3.1 PDF p.27; register SYN-0095-LEARNER-L-0x-SUM"
      },
      {
        "check": "Learner item means X̄ = sum/14 to 2 dp",
        "recomputed": "57/14 = 4.0714 → 4.07; 56/14 = 4.0000 → 4.00; 55/14 = 3.9286 → 3.93; 56/14 = 4.00; 58/14 = 4.1429 → 4.14",
        "verdict": "PASS",
        "locator": "§6.3.1 PDF p.27; register SYN-0095-LEARNER-L-0x-MEAN"
      },
      {
        "check": "Learner positive counts (4 or 5) and rates",
        "recomputed": "L-01 11/14 = 78.571 → 78.6%; L-02 11/14 → 78.6%; L-03 10/14 = 71.428 → 71.4%; L-04 11/14 → 78.6%; L-05 12/14 = 85.714 → 85.7%; the respondent enumerations printed in §6.3.1 match the raw matrix member-by-member",
        "verdict": "PASS",
        "locator": "§6.3.1 PDF p.27; register SYN-0095-LEARNER-L-0x-POSN / -POSRATE"
      },
      {
        "check": "Customer item sums, means, positive counts and rates from the §6.2 raw matrix (5 rows, pp.25–26)",
        "recomputed": "C-01 21 → 4.20, 4 → 80.0%; C-02 20 → 4.00, 4 → 80.0%; C-03 20 → 4.00, 4 → 80.0%; C-04 21 → 4.20, 4 → 80.0%; C-05 21 → 4.20, 4 → 80.0%",
        "verdict": "PASS",
        "locator": "§6.2 PDF pp.25–26; §6.3.2 PDF p.28; register SYN-0095-CUSTOMER-C-0x-*"
      },
      {
        "check": "Follow-up paired scores: Σpre, Σpost, means, Δabs, Δrel, outcome rate, threshold count",
        "recomputed": "Σpre = 4+5+6+3+4+5+6+2+4+5+3+4 = 51 → 4.25; Σpost = 7+8+8+6+7+8+8+5+7+8+6+7 = 85 → 7.0833 → 7.08; Δabs = 34/12 = 2.8333 → 2.83; Δrel = 34/51 = 66.666…% → 66.7%; post ≥ 7 for L01, L02, L03, L05, L06, L07, L09, L10, L12 = 9 of 12 → 75.0%; the three failures (L04 = 6, L08 = 5, L11 = 6) match the document's list",
        "verdict": "PASS",
        "locator": "§6.4 PDF p.29; §6.4.1 PDF p.30; register SYN-0095-FOLLOWUP_PRE_SUM/POST_SUM/PRE_MEAN/POST_MEAN/ABS_CHANGE/REL_CHANGE/PASS_COUNT/PASS_RATE"
      },
      {
        "check": "Non-zero baseline guard for Δrel and no zero substitution for missing pairs",
        "recomputed": "Baseline Σ = 51 ≠ 0 so the guard in §5.2 is satisfied and the computation is valid; the 2 unpaired learners are excluded from the paired denominator and are explicitly not counted as failures (PDF p.29, p.30)",
        "verdict": "PASS",
        "locator": "§5.2 item 6, PDF p.22; §6.4 bullet 2, PDF p.29; §6.4.1 配對母數核對, PDF p.30"
      },
      {
        "check": "§7.2 gap columns recomputed against the stated group comparators",
        "recomputed": "Learner baseline L-05 85.7% / 4.14: L-03 gap 85.7−71.4 = 14.3 pp and 4.14−3.93 = 0.21; L-02/L-04 gap 85.7−78.6 = 7.1 pp and 0.14; L-01 gap 7.1 pp and 0.07; L-05 0.0 / 0.00. Customer baseline80.0% / 4.20: C-02/C-03 gap 0.0 pp and 0.20; C-01/C-04/C-05 0.0 / 0.00 — all correct",
        "verdict": "PASS",
        "locator": "§7.2 學員端 matrix, PDF pp.31–32; §7.2 目標客戶端 matrix, PDF p.32"
      },
      {
        "check": "§7.2 ranking rule (2)(3)(4) applied with dense ranking within each group only",
        "recomputed": "Learner: ascending positive rate gives L-03 (71.4%) then L-01/L-02/L-04 (78.6%) then L-05 (85.7%); tie-break by mean gives L-02 and L-04 (4.00) ahead of L-01 (4.07) → P1 L-03; P2 L-02/L-04; P3 L-01; P4 L-05. Customer: all positive rates 80.0%, so the mean tie-break gives C-02/C-03 (4.00) at P1 and C-01/C-04/C-05 (4.20) at P2 — matches the printed ranks",
        "verdict": "PASS",
        "locator": "§7.2 排序規則 (1)–(6) and matrices, PDF pp.31–32"
      },
      {
        "check": "§7.2 single-observation sensitivity scenario (exclusion of SYN-L14 from L-03)",
        "recomputed": "L-03 sum 55 − 2 = 53 over n = 13 → mean 4.0769 → 4.08; positive count unchanged at 10 → 10/13 = 76.923 → 76.9%; gap to L-05 (85.7%) = 8.8 pp; mean gap 4.14 − 4.08 = 0.07; by rule (2)(3) L-03 remains P1 — matches the document",
        "verdict": "PASS",
        "locator": "§7.2 情境演算 bullet, PDF p.33"
      },
      {
        "check": "Register arithmetic against the CSV body supplied in the packet",
        "recomputed": "Row groups in the supplied CSV: 14 case/count/base facts (CASE_ID, COURSE_NAME, COURSE_HOURS, COURSE_DATE, FOLLOWUP_DATE, LEARNER_INVITED, LEARNER_RETURNED, LEARNER_NONRESPONSE, LEARNER_INVALID, LEARNER_VALID, INVALID_REASON, CUSTOMER_INVITED, CUSTOMER_RETURNED, CUSTOMER_NONRESPONSE, CUSTOMER_VALID —15 in fact) plus 9 pre-existing UNKNOWN keys plus 6 new UNKNOWN keys; 70 learner score rows (14 × 5); 25 customer score rows (5 × 5); 24 follow-up rows (12 × 2); 7 PROPOSED_CONTROL + 4 PROPOSED_ROLE; 40 learner/customer derived metrics + 4 rate metrics + 8 follow-up metrics + 1 valid-return-share = 53 DERIVED_SYNTHETIC_METRIC. The manifest's fact_status_counts (134 / 13 / 7 / 4 / 53) sum to 211 and equal row_count 211, with column_count 13 and unique_register_key true; register_key values are unique across the supplied body and every key cited in §9.5 and §10 appears in the body",
        "verdict": "PASS",
        "locator": "Full register CSV body; manifest fact_status_counts and row_count/column_count; §9.5 PDF pp.39–40"
      },
      {
        "check": "Register value-to-document reconciliation for every derived key family",
        "recomputed": "SYN-0095-LEARNER-L-01..L-05 {SUM,MEAN,POSN,POSRATE} equal the §6.3.1 figures (57/4.07/11/78.6; 56/4.00/11/78.6; 55/3.93/10/71.4; 56/4.00/11/78.6; 58/4.14/12/85.7); SYN-0095-CUSTOMER-C-01..C-05 equal the §6.3.2 figures; the four rate keys equal §6.3.1/§6.3.2; the eight follow-up keys equal §6.4.1; and the count keys equal §6.1/§6.2 (18/15/14 and 6/5/5, 3 and 1 nonresponse, 1 invalid)",
        "verdict": "PASS",
        "locator": "Register DERIVED_SYNTHETIC_METRIC rows vs §6.1 p.24, §6.2 p.25, §6.3.1 p.27, §6.3.2 p.28, §6.4.1 p.30"
      },
      {
        "check": "Retirement of combined/pooled metrics consistent between document, register and manifest",
        "recomputed": "SYN-0095-COMBINED_RETURN_RATE, SYN-0095-COMBINED_VALID_RATE and SYN-0095-POOLED_POSITIVE_RATE appear in the manifest's retired_r08_rows and r06_omitted_keys_from_r08, are absent from the supplied R08 CSV body, and §10 (PDF p.41) records the retirement with its basis (§6.3.3 no longer merges); §6.3.3 (PDF p.28) contains no pooled figure",
        "verdict": "PASS",
        "locator": "§6.3.3 PDF p.28; §10 PDF p.41; manifest retired_r08_rows; §9.5 row 6 PDF p.40"
      },
      {
        "check": "Item-level sensitivity of the register's per-response rows against the displayed raw matrices",
        "recomputed": "All 70 learner and 25 customer score values in the CSV equal the corresponding cells printed in §6.1/§6.2 (e.g. SYN-L14 = 2/3/3/3/2; SYN-C04 = 3/3/3/3/3; SYN-C05 = 4/4/4/4/4), and all 24 follow-up rows equal the §6.4 table",
        "verdict": "PASS",
        "locator": "Register per-response rows vs §6.1 PDF pp.24–25, §6.2 PDF pp.25–26, §6.4 PDF p.29"
      },
      {
        "check": "Official anchor arithmetic and hash bindings carried in the document",
        "recomputed": "§1.2 official source SHA805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709 equals the packet's binding value; §1.3 scoring-form SHA 9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684 is distinct and consistent between PDF p.2 and p.3; §1.2 quotes the 1分 band text and the I18-E02 evidence item verbatim from the supplied page-6 extract; the quoted 1–4 score bands match the supplied page-4 extract verbatim; the Unique Blueprint row SHA in the binding matches the packet's stated Blueprint row SHA; §10 quotes the CSV SHA 203583e4…0202c and manifest SHA df1b2517…17c0 exactly as given in the packet and the manifest",
        "verdict": "PASS",
        "locator": "§1.2 PDF p.2; §1.3 PDF pp.2–3; §9.5 PDF p.39; §10 PDF p.41; §10.1 PDF pp.41–42"
      },
      {
        "check": "Suppression and small-sample discipline (n<5 rule) versus published results",
        "recomputed": "The only group-level results published are learner n=14 and customer n=5, both ≥ 5; no sub-group percentages, means or distributions below the threshold are published; the follow-up paired subset n=12 is ≥ 5 and is labelled as a subset with its own limitation; individual respondent scores shown in §6.1/§6.2/§6.4 are synthetic index codes, not identifiable persons",
        "verdict": "PASS",
        "locator": "§5.1 SUB_SUPPRESS PDF p.21; §7.3 items 1 and 3 PDF p.34; §8.1 PDF p.35"
      },
      {
        "check": "No cross-population aggregation or cross-track comparison in any computed figure",
        "recomputed": "Every published rate, mean, gap and rank belongs to exactly one of the two tracks; the only combined-looking number (5/6 = 83.3% valid-return share) is explicitly labelled as a share of the customer invitation base and explicitly distinguished from a validity rate; no pooled satisfaction rate exists anywhere",
        "verdict": "PASS",
        "locator": "§6.3.3 PDF p.28; §7.2 PDF pp.31–33; §7.2 附圖 A 警示 PDF p.34"
      }
    ],
    "unknowns": [
      "Whether the DOCX binary at SHA e9322191…ce31a1 (262583 bytes) matches the reviewed PDF export e194836e…bd2e9 (43 pages) — the reviewer did not and cannot rehash either artefact; the association is packet-asserted only.",
      "Whether the CSV file with SHA 203583e4…0202c and the manifest with SHA df1b2517…17c0 exist on disk with exactly the 211 rows / 13 columns shown in the packet, and whether the manifest's R06 SHA 7f2034e3…347f, R07 SHA ba5e5e1c…3d4 and historical manifest SHA 7d90e5af…cb01c are correct.",
      "The R06 register's own 208-row content and the three retired combined/pooled keys' former values (not supplied), which prevents independent confirmation that the 205 retained R06 rows are byte-faithful except for document_location updates.",
      "The R08 technical, visual and semantic QA receipts (attachment E) do not yet exist; the exact PDF SHA binding claimed by the manifest's page_locator_basis is deferred to that receipt.",
      "All REAL association facts: existing survey system, approved instrument, actual class/course, author and formal reviewer identity, approval and signature originals, formal/effective dates, real invitation/return/valid counts, real responses, nonresponse reasons, improvement decisions with owner and deadline, and real attachment/storage/access paths.",
      "The identity and item values of the one invalid learner return and the two unpaired learners; the specific non-positive customer scores per item; and the identity of the fourth unidentified non-positive L-03 response.",
      "Whether the association has a 原始點協會 committee, delegated authority or an adopted survey mechanism — the document keeps this UNKNOWN and the reviewer could not resolve it from the packet.",
      "Runtime/model-provider identity of this review session; the requested route (OpenCode CLI v2.0.32, opencode/minimax-m3.1-flash-free) is recorded as requested, not attested."
    ],
    "reviewer_limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used, and none was available; no DOCX binary rehash, no PDF re-render, no extraction of the DOCX XML, no font-size or layout measurement.",
      "No visual inspection of the 43-page export was performed; all page, table, row and cell references are read from the packet's page-bounded PDF text. Typography (10.5pt body / 9.5pt table floors), column fit, orphan headings, blank pages, image presence or absence, and 附圖 A's actual rendering (which exists in R08 only as a written specification on PDF pp.33–34) could not be confirmed — an actual drawn figure may or may not be present in the DOCX.",
      "All arithmetic was recomputed by hand from the raw rows printed in §6.1, §6.2 and §6.4 and from the CSV body reproduced in the packet; no spreadsheet or calculation engine was used.",
      "SHA-256 values for the DOCX, PDF, CSV, manifest and official sources were compared for internal consistency only and were not independently recomputed.",
      "Findings are bound to the DOCX SHA-256 supplied by the packet; a re-export, re-layout or any change to the DOCX invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, and not formal association acceptance; the deliverable remains CANDIDATE."
    ],
    "provider_model_identity": "UNKNOWN — no runtime attestation of provider or model identity was supplied to the reviewer. The packet records a requested reviewer route of OpenCode CLI v2.0.32 with opencode/minimax-m3.1-flash-free, but that is a request recorded in the packet, not a direct attestation from the executing runtime; in the absence of direct attestation the identity is treated as UNKNOWN, and the document's own equivalent boundary (§10.2, PDF p.43: identity, signatures and approval must not be inferred from tool route or system output) is applied here as well."
  },
  "R08_receipt": {
    "receipt_type": "R08 independent semantic review receipt",
    "project_id": "TTQS_ONE",
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "candidate_state": "HISTORICAL_CANDIDATE_NOT_FORMALLY_ACCEPTED",
    "reviewed_docx_sha256": "e9322191eb70554311f506db2eedf0800c1e786012a6b854cbe4b31864ce31a1",
    "review_packet_sha256": "aea6f077427db3c32ca9489f7ef4e6d68a482da95ad5200899c9d3365ab55d19",
    "reviewed_pdf_sha256": "e194836e1a63abc189ebfc6af1bfe314219dc0b2aefd65947ebb02665e6bd2e9",
    "review_response_sha256": "914a9d8f34186b5f7bbfec0d8c1183d81ff4435bf3adb2ddc0261f42e5189a89",
    "raw_stdout_sha256": "93c057da3ae7200cde680c195d89175cb164b81d1f7c1b26eaf872a911a628fd",
    "raw_stderr_sha256": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "process_exit_code": 0,
    "requested_cli": "OpenCode CLI v2.0.32",
    "requested_model_route": "opencode/minimax-m3.1-flash-free",
    "provider_model_identity": "UNKNOWN",
    "review_session_id": "ses_ea6c9f637ffeeWAC5U2G4x4K1g",
    "verdict": "PARTIAL",
    "blocking_finding_count": 0,
    "nonblocking_finding_count": 5,
    "review_scope": "Packet-only independent semantic review of DOCX 0095 / I18-E02 R08 candidate, performed without shell, filesystem, browser, GUI, DOCX-binary rehash or independent visual inspection. All verdicts are derived from the packet-supplied R08 Word-exported PDF text (43 pages), the supplied R08 replacement-register CSV body, the supplied manifest, the Unique Blueprint and source binding, and the R07 historical finding list. The DOCX SHA-256 e9322191…ce31a1 is bound as the item under review as supplied by the packet; the reviewer did not and cannot independently rehash the DOCX binary. Reviewer re-derived every quantitative claim from the raw rows displayed in §6.1, §6.2 and §6.4 and re-verified register arithmetic from the CSV body reproduced in the packet.",
    "reviewer_limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used, and none was available; no DOCX binary rehash, no PDF re-render, no extraction of the DOCX XML, no font-size or layout measurement.",
      "No visual inspection of the 43-page export was performed; all page, table, row and cell references are read from the packet's page-bounded PDF text. Typography (10.5pt body / 9.5pt table floors), column fit, orphan headings, blank pages, image presence or absence, and 附圖 A's actual rendering (which exists in R08 only as a written specification on PDF pp.33–34) could not be confirmed — an actual drawn figure may or may not be present in the DOCX.",
      "All arithmetic was recomputed by hand from the raw rows printed in §6.1, §6.2 and §6.4 and from the CSV body reproduced in the packet; no spreadsheet or calculation engine was used.",
      "SHA-256 values for the DOCX, PDF, CSV, manifest and official sources were compared for internal consistency only and were not independently recomputed.",
      "Findings are bound to the DOCX SHA-256 supplied by the packet; a re-export, re-layout or any change to the DOCX invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, and not formal association acceptance; the deliverable remains CANDIDATE."
    ],
    "raw_stdout_preserved": "review/0095_R08_opencode_minimax_R01_stdout.jsonl",
    "normalized_response": "review/0095_R08_opencode_minimax_R01_response.json",
    "state": "REVIEWED_PARTIAL_NO_BLOCKERS; R08 unchanged; material locator issue repaired only in R09"
  },
  "R09_response": {
    "overall_verdict": "PARTIAL",
    "reviewed_docx_sha256": "e1be4a9e9a0c61216416f6ff955bb1be3ed5d1f636550ea82bea4b5431e0ed8e",
    "review_scope": "Packet-only independent semantic review of the R09 candidate for DOCX 0095 / I18-E02. All findings derive solely from the packet-supplied current R09 Word-exported PDF text (43 pages), the supplied R08 replacement-register CSV body, the supplied register manifest, the Unique Blueprint and source binding, the R08 exact-SHA review outcome, and the deterministic R06/R08 register key-set reconciliation. No shell, filesystem, browser, GUI, DOCX-binary rehash, PDF re-render, or visual inspection was performed or claimed. The DOCX SHA-256 e1be4a9e…0ed8e is bound as the review target exactly as supplied by the packet and was not independently rehashed. This review assesses semantic content only; it is not a TTQS assessment, not a score, and not formal association acceptance. The candidate remains CANDIDATE.",
    "criteria": [
      {
        "criterion": "1. Official I18-E02 wording, DOCX 0095, analysis-report genre, case mapping, title-blind identifiability, separation from 0094/I18-E01 and 0096/I18-E03",
        "verdict": "PASS",
        "exact_locator": "§1.2 PDF p.2; §1.3 官方評核級距表 PDF pp.2–3; §1.4 PDF p.4; §9.1 PDF p.38; §9.3 PDF p.38; §9.4 PDF p.38; 文件狀態宣告 PDF p.1",
        "finding": "The official checkbox text 『建立目標客戶及學員滿意度調查機制（系統及流程面）。』 is reproduced verbatim and bound to official source page 6 with SHA-256 805386b7…4709 and readback status PDF_TEXT_EXACT_PAGE_MATCH (§1.2, PDF p.2), matching the supplied page-6 extract. The indicator-18 grading band (1–4 分) is quoted verbatim from the scoring form page 4 with its own distinct SHA-256 9d253829…83684 (§1.3, PDF pp.2–3), and the document explicitly separates the two official instruments' roles, which is a material improvement over conflating them. The deliverable is DOCX 0095 / I18-E02 throughout the running header and §1.2. Genre is an analysis/evaluation report: §1 executive summary, §2 architecture and lifecycle, §3 SoD/SOP, §4 instruments, §5 dictionary/formulae, §6 worked synthetic case, §7 group analysis, §8 controls/PDCA, §9 neighbours, §10 register and version lineage. Title-blind identifiability holds: body-level fields LEARN_RELEVANCE/LEARN_CLARITY/LEARN_PRACTICE/LEARN_SUPPORT/LEARN_OVERALL and CUST_GOAL_FIT/CUST_ARRANGE/CUST_PRACTICE/CUST_COMM_CLAR/CUST_OVERALL (§4.3, PDF pp.17–18), plus form codes SURVEY-TOOL-A-L / SURVEY-TOOL-B-C (§4.1 p.10, §4.2 p.13) and SOP codes P-01…P-10 (PDF pp.7–8), could not be moved unchanged to another requirement. Separation from 0094 (口述訪談紀錄) and 0096 (感謝函) is explicit and concrete at §9.3 and §9.4 (PDF p.38), with an explicit refusal to fabricate or substitute 0096 originals; §9.2 also flags 0093 as an unverified extra neighbour without using it as requirement evidence. No correction required."
      },
      {
        "criterion": "2. All Unique Blueprint sections, required tables/figure/analysis, questions, calculations, direct usability and acceptance tests",
        "verdict": "PASS",
        "exact_locator": "§1–§10 PDF pp.1–43; Blueprint required_sections vs §1.1–§10.2; required_tables_or_figures vs §5.1 (pp.20–21), §6.1–§6.4 (pp.24–30), §7.2 (pp.31–32), §7.2 附圖 A (pp.33–34), §8.5 (p.37), §1.4 (p.4); required_fields_or_questions vs §1.1 (p.1), §3.2 (pp.7–9), §5.1 (pp.20–21), §5.2 (p.22), §6.3 (pp.27–28), §7.3 (p.34), §8.1 (p.35), §10 (p.41), §9.5 (pp.39–41)",
        "finding": "All thirteen Blueprint required_sections are present and substantively populated: 摘要/決策問題 (§1.1), 官方要求 (§1.2–§1.3), 來源樣本納入排除 (§2.4, §3.2, §5.1, §6.1–§6.2), 指標定義與分母 (§5.1–§5.2), 完整示範資料與逐步計算 (§6.1–§6.4.1), 分群/趨勢/差異 (§7.1–§7.2), 圖表解讀與品質限制 (§7.2 附圖 A, §7.3), 發現原因與證據強度 (§1.3, §7.3, §8.4), 結論與建議 (§8.4–§8.5), 責任/期限/追蹤指標 (§8.5, PDF pp.37–38), 合成聲明與替換清單 (§9.5, §10), 附件索引/覆核/版本 (§10.1–§10.2). All five required table/figure families are present, including 附圖 A as a fully specified two-panel figure with title, per-panel values, same 0–100% axis, presentation rules, warnings and alt-text draft (PDF pp.33–34). Per the packet instruction, the absence of an encoded figure object in PDF text was not treated as a missing chart. All ten required_questions are answered with explicit denominators, sources, nonresponse handling, attribution boundary, direct-evidence location, evidence-strength ladder (4.25–4.26), calculation precision and N/A conditions. All three required_calculations are implemented and recomputed (see material_arithmetic_checks) and the result is never framed as association performance. Genre-specific usability is satisfied: questionnaires carry items/options/scale (PDF pp.12, 16), the SOP carries role/input/control/output/hold-reject (PDF pp.7–8), the meeting-record role is carried as 審閱／決策紀錄 and 版本與調閱記錄 outputs with decisions, responsibility, deadline and status columns (§8.5, PDF p.37), and the report carries data, denominators, formulae, step-by-step arithmetic, limits and decisions. Acceptance tests are met on the text-only evidence available; typography floors, column fit and actual figure rendering are outside the packet-only scope and are carried in unknowns, not as defects."
      },
      {
        "criterion": "3. Reassessment of the five R08 findings (R08-01 page-map precision; R08-02 uncounted CUSTOMER_VALID_RETURN_SHARE; R08-03 sample class wording; R08-04 review receipt status; R08-05 small-sample sensitivity)",
        "verdict": "PARTIAL",
        "exact_locator": "R08-01 → §1.4 table PDF p.4; R08-02 → §10 body PDF p.41 and manifest r08_current_rows_from_r06 / r08_added_unknown_index_rows / retired_r08_rows; R08-03 → §4.1 PDF pp.10–11, §4.2 PDF p.15; R08-04 → §10.1 附件 D/E PDF p.42, §10.2 R09 row PDF p.43; R08-05 → §7.2 sensitivity note PDF p.33, §7.3 PDF p.34, §6.4 PDF p.29",
        "finding": "R08-01 is materially improved but not fully closed: the §1.4 locator column was rewritten to per-section page spans, §7.3–§7.4 now points to PDF p.34 (the page where both sections actually print) instead of R08's pp.33–34, and the row-1 spans §4.1 → pp.10–13, §4.2 → pp.13–17, §4.3 → pp.17–19 now match the section starts observed in the current export. Residual imprecision remains in row 1 (§5.1 → pp.20–21 and §5.2 → p.22, where §5.1 actually opens on p.19 under the §4.3 heading and §5.2 opens on p.22), row 2 (§2.1–§2.4 → pp.5–6, although §2.4 and its 制度設計與現況之分際 table run to p.6 only as a heading with the boundary text continuing to p.6–7), row 3 (§7.1–§7.2 → pp.31–34, but §7.2's 視覺化就緒表格 opens on p.31 while the 附圖 A figure specification opens on p.33), and row 4 (§6.3.3–§6.4 → pp.28–30, where §6.3.3 and §6.4 both open on p.28 and the §6.4.1 derivation extends to p.30, which the span does not cover). R08-02 is confirmed CLOSED/contradicted: SYN-0095-CUSTOMER_VALID_RETURN_SHARE is present in the supplied R08 CSV body and, per the deterministic R06/R08 key-set reconciliation, also in R06 and therefore among the 205 retained keys; the §10 lineage sentence (205 retained + 6 added − 3 retired = 208) is a count of key-set deltas that correctly reaches 211 only if read as 208 R06 keys − 3 retired + 6 added, and the R09 version note at PDF p.43 states this reconciliation, so no uncounted row survives. R08-03 is CLOSED: both instruments now carry the qualifier 『未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範』 immediately above the printed 示範班次代號 SYN-TRN-01 (PDF p.10 for Tool-A, p.14 for Tool-B), and Tool-B p.15 carries 『示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11』 labelled as synthetic immediately above the four REAL blank date fields. R08-04 remains OPEN as a workflow state (Attachment E records R09 receipts as 待執行 at PDF p.42) and is consistent with CANDIDATE_QA_PENDING. R08-05 is CLOSED in substance and remains disclosed at PDF p.33."
      },
      {
        "criterion": "4. Recomputation of all learner/customer raw counts, sums, means, positive counts/rates, rankings, gaps, single-record sensitivity, outcome figures, denominators, missing/N/A rules, rounding and suppression; no merging of distinct respondent populations",
        "verdict": "PASS",
        "exact_locator": "§6.1 PDF pp.24–25; §6.2 PDF pp.25–26; §6.3.1 PDF p.27; §6.3.2 PDF p.28; §6.3.3 PDF p.28; §6.4 PDF p.29; §6.4.1 PDF p.30; §7.1 PDF p.31; §7.2 PDF pp.31–33; §5.2 PDF p.22",
        "finding": "Every displayed quantity was independently recomputed from the raw rows printed in §6.1/§6.2/§6.4 and all reproduce exactly (see material_arithmetic_checks). Counts reconcile: learners 18 invited = 15 returned + 3 nonresponse; 15 returned = 14 valid + 1 invalid (missing L-05); customers 6 invited = 5 returned + 1 nonresponse; 5 valid. Item sums 57/56/55/56/58 and 21/20/20/21/21, means 4.07/4.00/3.93/4.00/4.14 and 4.20/4.00/4.00/4.20/4.20, positive counts 11/11/10/11/12 and 4/4/4/4/4, positive rates 78.6/78.6/71.4/78.6/85.7 and 80.0 across, and 100.0/93.3/83.3/83.3/100.0 rate set all match. Ranking is reproducible under the stated rule (positive rate ascending, then mean ascending, dense ranking): learner P1 L-03, P2 L-02 and L-04, P3 L-01, P4 L-05 with gaps 14.3/7.1/7.1/0.0 percentage points and 0.21/0.14/0.07/0.00 points; customer P1 C-02 and C-03, P2 C-01, C-04, C-05. The §7.2 sensitivity scenario (excluding SYN-L14's 2-point L-03 response) recomputes exactly: n=13, sum 53, mean 4.08, 10/13 = 76.9%, gap narrowing to 8.8 points and 0.07 points, and L-03 remains P1. Follow-up figures reproduce: 51, 4.25, 85, 7.08, Δ_abs 2.83, Δ_rel 66.7%, 9/12 = 75.0%. The §6.4 pairing boundary (14 valid = 12 paired + 2 unavailable, excluded from the paired denominator, not treated as failure) is correctly applied. Rounding follows §5.2 (means/Δ_abs to 2 dp, rates/Δ_rel to 1 dp) and no displayed figure uses a rounded intermediate. N/A and missing rules (§4.3 p.19, §5.1 p.20, §5.2 p.22) are explicit and consistent, and the small-sample suppression rule n<5 is defined and applied to sub-groups with no sub-group data published. The §6.3.3 non-aggregation rule is honoured: learner and customer populations are reported on separate denominators with no pooled rate, and the §6.3.2 'valid returns as share of invitations' figure (5/6) is explicitly distinguished from the validity rate (5/5)."
      },
      {
        "criterion": "5. Direct administration of both tools: eligibility, consent, scale, N/A, incomplete/withdrawn/invalid/valid status, REAL blank dates, invitation/delivery/return, population boundary, privacy/storage, aggregation and hold/reject criteria; proposed controls distinct from implemented operation",
        "verdict": "PASS",
        "exact_locator": "§4.1 PDF pp.10–13; §4.2 PDF pp.13–17; §3.1 SoD PDF p.6; §3.2 SOP P-01…P-10 PDF pp.7–8; 計數界線 blocks PDF pp.9, 13, 17, 22; §5.1 dictionary PDF pp.20–21; §8.1 PDF p.35; §8.3 PDF p.35; §6.3.3 PDF p.28",
        "finding": "Both instruments are directly usable as printed. Tool-A (SURVEY-TOOL-A-L) and Tool-B (SURVEY-TOOL-B-C) each carry a pre-response consent/notice block, a volunteer-participation statement, a field-zone legend separating SAMPLE values from REAL blanks, the 1–5 plus N/A scale legend, and an item matrix with a check column. Status handling is complete and mutually exclusive on both forms: 未回應（NONRESPONSE, with an instruction not to tick it and not to treat it as negative）, 撤回（WITHDRAWN）, 待補正之未完成（INCOMPLETE_PENDING_CORRECTION）, 無效（INVALID）, 有效（VALID）, each with a mutually-exclusive instruction, and a repeated 計數界線 block (PDF pp.13, 17) stating that nonresponse is logged only on the invitation/delivery roster, that every physically returned form counts once as POP_RETURNED regardless of downstream status, that withdrawn/incomplete/invalid forms do not enter POP_VALID or item denominators, and that corrections leave a trace. REAL date fields are blank with explicit format instructions (Tool-A: 班次編號, 培訓日期, 實際填答日期, PDF pp.10–11; Tool-B: 邀請發送日期, 送達日期, 實際填答日期, 回收日期, PDF p.15), and the sample date is fenced as SAMPLE with a no-backfill instruction. Invitation/delivery/return are separated at the counting-boundary level (PDF p.9) and in SOP step P-04 (PDF p.7). Population boundaries are defined per POP_ELIGIBLE / POP_INVITED / POP_RETURNED / POP_VALID (PDF p.20). Privacy and storage are left explicitly UNKNOWN with a candidate control list (§8.3, PDF p.35) rather than asserted. Hold/reject conditions are given per SOP step and consolidated in the §8.1 decision table (可計算 / 暫緩 / 排除單份 / 抑制次分群 / 不得升格 REAL, PDF p.35), including the rule that a single unapproved percentage may not auto-trigger a failure verdict or CAPA (PDF p.6). Every control is labelled 候選設計/提案 and marked as requiring authorised adoption; the document never asserts that any control, committee, role assignment, storage location or recovery channel is in operation, so the proposed/implemented boundary holds throughout."
      },
      {
        "criterion": "6. SAMPLE/SYNTHETIC vs REAL boundaries and replacement-register traceability; no fabricated people, approvals, signatures, courses, respondents, survey execution, outcomes or third-party records; missing REAL items remain UNKNOWN with safe source paths",
        "verdict": "PASS",
        "exact_locator": "文件狀態宣告 PDF p.1; §9.5 PDF pp.39–41; §10 and §10.1 PDF pp.41–42; §8.5 PDF pp.37–38; register CSV body (211 rows, 13 columns) and manifest",
        "finding": "The SAMPLE/SYNTHETIC boundary is enforced at every layer. The status declaration on p.1 states the document is a candidate analysis report with a complete SAMPLE/SYNTHETIC demonstration and that no source proves the association adopted, approved or executed it. No fabricated person, approval, signature, course, respondent, real survey execution, outcome or third-party record was found: the only named entities are the synthetic course 志工服務溝通與紀錄練習, class code SYN-TRN-01 and synthetic dates 2026-07-11 / 2026-08-10, all flagged as synthetic; §8.5's 建議負責人 field is blank with 『姓名未提供；UNKNOWN，不得填入推定人選』; the 感謝函 of 0096 is expressly not fabricated (§9.4). Missing REAL items are held UNKNOWN with safe acquisition paths rather than filled: §9.5 lists 8 promotion classes, each with the needed real source, the corresponding register key and status 未提供；UNKNOWN, and every UNKNOWN row in the register carries real_source_status NOT_PROVIDED plus an explicit 'listed to prevent inference' note. Register traceability is complete: the CSV body supplied in the packet contains 211 data rows, 13 columns, unique register_key, and every row carries a §-anchored document_location with a PDF page; the manifest's fact_status counts (134/13/7/4/53 = 211) reconcile against the body I re-counted by status class. The three retired pooled keys are absent from the current body, consistent with §6.3.3 and the §10 narrative."
      },
      {
        "criterion": "7. Usability for a small volunteer association: SOP, data dictionary, worked case, ranked recommendations, decision criteria, responsibility/deadline/metric fields and follow-up; recommendations separate from authorization/execution",
        "verdict": "PASS",
        "exact_locator": "§3.1 PDF p.6; §3.2 PDF pp.7–9; §5.1 PDF pp.20–21; §5.2 PDF p.22; §6 PDF pp.23–30; §7.2 PDF pp.31–33; §8.1 PDF p.35; §8.4 PDCA PDF pp.36–37; §8.5 PDF pp.37–38; §1.1 PDF p.1",
        "finding": "Usability is high for a small volunteer body and does not assume a committee or dedicated data unit: the SoD matrix names four candidate functions (ROLE-CRD / COL / ANL / DEC) with an explicit scale-limitation fallback requiring an authorised alternative control, and states that no committee, CAPA or file-management process is implied (PDF p.6). The SOP provides ten steps with input, operation/control, output and hold/reject conditions, P-02 explicitly gating release on authorised tool approval, and P-01 gating on a known population and invitation denominator. The data dictionary gives eleven coded fields with denominator, numerator, source form and limits, including N/A and suppression rules, and the formula library gives six reproducible formulae with rounding and N/A guards. The worked case is complete and self-consistent end to end. Ranked recommendations exist at §7.2 (P1 L-03 for the learner track) with a documented ranking rule, an explicit decision criterion (positive rate 10/14, mean 3.93/5) and a sensitivity caveat. The tracking table separates 合成觀察 / 成因狀態 / 改善建議 / 後續核驗方式 / 建議責任職能 / 建議負責人 / 預定期限 / 狀態 into independent columns with fill rules ①–④ that forbid naming a person, forbid assumed deadlines and forbid writing 已改善 without verifiable follow-up data, plus a blank TRK- log table. The PDCA block adds hold/close criteria per stage, including a requirement to compare at least two options. Recommendations are consistently kept distinct from authorization: stage 4 requires verified decision authority, and every candidate proposal is marked as requiring authorised adoption with 實際指派未核定."
      },
      {
        "criterion": "8. Negative-neighbour and title-blind tests reject at least two wrong documents by concrete body-level fields/sections",
        "verdict": "PASS",
        "exact_locator": "§9.3 PDF p.38; §9.4 PDF p.38; §9.1 PDF p.38; §4.3 field mapping PDF pp.17–18; §3.2 SOP codes PDF pp.7–8; §1.4 PDF p.4",
        "finding": "Two wrong documents are rejected on body-level grounds, not labels. Against 0094 / I18-E01 (口述訪談紀錄), §9.3 identifies the distinguishing body content: 0094's artefact is an oral interview record with interview statements and interviewees, whereas 0095 carries dual-track structured instruments, item codes, a scale definition, a field dictionary, formulas, denominators and per-item rates, and the document expressly states it does not pass interview quotes, interviewees or real oral material off as its own survey results. Against 0096 / I18-E03 (感謝函), §9.4 identifies the distinguishing body content: 0096's artefact is a letter with an issuer, content and an original whose provenance must be verified, whereas 0095 is a mechanism analysis report, and the document states it must not impersonate, manufacture or backfill 0096's genuine original. In title-blind terms the two neighbours are rejected on concrete body fields a reader would have to see: SURVEY-TOOL-A-L / SURVEY-TOOL-B-C form codes, LEARN_*/CUST_* field names, P-01…P-10 SOP steps and ROLE-* function codes appear in no other document, while a 訪談逐字稿 or a 感謝函格式 (致受贈單位／敬啟者／署名) appears in none of them. The §9.1 four-document table further states the boundary is derived from official wording and Blueprint division of labour, and does not presume neighbours' real content."
      },
      {
        "criterion": "9. §1.4 page locators against the current 43-page R09 export; no nonexistent subsection cited; §4.1/§4.2/§4.3 page spans cover their actual sections; §7.3–§7.4 point to their actual page; register page locators remain correct; R09 appendices/version lineage and exact R06/R07/R08 history preserved without rewriting prior artefacts",
        "verdict": "PARTIAL",
        "exact_locator": "§1.4 table PDF p.4; §2.4 PDF p.6; §3.2 PDF pp.7–9; §4.1 PDF pp.10–13; §4.2 PDF pp.13–17; §4.3 PDF pp.17–19; §5.1 PDF p.19; §5.2 PDF p.22; §6.1–§6.4 PDF pp.23–30; §7.1–§7.2 PDF pp.31–34; §7.3–§7.4 PDF p.34; §8 PDF pp.35–38; §9.5 PDF pp.39–41; §10 PDF pp.41–43; §10.1/§10.2 PDF pp.42–43; register document_location column (CSV body) and manifest page_locator_basis",
        "finding": "Every section cited in §1.4 exists in the current export — no nonexistent subsection is cited — and the previously defective pointers are now correct where the R08 finding identified them: §7.3–§7.4 → PDF p.34 (both headings print on p.34, resolving the R08 'pp.33–34' defect); §4.1 → pp.10–13 (heading on p.10, form continues to p.13); §4.2 → pp.13–17 (heading on p.13, form to p.17); §4.3 → pp.17–19 (heading on p.17, mapping table to p.19). The register's page locators remain correct: SYN-0095-CASE_ID → p.23, SYN-0095-COURSE_DATE → pp.11/15/23, learner item keys → pp.24–25, customer item keys → pp.25–26, derived learner metrics → p.27, derived customer metrics → p.28, follow-up keys → pp.29 and derived follow-up → p.30, all of which match the current export's actual placement of §6.1, §6.2, §6.3.1, §6.3.2, §6.4 and §6.4.1. Residual locator defects remain in three spans: (a) §5.1 is mapped to pp.20–21, but its heading 5. 資料字典、計算公式與統計口徑規範 and the §5.1 heading both print at the foot of PDF p.19 with the table body on pp.20–21; (b) §6.3.3–§6.4 → pp.28–30 under-covers, since §6.3.3 and §6.4 both open on p.28 and the §6.4.1 derivation runs to p.30; (c) §7.1–§7.2 → pp.31–34 over-covers the ranking matrices (pp.31–32) and merges them with the 附圖 A figure specification (pp.33–34), while the §2.1–§2.4 → pp.5–6 span ends before the §2.4 boundary text completes on p.6. Version lineage is correct and non-destructive: §10.2 (PDF pp.42–43) records R05–R09 with dates, records R06 SHA 71398b10…fa4, R07 SHA ba6100f3…394, R08 SHA e9322191…ce31a1, the R08 review response path and its SHA 914a9d8f…1a89, keeps R06/R07 historical CSV and manifest artefacts unchanged (Attachment A-2/A-3 with their own SHAs) and states that R09 keeps the R08 register and manifest unchanged; the R09 row (PDF p.43) records that NB-R08-02 was a misjudgement confirmed by the R06/R08 key-set reconciliation and that the R09 register is unchanged, with the CSV SHA 203583e4…0202c and manifest SHA df1b2517…17c0 bound in §10/§10.1."
      },
      {
        "criterion": "10. Remaining material contradiction, unsupported claim, ambiguous field, unusable form, arithmetic mismatch, overclaim, required omission or traceability defect",
        "verdict": "PARTIAL",
        "exact_locator": "§1.4 rows 1 and 4 (PDF p.4); §10 lineage sentence (PDF p.41); §10.2 R09 row (PDF p.43); §9.5 row 6 register-key count (PDF p.40); manifest r08_current_rows_from_r06 / r08_added_unknown_index_rows / retired_r08_rows; §8.1 不得升格 REAL row (PDF p.35) vs §10.1 Attachment D/E (PDF p.42)",
        "finding": "No material contradiction, arithmetic mismatch, overclaim, unusable form, fabricated fact or unsafe REAL claim was found; the residual defects are traceability precision and count-presentation defects, and they are itemised in nonblocking_findings. Four residual items: (i) §1.4 §5.1 and §6.3.3–§6.4 page spans do not match the sections' actual pages (criterion 9); (ii) the §10 lineage sentence (PDF p.41) states '保留 205 鍵並新增 6 個 UNKNOWN 升格索引鍵…移除 3 個…鍵' without stating the 208-key R06 base, so the sentence's own arithmetic does not visibly close to the delivered 211 rows (the R09 note on p.43 and the manifest do close it, and the R06/R08 key-set reconciliation confirms the contested key is retained rather than added, so no row is unaccounted for); (iii) §9.5 row 6 (PDF p.40) describes 'L-01–L-05 與 C-01–C-05 各題之 SUM／MEAN／POSN／POSRATE 衍生鍵…共 40 列', but the register body actually contains 40 derived item-metric keys (10 items × 4) plus 4 derived rate keys (LEARNER_RETURN_RATE, LEARNER_VALID_RATE, CUSTOMER_RETURN_RATE, CUSTOMER_VALID_RATE) that the row's own parenthetical lists separately, making the '40' understate the derived-metric population; (iv) Attachment E (PDF p.42) records the R09 receipts as 待執行 while the manifest state remains CANDIDATE_QA_PENDING, which is internally consistent but leaves the candidate's QA chain open at R09 by design."
      }
    ],
    "r08_finding_disposition": [
      {
        "id": "R08-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 evidence-locator table, PDF p.4, third column (文件證據定位), rows 1–4; actual section locations: §4.1 PDF p.10, §4.2 PDF p.13, §4.3 PDF p.17, §5.1 PDF p.19, §5.2 PDF p.22, §6.3.3 PDF p.28, §6.4 PDF p.28, §6.4.1 PDF p.30, §7.1 PDF p.31, §7.2 PDF p.31, 附圖 A PDF pp.33–34, §7.3 PDF p.34, §7.4 PDF p.34, §8.1 PDF p.35, §9.5 PDF pp.39–41, §10 PDF pp.41–43",
        "rationale": "The specific defect R08-01 named is fixed: §7.3–§7.4 is now cited to PDF p.34 only, where both headings actually print, and the row-1/row-2/row-3 spans for §4.1/§4.2/§4.3 (§2.1–§2.4 → pp.5–6, §3.1 → p.6, §3.2 → pp.7–9, §8.1–§8.5 → pp.35–38, §6.1–§6.4 → pp.23–30) now agree with the observed section starts. The table is also self-limited by the pagination-anchor warning immediately below it (PDF p.5) and by the R08 lineage note (PDF p.41). It is not fully closed because three spans remain mis-anchored against the current 43-page export: §5.1 → pp.20–21 although §5.1 opens on p.19; §6.3.3–§6.4 → pp.28–30 although §6.4.1 extends to p.30 and both cited headings open on p.28; and §7.1–§7.2 → pp.31–34 although the ranking matrices occupy pp.31–32 and 附圖 A occupies pp.33–34. These are audit-trail precision defects in the document's primary traceability table, not false pointers, so the finding is marked PARTIALLY_CLOSED rather than CLOSED."
      },
      {
        "id": "R08-02",
        "disposition": "CLOSED",
        "exact_locator": "Register row SYN-0095-CUSTOMER_VALID_RETURN_SHARE (CSV body; document_location '§6.3.2 / valid target-customer returns as share of delivered invitations；PDF p. 28'); §10 lineage sentence PDF p.41; §10.2 R09 row PDF p.43; manifest r08_current_rows_from_r06 = 205, r08_added_unknown_index_rows = 6, retired_r08_rows = 3, row_count = 211",
        "rationale": "R08-02 alleged an uncounted added key. The supplied R06/R08 key-set reconciliation shows SYN-0095-CUSTOMER_VALID_RETURN_SHARE is present in R06 and in R08 with the same fact_status, fact_type, value 83.3 and unit percent (only document_location gains the PDF p. 28 locator), so it is among the 205 retained keys and is neither an addition nor a retirement. The complete key-set difference is exactly the three listed removals (COMBINED_RETURN_RATE, COMBINED_VALID_RATE, POOLED_POSITIVE_RATE) and the six listed UNKNOWN additions, giving 208 − 3 + 6 = 211, which I confirmed against the CSV body I re-counted in the packet. I therefore do not repeat the allegation. The residual, narrower defect is presentational rather than evidentiary: the §10 sentence on p.41 gives 205 + 6 − 3 without naming the 208-key R06 base, so the sentence does not visibly close to 211 on its face, and the R09 version note on p.43 plus the manifest supply the closing arithmetic."
      },
      {
        "id": "R08-03",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF p.10, block 『【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】』 immediately above 示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）：SYN-TRN-01, PDF p.11; §4.2 PDF p.14, same block above 示範班次代號 SYN-TRN-01; §4.2 PDF p.15, 『示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11』 above 邀請發送日期／送達日期／實際填答日期／回收日期 (all REAL blanks)",
        "rationale": "R08-03 flagged the literal wording 'no approved class identifier' sitting one line above a filled sample code and a prefilled sample date, creating a residual risk that a prefilled sample value could be read as an administration fact. R09 has closed this directly: both instruments now carry an explicit header stating that no verified and approved real class identifier is provided and that the following code is a synthetic demonstration only, and the sample code and sample date are each individually labelled SAMPLE／SYNTHETIC／未核定／非實際辦訓日期. The surrounding REAL fields are blank with format instructions and a prohibition on back-filling the sample date into the REAL fields, and the 欄位分區說明 legend states that the sample sheet leaves every REAL field blank. The wording risk R08-03 identified is therefore no longer present in the current text."
      },
      {
        "id": "R08-04",
        "disposition": "OPEN",
        "exact_locator": "§10.1 附件 D (0095_R09_CANDIDATE.pdf; PDF SHA-256 及頁數由同套件最終 QA 清冊綁定) and 附件 E (0095_R09 technical, visual and semantic review receipts; 『R09 收據於本版製稿時尚待產生，狀態為待執行』) PDF p.42; §10.2 R09 row PDF p.43; manifest state CANDIDATE_QA_PENDING",
        "rationale": "This is a workflow state rather than a document-body defect, and it is still open by design at R09: the candidate's own QA chain is open, Attachment D binds the Word-exported PDF only through an external final-QA list, and Attachment E records the R09 technical, visual and semantic receipts as not yet produced. The document is consistent with this — it does not self-declare PASS, states that the independent semantic review result must be taken from the external package receipt bound to this version's DOCX SHA, and the manifest carries CANDIDATE_QA_PENDING. I record it as OPEN because the R09 receipts do not exist in the supplied evidence; it is not counted as a material semantic defect and does not affect the body assessment."
      },
      {
        "id": "R08-05",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.33 (L-03 非正向 4 份, 識別 SYN-L14 2 分 / SYN-L04 / SYN-L11 3 分, 1 份未逐筆識別; 情境演算 n=13, sum 53, mean 約 4.08, 10/13 = 76.9%, 差距收斂為 8.8 個百分點與 0.07 分; 目標客戶端 n=5 每題各 1 份非正向回覆, 單一填答者對應 20 個百分點); §7.3 item 1 小樣本限制, PDF p.34; §6.4 追蹤遺漏處理, PDF p.29; §8.4 PDF p.36; §8.5 PDF pp.37–38",
        "rationale": "R08-05 concerned the residual inherent limitation of a 14-respondent synthetic sample and the customer track's n=5 giving each respondent 20 percentage points of influence. R09 keeps both sensitivities disclosed with the causes UNKNOWN and an explicit prohibition on inferring group differences: the L-03 single-2-point scenario is recomputed and shown not to change the P1 ranking, the note states the scenario is a sensitivity calculation rather than a re-test result and not a basis for excluding that response, and the customer track's 20-point-per-respondent effect is stated with the reading limit that the five customer facets share the same 4/5 positive count and therefore cannot be read as agreement or representativeness. §7.3 adds small-sample and nonresponse-causality limits, §6.4 excludes the 2 unpaired learners from the paired denominator without treating them as failures, and §8.4/§8.5 keep cause, owner, deadline and status UNKNOWN or blank. The sensitivity is disclosed rather than concealed, so the finding is closed for the purposes of the review; the underlying small-sample limitation persists as an inherent property of the SAMPLE/SYNTHETIC design and is carried in the nonblocking list and unknowns."
      }
    ],
    "blocking_findings": [],
    "nonblocking_findings": [
      {
        "id": "NB-R09-01",
        "severity": "LOW_MEDIUM",
        "title": "§1.4 locator column still mis-anchors three section spans against the current 43-page R09 export",
        "locator": "§1.4 table PDF p.4: row 1 third column '§5.1 → pp.20–21' (actual §5.1 heading and the chapter-5 heading print at the foot of PDF p.19); row 1 '§5.2 → p.22' (correct, §5.2 opens on p.22); row 4 '§6.3.3–§6.4 → PDF pp.28–30' (both cited headings open on p.28, but the §6.4.1 derivation runs to p.30); row 3 '§7.1–§7.2 → pp.31–34' (ranking matrices occupy pp.31–32, 附圖 A occupies pp.33–34); row 1/row 2 '§2.1–§2.4 → PDF pp.5–6' (the §2.4 boundary text completes on p.6–7)",
        "finding": "R09's rewrite of the primary traceability table fixed the R08-01 defect at §7.3–§7.4 and at §4.1/§4.2/§4.3, but the same column still carries spans whose start or end does not match the sections actually printed. §5.1's start page is wrong by one page and §6.3.3–§6.4's span does not cover §6.4.1. Because the document itself warns that page anchors must not be inherited across re-exports (PDF pp.5, 41) and the register's own row-level locators are correct, this is a precision defect in the audit trail rather than a false pointer, but it is the table a reviewer uses to navigate, so each section should be anchored to its own start page."
      },
      {
        "id": "NB-R09-02",
        "severity": "LOW",
        "title": "§10 lineage sentence does not state the R06 base count, so its own arithmetic does not visibly close to the delivered 211 rows",
        "locator": "§10 body, PDF p.41: '該清冊為 211 筆資料列、13 欄，其中 205 個仍適用之 R06 鍵保留，6 個 UNKNOWN 升格索引鍵新增…R08 移除 3 個不再使用的合併／合併正向率衍生鍵'; §10 R08 補充說明 (3), PDF p.41; manifest r08_current_rows_from_r06 = 205, r08_added_unknown_index_rows = 6, retired_r08_rows = 3, row_count = 211; §10.2 R09 row PDF p.43",
        "finding": "The §10 sentence expresses the lineage as 205 retained + 6 added − 3 retired, which does not reach 211 as printed unless the reader supplies the 208-key R06 base. The correct closure is 208 (R06) − 3 retired + 6 added = 211, and this is stated in the R09 version note on p.43 and encoded in the manifest (r06_historical_row_count = 208). Because the R06/R08 key-set reconciliation confirms the only contested key, SYN-0095-CUSTOMER_VALID_RETURN_SHARE, exists in R06 and R08 as a retained key rather than an uncounted addition, no register row is unaccounted for and no factual claim is false. The defect is that the primary lineage statement in §10 omits the 208-key base; adding it (or restating as 211 = 208 − 3 + 6) closes the sentence on its face."
      },
      {
        "id": "NB-R09-03",
        "severity": "LOW",
        "title": "§9.5 row 6 understates the derived-metric register population by omitting the four derived rate keys from its '40 列' count",
        "locator": "§9.5 row 6, PDF p.40: 'L-01–L-05 與 C-01–C-05 各題之 SUM／MEAN／POSN／POSRATE 衍生鍵（如 SYN-0095-LEARNER-L-01-SUM、SYN-0095-CUSTOMER-C-05-POSRATE 等，共 40 列）、SYN-0095-LEARNER_RETURN_RATE、SYN-0095-CUSTOMER_RETURN_RATE'; register body contains SYN-0095-LEARNER_VALID_RATE and SYN-0095-CUSTOMER_VALID_RATE in addition",
        "finding": "I counted the derived item-metric keys in the supplied register body: 10 items × 4 keys (SUM, MEAN, POSN, POSRATE) = 40, which is what the row states; but the body also carries four derived rate keys (SYN-0095-LEARNER_RETURN_RATE 83.3, SYN-0095-LEARNER_VALID_RATE 93.3, SYN-0095-CUSTOMER_RETURN_RATE 83.3, SYN-0095-CUSTOMER_VALID_RATE 100.0), of which the row's parenthetical names only the two RETURN_RATE keys. The '40 列' therefore reads as the whole derived-metric population when it is only the item-metric subset, and the two VALID_RATE keys are the ones left outside the sentence's own list. This is a count-precision defect in the REAL-promotion index, not a missing registration: all four keys are present in the register, correctly valued and keyed, and the manifest's 53 DERIVED_SYNTHETIC_METRIC rows reconcile with the body."
      },
      {
        "id": "NB-R09-04",
        "severity": "INFORMATIONAL",
        "title": "R09 QA chain remains open by design at the time of the candidate's drafting",
        "locator": "§10.1 附件 D and 附件 E, PDF p.42 (附件 E: 'R09 收據於本版製稿時尚待產生，狀態為待執行'); §10.2 R09 row, PDF p.43 ('本版仍為 CANDIDATE，R09 QA 以外部 exact-SHA 收據為準'); manifest state CANDIDATE_QA_PENDING",
        "finding": "The R09 technical, visual and semantic receipts did not exist in the supplied evidence, and Attachment D still binds the Word-exported PDF only through an external final-QA list. This is consistent with the CANDIDATE state and with the document's own prohibition on self-declaring PASS, so it is recorded as a workflow state rather than a body defect. It does mean that the figure-rendering confirmation required by the Blueprint's font-size and figure acceptance tests, and the R09 receipt chain itself, remain outstanding and must be satisfied by the separate exact-SHA visual receipt and the external QA list before any formal acceptance step."
      },
      {
        "id": "NB-R09-05",
        "severity": "INFORMATIONAL",
        "title": "Improvement-candidate robustness continues to rest on a 14-respondent synthetic learner sample and a 5-respondent synthetic customer sample",
        "locator": "§7.2 sensitivity note, PDF p.33; §7.3 items 1–2, PDF p.34; §6.1 PDF pp.24–25; §6.2 PDF pp.25–26; §6.3.3 PDF p.28; §8.5 PDF p.37",
        "finding": "R09 discloses this fully — the L-03 single-record sensitivity is recomputed and shown not to change the ranking, the customer track's 20-points-per-respondent effect is stated, nonresponse reasons are UNKNOWN, and §6.3.3 forbids pooled or cross-group comparison — so the limitation is inherent to the SAMPLE/SYNTHETIC design and is presented, not concealed. It requires no change other than continued presentation as SAMPLE/SYNTHETIC and continued refusal to characterise the numbers as association performance, and it should be re-stated explicitly if any figure derived from these data is later reused outside this document."
      }
    ],
    "material_arithmetic_checks": [
      {
        "item": "Learner population reconciliation (POP_INVITED / POP_RETURNED / POP_VALID / nonresponse)",
        "locator": "§6.1 PDF p.24; §3.2 counting boundary PDF p.9; §5.1 PDF p.20; §6.3.1 PDF p.27",
        "recomputed": "18 invited = 15 returned + 3 nonresponse; 15 returned = 14 valid + 1 invalid; 3 = 18 − 15; 1 = 15 − 14",
        "verdict": "MATCH"
      },
      {
        "item": "Learner return rate and validity rate",
        "locator": "§6.3.1 items 1–2, PDF p.27; register SYN-0095-LEARNER_RETURN_RATE / SYN-0095-LEARNER_VALID_RATE",
        "recomputed": "15/18 = 83.333% → 83.3%; 14/15 = 93.333% → 93.3%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-01 任務關聯性: sum, mean, positive count, positive rate",
        "locator": "§6.1 PDF pp.24–25; §6.3.1 item 3, PDF p.27; register SYN-0095-LEARNER-L-01-SUM/MEAN/POSN/POSRATE",
        "recomputed": "5+5+4+3+5+4+4+5+4+4+3+5+4+2 = 57; 57/14 = 4.0714 → 4.07; 11 values ≥ 4 → 11/14 = 78.571% → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-02 目標引導清晰度",
        "locator": "§6.3.1 item 4, PDF p.27; register SYN-0095-LEARNER-L-02-*",
        "recomputed": "4+4+5+4+5+4+3+5+4+3+4+4+4+3 = 56; 56/14 = 4.00; positive 11 (L01,L02,L03,L04,L05,L06,L08,L09,L11,L12,L13) → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-03 演練操作價值",
        "locator": "§6.3.1 item 5, PDF p.27; register SYN-0095-LEARNER-L-03-*",
        "recomputed": "5+4+4+3+4+4+4+5+3+4+3+5+4+3 = 55; 55/14 = 3.9286 → 3.93; positive 10 (L01,L02,L03,L05,L06,L07,L08,L10,L12,L13) → 71.428% → 71.4%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-04 講師支持度",
        "locator": "§6.3.1 item 6, PDF p.27; register SYN-0095-LEARNER-L-04-*",
        "recomputed": "5+4+4+4+5+3+4+4+4+3+4+5+4+3 = 56; 56/14 = 4.00; positive 11 (L01,L02,L03,L04,L05,L07,L08,L09,L11,L12,L13) → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-05 整體滿意度",
        "locator": "§6.3.1 item 7, PDF p.27; register SYN-0095-LEARNER-L-05-*",
        "recomputed": "5+5+4+4+5+4+4+5+4+4+3+5+4+2 = 58; 58/14 = 4.1428 → 4.14; positive 12 (L01–L10, L12, L13) → 85.714% → 85.7%",
        "verdict": "MATCH"
      },
      {
        "item": "Customer population reconciliation and rates",
        "locator": "§6.2 PDF pp.25–26; §6.3.2 item 1, PDF p.28; register SYN-0095-CUSTOMER_INVITED/RETURNED/VALID/NONRESPONSE and the four rate keys",
        "recomputed": "6 invited = 5 returned + 1 nonresponse; 5 returned = 5 valid; 5/6 = 83.333% → 83.3% (return rate); 5/5 = 100.0% (validity rate); 5/6 = 83.3% valid-returns-as-share-of-invitations, explicitly distinguished from the validity rate",
        "verdict": "MATCH"
      },
      {
        "item": "Customer item sums, means, positive counts and rates (C-01…C-05)",
        "locator": "§6.3.2 items 2–6, PDF p.28; register SYN-0095-CUSTOMER-C-01…C-05-* (20 keys)",
        "recomputed": "C-01 5+4+5+3+4 = 21 → 4.20, positive 4 → 80.0%; C-02 5+4+4+3+4 = 20 → 4.00, positive 4 → 80.0%; C-03 4+4+5+3+4 = 20 → 4.00, positive 4 → 80.0%; C-04 5+4+5+3+4 = 21 → 4.20, positive 4 → 80.0%; C-05 5+4+5+3+4 = 21 → 4.20, positive 4 → 80.0%",
        "verdict": "MATCH"
      },
      {
        "item": "Follow-up pairing boundary and outcome figures",
        "locator": "§6.4 PDF p.29; §6.4.1 PDF p.30; register SYN-0095-SYN-L01…L12-PRE/POST30 (24 keys) and SYN-0095-FOLLOWUP_* (8 keys)",
        "recomputed": "14 valid = 12 paired + 2 unavailable (2 excluded from paired denominator, not counted as failures); Σpre = 4+5+6+3+4+5+6+2+4+5+3+4 = 51 → 4.25; Σpost = 7+8+8+6+7+8+8+5+7+8+6+7 = 85 → 7.08; Δ_abs = (85−51)/12 = 2.8333 → 2.83; Δ_rel = 34/51 = 0.66666 → 66.7%; post ≥ 7 for L01,L02,L03,L05,L06,L07,L09,L10,L12 = 9 → 9/12 = 75.0%; per-row Δ values +3,+3,+2,+3,+3,+3,+2,+3,+3,+3,+3,+3 all match the table",
        "verdict": "MATCH"
      },
      {
        "item": "Learner ranking, gaps and dense-rank application under the §7.2 rule",
        "locator": "§7.2 learner matrix, PDF pp.31–32; §7.1 comparison table, PDF p.31",
        "recomputed": "Positive rate ascending then mean ascending: L-03 71.4%/3.93 → P1; L-02 78.6%/4.00 and L-04 78.6%/4.00 → P2; L-01 78.6%/4.07 → P3; L-05 85.7%/4.14 → P4. Gaps to in-group top (L-05 85.7%, 4.14): 14.3/0.21, 7.1/0.14, 7.1/0.14, 7.1/0.07, 0.0/0.00",
        "verdict": "MATCH"
      },
      {
        "item": "Customer ranking, gaps and dense-rank application",
        "locator": "§7.2 customer matrix, PDF p.32; §7.1 PDF p.31; 序位解讀界線 PDF p.33",
        "recomputed": "All five positive rates 4/5 = 80.0%, so ordering is decided by mean alone: C-02 4.00 and C-03 4.00 → P1; C-01 4.20, C-04 4.20, C-05 4.20 → P2. Gaps: 0.0 points for all; mean gaps 0.20 for C-02/C-03 and 0.00 for C-01/C-04/C-05. §7.1's statement that the customer track has no relative highest or lowest positive-rate item and that the two lowest-mean items are 辦訓安排 and 實作演練 is consistent",
        "verdict": "MATCH"
      },
      {
        "item": "Single-record sensitivity scenario for L-03",
        "locator": "§7.2 sensitivity note, PDF p.33",
        "recomputed": "Removing SYN-L14's 2-point L-03 response: n = 13, sum = 55 − 2 = 53, mean = 53/13 = 4.0769 → ≈ 4.08, positive = 10/13 = 76.923% → 76.9%; positive-rate gap to L-05 (85.714%) = 8.79 → 8.8 points; mean gap to 4.1429 = 0.0660 → 0.07 points; P1 ordering retained because 76.9% < 78.6% of L-02/L-04/L-01",
        "verdict": "MATCH"
      },
      {
        "item": "Rounding, N/A, missing-value and suppression rules versus the displayed values",
        "locator": "§5.2 rounding paragraph, PDF p.22; §4.3 N/A paragraph, PDF p.19; §5.1 MISSING_ITEM/NA_TREATMENT/SUB_SUPPRESS, PDF pp.20–21; §8.1, PDF p.35",
        "recomputed": "Means and Δ_abs shown to 2 dp, rates and Δ_rel to 1 dp as required; no displayed figure is derived from a rounded intermediate (e.g. 34/51 computed from raw sums 85 and 51, 2.8333 from 34/12, not from 7.08−4.25); N/A excluded from item denominators and not treated as 0; core-item missing renders the form invalid; n<5 sub-group suppression defined and no sub-group results published",
        "verdict": "MATCH"
      },
      {
        "item": "Register row/column/unique-key totals and fact_status counts against the manifest",
        "locator": "Supplied register CSV body; manifest row_count 211, column_count 13, unique_register_key true, fact_status_counts 134/13/7/4/53, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3",
        "recomputed": "Status counts 134 + 13 + 7 + 4 + 53 = 211, matching row_count 211 and column_count 13; 208 (R06) − 3 retired + 6 added = 211, consistent with the deterministic R06/R08 key-set reconciliation; the three retired keys are absent from the current body and all six listed UNKNOWN additions are present",
        "verdict": "MATCH"
      },
      {
        "item": "Population non-aggregation and denominator separation",
        "locator": "§6.3.3, PDF p.28; §6.1/§6.2 denominators, PDF pp.24–26; §6.3.2 note, PDF p.28; §7.1, PDF p.31; 附圖 A 警示, PDF p.34",
        "recomputed": "Learner denominators (18/15/14) and customer denominators (6/5/5) are used separately throughout; no pooled return rate, pooled positive rate or combined satisfaction figure appears anywhere in the R09 text; the three retired combined/pooled register keys are absent; §6.3.2's 5/6 figure is labelled as a share of the invitation population and not as a validity rate, avoiding a cross-metric conflation",
        "verdict": "MATCH"
      },
      {
        "item": "Source-hash internal consistency across the packet",
        "locator": "§1.2 PDF p.2; §1.3 PDF p.2; §10 PDF p.41; §10.1 附件 A/A-1 PDF p.41–42; packet header",
        "recomputed": "Official source PDF SHA 805386b7…4709 (§1.2), indicator-18 scoring-form page-4 extract SHA c789f8f0…adcf and its source form SHA 9d253829…83684 (§1.3), register CSV SHA 203583e4…0202c (§10 and 附件 A), manifest SHA df1b2517…17c0 (§10 and 附件 A-1) — all match the packet-supplied values and the CSV/manifest are the same R08 artefacts bound in the packet; official page-6 extract SHA e0ecd2d7…20f02 and Blueprint row SHA 9a22b3ac…79c2 are consistent with the manifest's source_refs. Hashes were compared for internal consistency only and were not independently recomputed",
        "verdict": "MATCH"
      }
    ],
    "unknowns": [
      "Whether the DOCX file actually renders a drawn 附圖 A: the packet supplies the figure's full specification, panel values, presentation rules, warnings and alt-text draft (PDF pp.33–34) but the text-only evidence does not encode pixels, so per the packet instruction no missing chart is alleged. Figure rendering is to be confirmed by the separate exact-SHA visual receipt.",
      "Typography compliance with the Blueprint floors (body ≥ 10.5pt, tables ≥ 9.5pt), column fit, orphan headings, blank pages, header/footer consistency and any image objects in the DOCX: not measurable from text-only PDF extraction.",
      "Actual page count and byte-level identity of the R09 DOCX (262592 bytes) and the R09 Word-exported PDF (43 pages, SHA ab78192f…a23f): taken from the packet; the DOCX was not rehashed and the PDF was not re-rendered or re-hashed by the reviewer.",
      "Whether the four R09 QA receipts (technical, visual, semantic, final-QA list binding the PDF SHA and page count) have since been produced: Attachment E records them as 待執行 and the manifest as CANDIDATE_QA_PENDING.",
      "All association-side facts remain UNKNOWN/NOT PROVIDED by design and are correctly held as such in the candidate: existing survey system or adoption, committee or unit structure, authorised roles, approval and signature originals, formal and effective dates, real class/cohort identifiers, real invitation/delivery/return/valid counts, original questionnaires, nonresponse reasons, the invalid form's identity and other item values, real respondent roles and organisation, storage/access/retention paths, and improvement decision, responsible person, deadline and follow-up originals.",
      "Whether the real-system promotion path (§9.5) can be closed on the required eight item classes, and whether any scored TTQS position follows: not determinable from the packet and outside this review's scope.",
      "Runtime/provider model identity: UNKNOWN absent direct attestation by the executing runtime."
    ],
    "reviewer_limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used or attempted; no DOCX binary rehash, no PDF re-render, no DOCX XML extraction, and no font-size or layout measurement.",
      "No visual inspection of the 43-page export was performed; every page, table, row, cell and heading reference above is read from the packet's page-bounded PDF text. Image presence or absence (including whether 附圖 A exists as a drawn object) and typography could not be confirmed.",
      "All arithmetic was recomputed by hand from the raw response rows printed in §6.1, §6.2 and §6.4 and from the CSV body reproduced in the packet; no spreadsheet or calculation engine was used.",
      "SHA-256 values (DOCX, PDF, CSV, manifest, official sources, Blueprint row) were compared for internal consistency only and were not independently recomputed; the reviewed DOCX SHA is bound exactly as supplied by the packet.",
      "Findings are bound to the DOCX SHA-256 e1be4a9e…0ed8e as supplied. Any re-export, re-layout or content change invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, not an evaluation of the association's real practice, and not formal association acceptance. The deliverable remains CANDIDATE.",
      "R08's five findings were reassessed independently from the current R09 evidence and the deterministic R06/R08 key-set reconciliation; where the reconciliation contradicts an allegation (R08-02), the allegation was not repeated, and no prior artefact was rewritten in the process."
    ],
    "provider_model_identity": "UNKNOWN — no direct attestation of the executing runtime or provider model was available in the packet; the requested route was OpenCode CLI v2.0.32 / opencode/minimax-m3.1-flash-free, but the reviewer cannot attest which model actually produced this response."
  },
  "R09_receipt": {
    "doc_id": "0095",
    "revision": "R09",
    "requirement_id": "I18-E02",
    "official_checkbox": "建立目標客戶及學員滿意度調查機制（系統及流程面）。",
    "reviewer_route": "OpenCode CLI v2.0.32",
    "requested_model": "opencode/minimax-m3.1-flash-free",
    "provider_model_identity": "UNKNOWN",
    "reviewer_session_id": "ses_ea6bb354cffexYXYJtsp2ssyge",
    "review_scope": "Independent packet-only semantic review; current PDF text, official source, Blueprint, R08 findings and register reconciliation; no visual inspection or binary SHA recomputation",
    "reviewed_docx_sha256": "e1be4a9e9a0c61216416f6ff955bb1be3ed5d1f636550ea82bea4b5431e0ed8e",
    "pdf_sha256": "ab78192fb5297b88ecd240eee21ed08f52d7e8a0f5c53e9edf04568f8217a23f",
    "packet_sha256": "c054be1b88e97b7a4e759d179b5671518ddff29d93b49180df80969f8910981f",
    "raw_stdout_sha256": "c6df9a5bb3f53d513d84df06da8d0cd8f7285a3efd65f6f6e7637d2c5a0fc19b",
    "normalized_response_sha256": "4a10c02eb0aa6af0214782b03662c794568a93995f576148ca53ce082b19c530",
    "verdict": "PARTIAL",
    "blocking_findings": 0,
    "nonblocking_findings": [
      "NB-R09-01",
      "NB-R09-02",
      "NB-R09-03",
      "NB-R09-04",
      "NB-R09-05"
    ],
    "criterion_verdicts": [
      "1. Official I18-E02 wording, DOCX 0095, analysis-report genre, case mapping, title-blind identifiability, separation from 0094/I18-E01 and 0096/I18-E03=PASS",
      "2. All Unique Blueprint sections, required tables/figure/analysis, questions, calculations, direct usability and acceptance tests=PASS",
      "3. Reassessment of the five R08 findings (R08-01 page-map precision; R08-02 uncounted CUSTOMER_VALID_RETURN_SHARE; R08-03 sample class wording; R08-04 review receipt status; R08-05 small-sample sensitivity)=PARTIAL",
      "4. Recomputation of all learner/customer raw counts, sums, means, positive counts/rates, rankings, gaps, single-record sensitivity, outcome figures, denominators, missing/N/A rules, rounding and suppression; no merging of distinct respondent populations=PASS",
      "5. Direct administration of both tools: eligibility, consent, scale, N/A, incomplete/withdrawn/invalid/valid status, REAL blank dates, invitation/delivery/return, population boundary, privacy/storage, aggregation and hold/reject criteria; proposed controls distinct from implemented operation=PASS",
      "6. SAMPLE/SYNTHETIC vs REAL boundaries and replacement-register traceability; no fabricated people, approvals, signatures, courses, respondents, survey execution, outcomes or third-party records; missing REAL items remain UNKNOWN with safe source paths=PASS",
      "7. Usability for a small volunteer association: SOP, data dictionary, worked case, ranked recommendations, decision criteria, responsibility/deadline/metric fields and follow-up; recommendations separate from authorization/execution=PASS",
      "8. Negative-neighbour and title-blind tests reject at least two wrong documents by concrete body-level fields/sections=PASS",
      "9. §1.4 page locators against the current 43-page R09 export; no nonexistent subsection cited; §4.1/§4.2/§4.3 page spans cover their actual sections; §7.3–§7.4 point to their actual page; register page locators remain correct; R09 appendices/version lineage and exact R06/R07/R08 history preserved without rewriting prior artefacts=PARTIAL",
      "10. Remaining material contradiction, unsupported claim, ambiguous field, unusable form, arithmetic mismatch, overclaim, required omission or traceability defect=PARTIAL"
    ],
    "r08_findings": [
      "R08-01=PARTIALLY_CLOSED",
      "R08-02=CLOSED",
      "R08-03=CLOSED",
      "R08-04=OPEN",
      "R08-05=CLOSED"
    ],
    "limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used or attempted; no DOCX binary rehash, no PDF re-render, no DOCX XML extraction, and no font-size or layout measurement.",
      "No visual inspection of the 43-page export was performed; every page, table, row, cell and heading reference above is read from the packet's page-bounded PDF text. Image presence or absence (including whether 附圖 A exists as a drawn object) and typography could not be confirmed.",
      "All arithmetic was recomputed by hand from the raw response rows printed in §6.1, §6.2 and §6.4 and from the CSV body reproduced in the packet; no spreadsheet or calculation engine was used.",
      "SHA-256 values (DOCX, PDF, CSV, manifest, official sources, Blueprint row) were compared for internal consistency only and were not independently recomputed; the reviewed DOCX SHA is bound exactly as supplied by the packet.",
      "Findings are bound to the DOCX SHA-256 e1be4a9e…0ed8e as supplied. Any re-export, re-layout or content change invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, not an evaluation of the association's real practice, and not formal association acceptance. The deliverable remains CANDIDATE.",
      "R08's five findings were reassessed independently from the current R09 evidence and the deterministic R06/R08 key-set reconciliation; where the reconciliation contradicts an allegation (R08-02), the allegation was not repeated, and no prior artefact was rewritten in the process."
    ],
    "formal_acceptance": "NOT_ASSERTED",
    "created_utc": "2026-10-20T12:26:28Z"
  },
  "R10_response": {
    "overall_verdict": "PARTIAL",
    "reviewed_docx_sha256": "4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630",
    "review_scope": "Packet-only independent semantic review of the R10 candidate for DOCX 0095 / I18-E02. All findings derive solely from the packet-supplied current R10 Word-exported PDF text (44 pages), the supplied R08 replacement-register CSV body (211 rows, 13 columns), the supplied register manifest, the Unique Blueprint and source binding, the R08 exact-SHA review and the deterministic R06/R08 register key-set reconciliation, the R09 exact-SHA review response and targeted repair manifest, and the R10 technical / visual / font-floor receipts (scope only). No shell, filesystem, browser, GUI, DOCX-binary rehash, PDF re-render, or visual inspection was performed or claimed; no prior PASS was inherited from the builder or from the R08/R09 reviews, and each R08/R09 finding was re-derived from the current R10 text. The DOCX SHA-256 4c52fe99…ee3630 is bound as the review target exactly as supplied by the packet and was not independently rehashed. This review assesses semantic content only; it is not a TTQS assessment, not a score, and not formal association acceptance. The candidate remains CANDIDATE.",
    "criteria": [
      {
        "criterion": "1. Official I18-E02 wording, DOCX 0095, analysis-report genre, case mapping, title-blind identifiability, and separation from 0094/I18-E01 and 0096/I18-E03",
        "verdict": "PASS",
        "exact_locator": "PDF p.1 文件狀態宣告 and title; §1.1 PDF p.1; §1.2 PDF pp.1–2; §1.3 PDF pp.2–3; §1.4 PDF p.4; §9.1–§9.4 PDF p.37; running header '候選分析報告 DOCX 0095 / I18-E02 • 第 N 頁' on all pages",
        "finding": "The official checkbox text 『建立目標客戶及學員滿意度調查機制（系統及流程面）。』 is reproduced verbatim in §1.2 (PDF pp.1–2) with the official source PDF SHA-256 805386b7…4709 and readback status PDF_TEXT_EXACT_PAGE_MATCH against official source page 6, matching the supplied page-6 extract SHA e0ecd2d7…20f02. Indicator 18's 1–4 分 grading bands are quoted verbatim in §1.3 (PDF pp.2–3) from the scoring form page 4, and the document explicitly separates the two official instruments (查核佐證資料表 = I18-E02 checkbox source; 評核表 = scoring basis) so they are not conflated; it also states 本件不對應任何官方分數, 不能推定 0 分, 也不能宣稱 1 分 (PDF p.3). DOCX 0095 / I18-E02 appears in the running header and the status declaration. Genre is an analysis/evaluation report (§1 executive summary, §2 architecture, §3 SoD/SOP, §4 instruments, §5 dictionary/formulae, §6 worked synthetic case, §7 group analysis, §8 controls/PDCA, §9 neighbours, §10 register/version lineage). Title-blind identifiability holds on body-level fields: LEARN_RELEVANCE/CLARITY/PRACTICE/SUPPORT/OVERALL and CUST_GOAL_FIT/ARRANGE/PRACTICE/COMM_CLAR/OVERALL (§4.3, PDF pp.17–19), form codes SURVEY-TOOL-A-L / SURVEY-TOOL-B-C (PDF pp.10, 13), ROLE-CRD/COL/ANL/DEC (§3.1, PDF p.6), SOP codes P-01…P-10 (PDF pp.7–8), field codes POP_ELIGIBLE…SUB_SUPPRESS (§5.1, PDF p.20). Separation from 0094 (口述訪談紀錄) and 0096 (感謝函) is explicit and by body content at §9.3/§9.4 (PDF p.37), with an explicit refusal to impersonate, manufacture or backfill 0096 originals; §9.2 flags 0093 as an unverified extra neighbour and does not use it as requirement evidence. Only cosmetic observation: the packet's Blueprint filename string '…（系統及流程_分析報告.docx' is truncated relative to the official wording, but the document body uses the full official text '（系統及流程面）', so no material impact."
      },
      {
        "criterion": "2. All Unique Blueprint sections, required tables/figure specification and data, questions, calculations, direct usability, and acceptance tests",
        "verdict": "PASS",
        "exact_locator": "§1–§10 PDF pp.1–44; required_sections vs §1.1 (p.1), §1.2–§1.3 (pp.2–3), §2.4 (p.6), §5.1–§5.2 (pp.20–21), §6.1–§6.4.1 (pp.23–29), §7.1–§7.2 (pp.30–32), §7.3–§7.4 (p.33), §8.4–§8.5 (pp.35–37), §9.5 (pp.38–41), §10.1–§10.2 (pp.41–44)",
        "finding": "All thirteen Blueprint required_sections are present and substantively populated, and all five required table/figure families exist: 資料欄位—定義—分母—來源—限制字典 (§5.1, PDF p.20, nine coded entries with denominator/numerator/source/limits and the SUPPRESS/N-A rules), 合成明細／彙總與逐步計算 (§6.1–§6.4.1, PDF pp.23–29), 分群比較／差距優先排序矩陣 (§7.1–§7.2, PDF pp.30–32, with a reproducible 6-rule ranking rule), 結論—證據—建議—責任—追蹤指標表 (§8.5, PDF pp.36–37, with responsibility/owner/deadline/status as four independent columns plus a blank TRK- log), 官方要求—結果—證據位置—覆核追溯表 (§1.4, PDF p.4). 附圖 A is specified in full on PDF pp.32–33 (title, per-panel values, shared 0–100% axis, presentation rules, warnings, alt-text draft) and the supplied R10 visual receipt states the figure is embedded on p.32 with the specification continuing on p.33; I make no claim of my own visual inspection and allege no missing chart, per the packet instruction. All ten required_questions are answered with explicit denominators, sources, nonresponse handling, attribution boundary, direct-evidence location, the four-step evidence-strength ladder (PDF pp.2–3), calculation precision and N/A conditions (§5.2, PDF p.21). All three required_calculations are implemented and reproduce exactly (see material_arithmetic_checks) and are never framed as association performance. Genre usability is satisfied: questionnaires carry items/options/scale and consent (§4.1 PDF pp.10–13, §4.2 PDF pp.13–17); the SOP carries role/input/control/output/hold-reject (P-01…P-10, PDF pp.7–8); the meeting-record role is carried by §2.3 候選步驟/判斷／輸出 and §8.4 PDCA with 暫緩／結案判準 (PDF pp.5–6, 35); the report carries data, denominators, formulae, step-by-step arithmetic, limits and decisions. Acceptance tests are met on the text-only evidence; typography floors, column fit and actual figure rendering are covered by the separate exact-SHA technical/visual receipts and are carried in unknowns, not as defects."
      },
      {
        "criterion": "3. Reassess R09-NB-R09-01: compare every §1.4 locator with the current 44-page R10 export, including §2, §5, §6, §7, §8, §9.5 and §10",
        "verdict": "PARTIAL",
        "exact_locator": "§1.4 locator column, PDF p.4 (rows 1–4); actual headings: §2.1 PDF p.5, §2.4 PDF p.6, §3.1 PDF p.6, §3.2 PDF pp.7–9, §4.1 PDF p.10, §4.2 PDF p.13, §4.3 PDF pp.17–19, §5.1 PDF pp.20–21, §5.2 PDF p.21, §6.1 PDF p.23, §6.2 PDF p.24, §6.3 PDF p.26, §6.3.3 PDF p.27, §6.4 PDF pp.28–29, §6.4.1 PDF p.29, §7.1 PDF p.30, §7.2 PDF pp.30–32, 附圖 A PDF pp.32–33, §7.3/§7.4 PDF p.33, §8.1–§8.5 PDF pp.34–37, §9.5 PDF pp.38–41, §10 PDF pp.41–44",
        "finding": "I re-anchored every §1.4 entry against the supplied 44-page text; all four named R09 defects are repaired and the previously defective §7.3–§7.4 pointer remains correct at p.33. Verified correct: §2.1–§2.4 → pp.5–6 (§2.4's 制度設計與現況界線 table ends on p.6); §3.1 → p.6 and §3.2 → pp.7–9 (SOP table pp.7–8, 回收狀態與計數界線 p.9); §4.1 → pp.10–13, §4.2 → pp.13–17, §4.3 → pp.17–19; §5.1 → p.20 (heading and the complete dictionary table print on p.20, SUB_SUPPRESS included) and §5.2 → p.21 for the heading, all six formulae and the rounding/N-A-guard paragraph; §6.1–§6.4 → pp.23–29; §6.3.3 → p.27; §6.4 → pp.28–29; §6.4.1 → p.29; §7.1 → p.30; §7.2 → pp.30–33 (附圖 A → pp.32–33); §8.1–§8.5 → pp.34–37 (chapter 8 opens on p.34 and §8.5 closes on p.37 before chapter 9); §10 → pp.41–44. Residual precision defects (nonblocking, itemised as NB-R10-03): (a) '§5.2 → pp.21–22' over-covers, since p.22 opens chapter 6 (§6) and §5.2 ends on p.21; (b) '§5.1 → p.20' under-covers by one paragraph, since §5.1's closing paragraph 回收／有效狀態之候選計數口徑 prints on p.21; (c) '§9.5 → pp.38–40' under-covers by one paragraph, since §9.5's closing paragraph (維持 UNKNOWN，不升格 REAL，本索引僅列示升格路徑) prints on p.41 — the same one-page shift is visible inside the document itself at PDF p.38, where §9.5 row 3 states '索引本列見 PDF p.39' while that row actually prints on p.38. These are audit-trail precision defects in the navigation table, not false pointers, and the document self-limits page anchors at PDF pp.5 and 41."
      },
      {
        "criterion": "4. Reassess R09-NB-R09-02: verify the R06 208-key base, 3 retired keys, 205 retained, 6 added UNKNOWN keys and 211 final rows; confirm the equation closes in §10 and the supplement",
        "verdict": "PASS",
        "exact_locator": "§10 body PDF p.41 ('R06 原有 208 個鍵；R08 移除 3 個不再使用的合併／合併正向率衍生鍵、保留其餘 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，故清冊為 208 − 3 + 6 = 211 筆資料列、13 欄'); R08 補充說明 (3) PDF p.41 ('R06 原有 208 鍵…205 = 208 − 3…208 − 3 + 6 = 211'); manifest r06_historical_row_count 208, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, row_count 211",
        "finding": "R09's NB-R09-02 is fully repaired: the R06 base of 208 keys is now stated explicitly in two independent places, and both state the closure 208 − 3 + 6 = 211 and 205 = 208 − 3. I independently recomputed the lineage against the supplied CSV body: the three retired keys (SYN-0095-COMBINED_RETURN_RATE, SYN-0095-COMBINED_VALID_RATE, SYN-0095-POOLED_POSITIVE_RATE) are absent; the six added UNKNOWN index keys (UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY, UNK_APPROVAL_SIGNATURE, UNK_FORMAL_EFFECTIVE_DATE, UNK_REAL_COURSE_COHORT, UNK_IMPROVEMENT_ORIGINALS, UNK_ATTACHMENT_STORAGE_LOCATION) are present; the contested SYN-0095-CUSTOMER_VALID_RETURN_SHARE is present as a retained R06 key, consistent with the deterministic R06/R08 key-set reconciliation; and I counted the CSV body at exactly 211 data rows with 13 columns. The §10.2 R10 row (PDF p.43) records that the R08 CSV/manifest, the questionnaires and the sample values are unchanged, which I confirmed by re-deriving every item value in the CSV against the §6.1/§6.2/§6.4 tables in the current export. No uncounted row survives."
      },
      {
        "criterion": "5. Reassess R09-NB-R09-03: verify 40 item-metric keys + 5 separate population/return-derived keys + 8 follow-up metrics = 53 DERIVED_SYNTHETIC_METRIC rows against the complete supplied CSV and manifest; check names/counts rather than assuming categories",
        "verdict": "PASS",
        "exact_locator": "§9.5 row 6, PDF p.39 ('L-01–L-05 與 C-01–C-05 各題 SUM／MEAN／POSN／POSRATE，共 40 個題項鍵；另有 5 個分軌分母／回收衍生鍵（SYN-0095-LEARNER_RETURN_RATE、LEARNER_VALID_RATE、CUSTOMER_RETURN_RATE、CUSTOMER_VALID_RATE、CUSTOMER_VALID_RETURN_SHARE）及 8 個訓後追蹤計算鍵。全清冊共 53 個 DERIVED_SYNTHETIC_METRIC 鍵'); CSV body; manifest fact_status_counts",
        "finding": "R09's NB-R09-03 is repaired and I verified it by key names rather than by inheriting the categories. From the supplied CSV body I counted: (i) 40 item-metric keys =10 items × 4 (SYN-0095-LEARNER-L-01…L-05 and SYN-0095-CUSTOMER-C-01…C-05, each with -SUM, -MEAN, -POSN, -POSRATE); (ii) 5 population/return-derived keys, all now individually named in §9.5 row 6 — SYN-0095-LEARNER_RETURN_RATE 83.3, LEARNER_VALID_RATE 93.3, CUSTOMER_RETURN_RATE 83.3, CUSTOMER_VALID_RATE 100.0 and CUSTOMER_VALID_RETURN_SHARE 83.3 (the two VALID_RATE keys that R09 found were missing from the sentence are now listed); (iii) 8 follow-up metrics (FOLLOWUP_PRE_SUM 51, PRE_MEAN 4.25, POST_SUM 85, POST_MEAN 7.08, ABS_CHANGE 2.83, REL_CHANGE 66.7, PASS_COUNT 9, PASS_RATE 75.0). 40 + 5 + 8 = 53, which equals the manifest's DERIVED_SYNTHETIC_METRIC count of 53, and every stated value matches the figures computed in §6.3/§6.4.1 and my own recomputation. The '40' is now explicitly scoped as 題項鍵 rather than the whole derived population."
      },
      {
        "criterion": "6. Reassess R09-NB-R09-04: verify the historical R09 exact-SHA receipt and result are recorded as PARTIAL, 0 blocking, 5 nonblocking, provider identity UNKNOWN; confirm R10's own exact-SHA QA is not self-declared complete in its body",
        "verdict": "PASS",
        "exact_locator": "§10.1 附件 E, PDF p.42; §10.2 R10 row, PDF p.43; 歷史覆核標的 paragraph, PDF p.43; manifest state CANDIDATE_QA_PENDING",
        "finding": "The historical R09 receipt is recorded accurately: 附件 E states 'R09 exact-SHA 收據已完成；R09 外部語意審查為 PARTIAL、0 blocking、5 nonblocking', names the response and receipt paths, records 'requested route OpenCode CLI v2.0.32 / minimax-m3.1-flash-free；provider model identity UNKNOWN' and the packet-only/no-visual/no-rehash scope — all of which match the R09 receipt supplied in the packet (PARTIAL, blocking_finding_count 0, nonblocking_finding_count 5 = NB-R09-01…05). The R10 row in §10.2 states 'R09 語意結果 PARTIAL、0 blocking、5 nonblocking，provider model identity UNKNOWN。R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行', and 附件 E adds '本索引不自行宣告 PASS，R10 收據於本版製稿時待執行'. R10 therefore does not self-declare completion or PASS anywhere in its body, the closing statement on p.44 repeats that the review binds only the specified DOCX exact SHA and does not represent association approval, and the manifest state remains CANDIDATE_QA_PENDING. The only residual is informational (NB-R10-04): the packet now supplies R10 technical, visual and font-floor receipts while the body still records R10 receipts as 待執行 — a conservative, stale-by-design statement at drafting time, not a false claim and not a self-declaration of completeness."
      },
      {
        "criterion": "7. Reassess R09-NB-R09-05: confirm small synthetic samples remain disclosed and are not promoted as association performance; no repair fabricates broader evidence",
        "verdict": "PASS",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.32; §7.3 items 1–4, PDF p.33; §7.4, PDF p.33; §6.4 追蹤遺漏處理, PDF p.28; §6.3.3, PDF p.27; §8.4, PDF p.35; §8.5, PDF pp.36–37; §1.3 item 2, PDF p.2",
        "finding": "The sample remains fully disclosed and nothing is promoted. §7.3 states the small-sample limits (learner valid n=14, customer valid n=5; a single rating can move a proportion; results describe only the supplied synthetic sample; nonresponse reasons unknown and no bias direction inferred; n<5 suppression with no sub-group data published; the paired sub-set is only 12 records and may differ from the population). §7.2 discloses the L-03 single-record sensitivity (identified 2-point response SYN-L14, two identified 3-point responses SYN-L04/SYN-L11, one unidentified non-positive response) and the customer track's 20-percentage-point-per-respondent effect, and forbids inferring causes or cross-group differences. §6.4 excludes the two unpaired learners from the paired denominator without treating them as failures and does not impute missing values. §1.3 states '問卷分數呈現受訪者的主觀評價，不能單獨證明技能提升或組織績效改變' and '本報告的合成追蹤分數只示範計算，不構成協會成效證據'. The R10 repairs did not alter any questionnaire text, sample value or limitation text, so no broader evidence was fabricated and no synthetic result is presented as association performance."
      },
      {
        "criterion": "8. Reassess all five R08 findings from the R08 response, the R06/R08 key-set reconciliation and R10 evidence; do not repeat R08-02 if the exact key set disproves it",
        "verdict": "PARTIAL",
        "exact_locator": "R08-01 → §1.4 PDF p.4; R08-02 → CSV row SYN-0095-CUSTOMER_VALID_RETURN_SHARE and §10 PDF p.41; R08-03 → §4.1 PDF pp.10–11, §4.2 PDF pp.14–15; R08-04 → §10.1 附件 D/E PDF p.42, §10.2 PDF p.43; R08-05 → §7.2 PDF p.32, §7.3 PDF p.33",
        "finding": "R08-01 is materially improved but not fully closed: the §1.4 locator column is now itemised per section against the current 44-page export and the specific §7.3–§7.4 → p.33 pointer is correct, but three residual span defects remain (§5.1 → p.20 under-covers p.21; §5.2 → pp.21–22 over-covers p.22; §9.5 → pp.38–40 under-covers p.41) — NB-R10-03. R08-02 is contradicted by the exact key set and is not repeated: SYN-0095-CUSTOMER_VALID_RETURN_SHARE appears in the supplied CSV body with the same fact_status, fact_type, value 83.3 and unit as the R06 row quoted in the reconciliation receipt, so it is among the 205 retained keys; the complete key-set difference is exactly the three listed removals and six listed UNKNOWN additions, and the R10 §10 text now states 208 − 3 + 6 = 211. R08-03 remains CLOSED: both instruments carry 【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】 (PDF p.10 for Tool-A, p.14 for Tool-B) above the SYN-TRN-01 sample code, and Tool-B p.15 labels 示範填答日期 2026-07-11 as SAMPLE／SYNTHETIC／非真實施測結果 above four blank REAL date fields, with an explicit no-backfill instruction. R08-04 remains OPEN as a workflow state: 附件 D still binds the Word-exported PDF only through an external final-QA list and 附件 E records R10 receipts as 待執行; this is consistent with CANDIDATE_QA_PENDING and with the document's refusal to self-declare PASS, so it is a workflow state rather than a body defect. R08-05 remains CLOSED in substance: both sensitivities are disclosed, causes are UNKNOWN, and cross-group inference is forbidden."
      },
      {
        "criterion": "9. Recompute learner/customer counts, sums, means, positive counts/rates, rankings, gaps, sensitivity, follow-up calculations, denominators, missing/N/A rules, rounding and suppression; keep respondent populations separate",
        "verdict": "PASS",
        "exact_locator": "§6.1 PDF pp.23–24; §6.2 PDF pp.24–25; §6.3.1 PDF pp.26–27; §6.3.2 PDF pp.27; §6.3.3 PDF p.27; §6.4 PDF p.28; §6.4.1 PDF p.29; §7.1 PDF p.30; §7.2 PDF pp.30–32; §5.1 PDF p.20; §5.2 PDF p.21; §4.3 N/A rules PDF p.19",
        "finding": "Every displayed quantity was independently recomputed from the raw rows printed in §6.1, §6.2 and §6.4 (all 21 learner rows, 5 customer rows, 12 paired follow-up rows) and all reproduce exactly — see material_arithmetic_checks. Population reconciliation: learners 18 invited = 15 returned + 3 nonresponse, 15 returned = 14 valid + 1 invalid (missing L-05); customers 6 invited = 5 returned + 1 nonresponse, 5 valid. Item sums 57/56/55/56/58 (learner) and 21/20/20/21/21 (customer); means 4.07/4.00/3.93/4.00/4.14 and 4.20/4.00/4.00/4.20/4.20; positive counts 11/11/10/11/12 and 4/4/4/4/4; positive rates 78.6/78.6/71.4/78.6/85.7 and 80.0 across; rate set 83.3 (learner return), 93.3 (learner validity), 83.3 (customer return), 100.0 (customer validity) and 83.3 (valid returns as share of invitations, explicitly distinguished from the validity rate at PDF p.27). Ranking reproduces under the stated §7.2 rule (positive rate ascending, then mean ascending, dense ranking): learner P1 L-03, P2 L-02/L-04, P3 L-01, P4 L-05 with gaps 14.3/7.1/7.1/0.0 percentage points and 0.21/0.14/0.07/0.00 points; customer P1 C-02/C-03 (mean 4.00), P2 C-01/C-04/C-05 (mean 4.20) with 0.0-point and 0.20/0.00-point gaps. The L-03 sensitivity scenario reproduces exactly (n=13, sum 53, mean 4.0769→4.08, 10/13=76.9%, gap narrowing to 8.8 points and 0.07 points, P1 retained). Follow-up figures reproduce (Σpre51, mean 4.25; Σpost 85, mean 7.0833→7.08; Δ_abs 34/12=2.8333→2.83; Δ_rel 34/51=66.7%; 9/12=75.0%; all twelve per-row Δ values and the three non-pass cases L04/L08/L11 match). Rounding follows §5.2 (means and Δ_abs to 2 dp; rates and Δ_rel to 1 dp) and no displayed value is derived from a rounded intermediate. N/A is excluded from item denominators and never treated as 0; a missing core item invalidates the form; n<5 suppression is defined and applied with no sub-group data published. §6.3.3 is honoured — learner (18/15/14) and customer (6/5/5) denominators are never pooled, no merged satisfaction or positive rate appears anywhere in the R10 text, and the three retired combined/pooled register keys are absent."
      },
      {
        "criterion": "10. Assess both forms' direct usability: eligibility, consent, scales, N/A, incomplete/withdrawn/invalid/valid status, REAL blank dates, invitation/delivery/return, population boundary, privacy/storage, aggregation and hold/reject criteria; proposed controls distinct from implemented association operation",
        "verdict": "PASS",
        "exact_locator": "§4.1 PDF pp.10–13; §4.2 PDF pp.13–17; §3.1 PDF p.6; §3.2 P-01…P-10 PDF pp.7–9; 計數界線 blocks PDF pp.9, 13, 17; §5.1 PDF pp.20–21; §5.2 PDF p.21; §8.1 PDF p.34; §8.3 PDF p.34; §6.3.3 PDF p.27",
        "finding": "Both instruments are usable as printed. Each carries a pre-response consent/privacy notice, a voluntary-participation statement, a three-way field-zone legend (示範值 / REAL 空白欄位 / 管理者專用欄位) and the 1–5 plus N/A scale legend with a check column. Eligibility is captured (Tool-A 受評者是否實際參與本次課程,缺漏題項代號, PDF pp.12–13; Tool-B 是否為貴單位之指定目標客戶聯絡窗口或經授權代表 / 待核 / 提供評價之工作接觸, 填答人角色, PDF pp.14–15). Status handling is complete and mutually exclusive on both forms — 未回應 (with an instruction that it has no form, must not be ticked and must not be treated as negative), 撤回, 待補正之未完成, 無效, 有效 — each with an instruction and a single-choice format, plus 判定備註 and 管理者簽核（若經授權）left blank. REAL date fields are blank with format instructions (Tool-A: 班次編號, 培訓日期, 實際填答日期, PDF pp.10–11; Tool-B: 邀請發送日期, 送達日期, 實際填答日期, 回收日期, PDF p.15), and the sample date is fenced as SAMPLE with a prohibition on back-filling. Invitation, delivery, return and nonresponse are separated at the counting-boundary level (PDF p.9 and SOP P-04, PDF p.7) and per-population denominators are defined in §5.1 (POP_ELIGIBLE/INVITED/RETURNED/VALID, PDF p.20). Privacy and storage are left explicitly UNKNOWN/NOT PROVIDED with a candidate control list (§8.3, PDF p.34) rather than asserted. Hold/reject criteria exist per SOP step and in the §8.1 decision table (可計算／暫緩／排除單份／抑制次分群／不得升格 REAL, PDF p.34), including the prohibition on auto-triggering a failure verdict or CAPA from a single unapproved percentage (PDF p.6). Every control is labelled 候選設計/提案 or requires authorised adoption; no control, committee, role assignment, storage location or recovery channel is asserted as operating, so the proposed/implemented boundary holds throughout."
      },
      {
        "criterion": "11. Validate SAMPLE/SYNTHETIC versus REAL boundaries and replacement-register traceability; no invented association people, approvals/signatures, courses, respondents, real survey execution, outcome records or third-party originals; missing REAL items remain UNKNOWN",
        "verdict": "PARTIAL",
        "exact_locator": "文件狀態宣告 PDF p.1; §9.5 PDF pp.38–41; §10 and R08 補充說明 (1)–(3) PDF p.41; §10.1 附件 A–E PDF pp.41–42; §8.5 PDF pp.36–37; CSV body document_location column; manifest page_locator_basis",
        "finding": "The substance of the SAMPLE/SYNTHETIC/REAL boundary is sound: no fabricated person, approval, signature, course, respondent, real survey execution, outcome or third-party record was found; the only named entities are the synthetic course 志工服務溝通與紀錄練習, class code SYN-TRN-01 and synthetic dates 2026-07-11 / 2026-08-10, each flagged as synthetic; §8.5's 建議負責人 field is blank with 『姓名未提供；UNKNOWN，不得填入推定人選』; the 0096 感謝函 is expressly not fabricated (§9.4); and all eight §9.5 promotion classes are held 未提供；UNKNOWN with safe acquisition paths and corresponding register keys, every UNKNOWN row carrying real_source_status NOT_PROVIDED and a 'listed to prevent inference' note. Register content is internally consistent: 211 rows, 13 columns, unique register_key, status counts 134/13/7/4/53 = 211, and every row carries a §-anchored document_location. The traceability defect is in the page layer, not the fact layer: (i) the register's row-level PDF page anchors are those of the 43-page R08 export and are one page later than the current 44-page R10 export for every entry from §6 onward (e.g. SYN-0095-CASE_ID 'PDF p. 23' where §6 now opens on p.22; SYN-0095-SYN-L01-L-01 'PDF p. 24' where SYN-L01 prints on p.23; SYN-0095-LEARNER-L-01-SUM 'PDF p. 27' where §6.3.1 now prints on p.26; SYN-0095-FOLLOWUP_PRE_SUM 'PDF p. 30' where §6.4.1 now prints on p.29; UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY 'PDF p. 39' where §9.5 row 1 now prints on p.38), because the R10 §5.1 layout repair pulled all content from chapter 6 onward up by exactly one page; the manifest's page_locator_basis still states 'exact 43-page export inspected'; and §10 (2)'s assertion 清冊各列的 PDF 定位已對照本版 Word 匯出 PDF 核對 cannot hold for those page numbers (NB-R10-02); and (ii) 附件 A on PDF pp.41–42 prints the register CSV SHA-256 as a 65-character string '203583e4…b1174840202ca' — one character longer than the bound value '203583e4…b1174840202c' printed correctly in §10 on p.41 and fixed by the packet — so a reader following §10's instruction to stop using the package on any SHA mismatch would trip on a transcription error (NB-R10-01). Neither defect alters a fact, a value or a key, and both are self-limited by the chapter anchors that remain correct."
      },
      {
        "criterion": "12. Assess usability for a small volunteer association: SOP, dictionary, worked case, ranked recommendations, decision criteria, responsibility/deadline/metric fields and follow-up; recommendations distinct from authorization/execution",
        "verdict": "PASS",
        "exact_locator": "§3.1 PDF p.6; §3.2 PDF pp.7–9; §5.1 PDF pp.20–21; §5.2 PDF p.21; §6 PDF pp.22–29; §7.2 PDF pp.30–32; §8.1 PDF p.34; §8.4 PDF p.35; §8.5 PDF pp.36–37; §1.1 PDF p.1",
        "finding": "Usability is high for a small volunteer body and does not presume a committee or dedicated data unit: the SoD matrix names four candidate functions (ROLE-CRD/COL/ANL/DEC) with an explicit scale-limitation fallback requiring an authorised alternative control, and states that no committee, CAPA or file-management process is implied (PDF p.6). The SOP gives ten steps with input, candidate operation/control, output and hold/reject conditions, with P-01 gating on a known population and invitation denominator, P-02 gating release on authorised tool approval, P-04 separating invitation/delivery/nonresponse/return, P-05 separating撤回/待補正/無效/有效 with traceable status changes, and P-10 gating claims of established storage. The dictionary gives nine coded entries with denominator, numerator, source form and limits (including MISSING_ITEM, NA_TREATMENT and SUB_SUPPRESS), and the formula library gives six reproducible formulae with a zero-denominator N/A guard and explicit rounding rules. The worked case is complete and self-consistent end to end. Ranked recommendations exist at §7.2 with a documented six-rule ranking rule, an explicit decision criterion (10/14 positive, mean 3.93/5) and the sensitivity caveat. The tracking table separates 合成觀察 / 成因狀態 / 改善建議 / 後續核驗方式 / 建議責任職能 / 建議負責人 / 預定期限 / 狀態 into independent columns with fill rules ①–④ that forbid naming a person, forbid assumed deadlines and forbid writing 已改善 without verifiable follow-up data, plus a blank TRK- log table for ongoing use. The PDCA block adds per-stage hold/close criteria and requires at least two options before selection. Recommendations remain distinct from authorization throughout: stage 4 requires verified decision authority, every proposal is marked as requiring authorised adoption, and 實際指派未核定 / 姓名未提供 / 期限未定 remain in place."
      },
      {
        "criterion": "13. Confirm negative-neighbor and title-blind tests reject at least two wrong documents by body-level fields and sections",
        "verdict": "PASS",
        "exact_locator": "§9.1 PDF p.37; §9.3 PDF p.37; §9.4 PDF p.37; §4.3 field mapping PDF pp.17–19; §4.1/§4.2 form codes PDF pp.10, 13; §3.1/§3.2 codes PDF pp.6–8; §1.4 PDF p.4",
        "finding": "Two wrong documents are rejected on body-level grounds, not labels. Against 0094 / I18-E01 (口述訪談紀錄), §9.3 states that 0094's artefact is an oral interview record with interview statements and interviewees, whereas 0095 carries dual-track structured instruments, item codes, a scale definition, a field dictionary, formulas, denominators and per-item rates; the document expressly refuses to pass interview quotes, interviewees or real oral material off as its own survey results, and §9.1 records the 0094 official wording as the1 分 evidence text rather than as this document's requirement. Against 0096 / I18-E03 (感謝函), §9.4 records that 0096's artefact is a letter whose issuer, content and original must be verified from lawful sources, and that 0095 must not impersonate, manufacture or backfill a genuine 0096 original. In title-blind terms the neighbours are rejected on concrete body fields a reader would have to see: SURVEY-TOOL-A-L / SURVEY-TOOL-B-C form codes, LEARN_* / CUST_* database field names, P-01…P-10 SOP steps and ROLE-* function codes appear nowhere else, while a 訪談逐字稿 or a 感謝函 format (致受贈單位／敬啟者／署名) appears in neither. §9.1 also states the boundary is derived from official wording and Blueprint division of labour and does not presume neighbours' real content."
      },
      {
        "criterion": "14. Identify any remaining material contradiction, unsupported claim, ambiguous field, unusable form, arithmetic mismatch, overclaim, required omission or traceability defect",
        "verdict": "PARTIAL",
        "exact_locator": "§10.1 附件 A (PDF pp.41–42); §10 R08 補充說明 (2) PDF p.41; §9.5 PDF p.38 row 3 and PDF p.39 row 6; CSV document_location column; manifest page_locator_basis; §1.4 PDF p.4; §10.2 R10 row PDF p.43",
        "finding": "No material contradiction, arithmetic mismatch, overclaim, unusable form, fabricated fact or unsafe REAL claim was found; every displayed quantity reproduces, the required sections/tables/questions/calculations are all present, and the candidate's SAMPLE/SYNTHETIC boundary is intact. Three residual traceability defects remain and are itemised as NB-R10-01 to NB-R10-03: (i) 附件 A misprints the register CSV SHA-256 with a65-character value (trailing 'a') that does not equal the bound SHA printed in §10 and supplied by the packet; (ii) the register's row-level PDF page anchors and the manifest's page_locator_basis ('exact 43-page export inspected') are one page behind the current 44-page R10 export for all chapter-6-and-later entries, and §10 (2)'s statement that the locators were 核對 against 本版 export cannot hold for those page numbers — the document's own cross-reference at p.38 ('索引本列見 PDF p.39') shows the same one-page drift; (iii) three §1.4 spans are imprecise against the 44-page export (§5.1 → p.20 under-covers p.21; §5.2 → pp.21–22 over-covers p.22; §9.5 → pp.38–40 under-covers p.41). Two informational items are also carried: the R10 QA chain is open at the semantic receipt by design (NB-R10-04), and the inherent small-sample limitation persists (NB-R10-05). None of these affect a fact, value, key, formula, usability or the SAMPLE/REAL boundary, so they are nonblocking."
      }
    ],
    "r08_finding_disposition": [
      {
        "id": "R08-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 evidence-locator table, PDF p.4, third column (文件證據定位), rows 1–4; actual section locations in the current 44-page export: §4.1 p.10, §4.2 p.13, §4.3 p.17, §5.1 pp.20–21, §5.2 p.21, §6.1 p.23, §6.3.3 p.27, §6.4 pp.28–29, §6.4.1 p.29, §7.1 p.30, §7.2 pp.30–32, 附圖 A pp.32–33, §7.3/§7.4 p.33, §8.1–§8.5 pp.34–37, §9.5 pp.38–41, §10 pp.41–44",
        "rationale": "The defect R08-01 named is fixed: §7.3–§7.4 is cited to the single page where both headings print (p.33), and the R08 row-1/row-2 spans for §4.1/§4.2/§4.3 and §2–§3 now agree with the observed section starts in the 44-page export. The table is also itemised per section and self-limited by the pagination-anchor warning at PDF p.5 and the R08 lineage note at p.41. It is not fully closed because three spans remain mis-anchored: '§5.1 → p.20' omits §5.1's closing paragraph on p.21; '§5.2 → pp.21–22' includes p.22, which opens chapter 6; and '§9.5 → pp.38–40' omits §9.5's closing paragraph on p.41. These are audit-trail precision defects in the document's primary navigation table, not false pointers, so the finding is marked PARTIALLY_CLOSED and the residuals are itemised as NB-R10-03."
      },
      {
        "id": "R08-02",
        "disposition": "CLOSED",
        "exact_locator": "CSV body row SYN-0095-CUSTOMER_VALID_RETURN_SHARE (fact_status DERIVED_SYNTHETIC_METRIC, fact_type rate, value 83.3, unit percent, document_location '§6.3.2 …；PDF p. 28'); deterministic R06/R08 register lineage countercheck in the packet; §10 lineage sentence PDF p.41 ('208 − 3 + 6 = 211；205 = 208 − 3'); manifest r06_historical_row_count 208, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, row_count 211",
        "rationale": "R08-02 alleged an uncounted added key. The exact key set disproves it: SYN-0095-CUSTOMER_VALID_RETURN_SHARE is present in the supplied current CSV body and in the R06 row quoted in the packet's deterministic R06/R08 key-set reconciliation with identical fact_status, fact_type, value and unit (only document_location gained a page locator), so it is among the 205 retained keys and is neither an addition nor a retirement. The complete key-set difference is exactly the three listed removals and six listed UNKNOWN additions, and I confirmed by counting the supplied body that it holds 211 rows with 13 columns and status counts 134/13/7/4/53. I therefore do not repeat the allegation. The R10 body additionally closes the lineage arithmetic on its face by naming the 208-key R06 base, so the presentational gap R09 identified is also resolved."
      },
      {
        "id": "R08-03",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF p.10, block 【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】 immediately above the blank REAL 班次編號 field; §4.1 PDF p.11, 示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）: SYN-TRN-01 and 示範培訓日期 2026-07-11; §4.2 PDF p.14, same block; §4.2 PDF p.15, 示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11 above the four blank REAL date fields with the no-backfill instruction",
        "rationale": "R08-03 flagged that a literal 'no approved class identifier' statement sat one line above a filled-in synthetic identifier and a pre-filled sample date, creating a residual risk of the sample value being read as an administration fact. R10 (unchanged from R09 here) has closed this: each instrument states in a header block that no verified and approved real class identifier is provided and that the following code is synthetic only; the sample class code and the sample dates are individually labelled SAMPLE／SYNTHETIC／未核定／非正式班次／非實際辦訓日期; every REAL field is blank with format instructions; the 欄位分區說明 legend states the sample sheet leaves every REAL field blank; and the form explicitly forbids back-filling the sample date into the REAL fields. The wording risk R08-03 identified is not present in the current text."
      },
      {
        "id": "R08-04",
        "disposition": "OPEN",
        "exact_locator": "§10.1 附件 D (0095_R10_CANDIDATE.pdf; 'PDF SHA-256 及頁數由同套件最終 QA 清冊綁定') and 附件 E ('R10 各收據須明列 DOCX exact SHA…本索引不自行宣告 PASS，R10 收據於本版製稿時待執行'), PDF p.42; §10.2 R10 row PDF p.43 ('R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行'); manifest state CANDIDATE_QA_PENDING",
        "rationale": "This is a workflow state rather than a document-body defect and it remains open by design: the candidate's own QA chain is open at the semantic receipt for R10, Attachment D binds the Word-exported PDF only through an external final-QA list, and the body consistently refuses to self-declare PASS, deferring the independent result to the external package receipt bound to this version's DOCX SHA. The packet now supplies R10 technical, visual and font-floor receipts, so the body's '待執行' statement is conservative and stale-by-drafting-time rather than false, and the semantic receipt is what this review constitutes. I record it as OPEN because the R10 semantic receipt did not exist in the supplied evidence when the candidate body was written; it is not counted as a material semantic defect and does not affect the body assessment."
      },
      {
        "id": "R08-05",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.32 (L-03 非正向 4 份: 1 份 2 分 SYN-L14, 2 份 3 分 SYN-L04/SYN-L11, 1 份未逐筆識別; 情境演算 n=13, 總分 53, 平均約 4.08, 10/13＝76.9%, 差距收斂為 8.8 個百分點與 0.07 分; 目標客戶端 n=5 每題各 1 份非正向回覆，單一填答者對應 20 個百分點); §7.3 items 1–4, PDF p.33; §7.4, PDF p.33; §6.4 追蹤遺漏處理, PDF p.28; §8.4 PDF p.35; §8.5 PDF pp.36–37",
        "rationale": "R08-05 concerned the residual inherent limitation of a 14-respondent synthetic sample and of the customer track's n=5 giving each respondent 20 percentage points of influence. R10 keeps both sensitivities disclosed with causes UNKNOWN and an explicit prohibition on inferring group differences: the L-03 single-2-point scenario is recomputed and shown not to change the P1 ordering and is expressly not a re-test result nor a basis for excluding the response; the customer20-point effect is stated with the reading limit that the five facets share the same 4/5 positive count and therefore cannot be read as agreement or representativeness. §7.3 adds small-sample, nonresponse-causality and paired-subset limits, §6.4 excludes the two unpaired learners from the paired denominator without treating them as failures, and §8.4/§8.5 keep cause, owner, deadline and status UNKNOWN or blank. The limitation is disclosed rather than concealed and the R10 repairs did not alter any of this text, so the finding is closed; the underlying small-sample limitation persists as an inherent property of the SAMPLE/SYNTHETIC design and is carried as NB-R10-05 and in unknowns."
      }
    ],
    "r09_finding_disposition": [
      {
        "id": "NB-R09-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 locator column, PDF p.4, rows 1–4, third column; actual locations in the supplied 44-page export: §2.1 p.5, §2.4 p.6, §3.1 p.6, §3.2 pp.7–9, §4.1 pp.10–13, §4.2 pp.13–17, §4.3 pp.17–19, §5.1 pp.20–21, §5.2 p.21, §6.1–§6.4 pp.23–29, §6.3.3 p.27, §6.4.1 p.29, §7.1 p.30, §7.2 pp.30–33 (附圖 A pp.32–33), §7.3/§7.4 p.33, §8.1–§8.5 pp.34–37, §9.5 pp.38–41, §10 pp.41–44",
        "rationale": "I re-derived every §1.4 locator against the current 44-page export rather than reusing R09's 43-page anchors. All four spans R09 named as defective are repaired: §5.1 now points to p.20 (its heading and the complete dictionary table, SUB_SUPPRESS included, print on p.20 after the R10 layout repair), §6.3.3/§6.4/§6.4.1 are itemised to p.27 / pp.28–29 / p.29 and match the observed headings, §7.1/§7.2 are itemised to p.30 / pp.30–33 with 附圖 A at pp.32–33, and §2.1–§2.4 → pp.5–6 now fully contains the §2.4 boundary table that R09 found completing later. The §7.3–§7.4 → p.33 pointer remains correct. The finding is not fully closed because three residual spans remain imprecise against the 44-page export: '§5.1 → p.20' omits §5.1's closing paragraph on p.21; '§5.2 → pp.21–22' includes p.22, which opens chapter 6; and '§9.5 → pp.38–40' omits §9.5's closing paragraph on p.41 (the same one-page drift is visible in the document's own cross-reference at p.38, where §9.5 row 3 states '索引本列見 PDF p.39' although that row prints on p.38). These are navigation-precision defects in the audit trail, not false pointers, so NB-R09-01 is PARTIALLY_CLOSED and the residuals are itemised as NB-R10-03."
      },
      {
        "id": "NB-R09-02",
        "disposition": "CLOSED",
        "exact_locator": "§10 body PDF p.41 ('R06 原有 208 個鍵；R08 移除 3 個…保留其餘 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，故清冊為 208 − 3 + 6 = 211 筆資料列、13 欄'); R08 補充說明 (3) PDF p.41 ('R06 原有 208 鍵…205 = 208 − 3…208 − 3 + 6 = 211；R06、R07 歷史 CSV 與 manifest 均維持原件，不回溯改寫'); manifest r06_historical_row_count 208, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, row_count 211, column_count 13",
        "rationale": "R09's finding was that the §10 lineage sentence gave 205 + 6 − 3 without naming the 208-key R06 base, so it did not visibly close to the delivered 211 rows. R10 repairs this in two places, not one: both the §10 body paragraph and the R08 補充說明 (3) now state the R06 base of 208 keys, the removal of 3 merged/pooled keys, the 205 retained keys and the 6 added UNKNOWN index keys, and both print the closing equation 208 − 3 + 6 = 211 with 205 = 208 − 3. I independently verified the arithmetic against the supplied CSV body (211 rows, 13 columns, three retired keys absent, six added UNKNOWN keys present, contested key retained) and against the manifest, so the lineage now closes on its face and no row is unaccounted for."
      },
      {
        "id": "NB-R09-03",
        "disposition": "CLOSED",
        "exact_locator": "§9.5 row 6, PDF p.39 ('共 40 個題項鍵；另有 5 個分軌分母／回收衍生鍵（SYN-0095-LEARNER_RETURN_RATE、LEARNER_VALID_RATE、CUSTOMER_RETURN_RATE、CUSTOMER_VALID_RATE、CUSTOMER_VALID_RETURN_SHARE）及 8 個訓後追蹤計算鍵。全清冊共 53 個 DERIVED_SYNTHETIC_METRIC 鍵'); CSV body derived rows; manifest fact_status_counts.DERIVED_SYNTHETIC_METRIC 53",
        "rationale": "R09 found that §9.5 row 6 stated '40 列' for the derived item-metric subset while its own parenthetical named only two of the four derived rate keys, leaving SYN-0095-LEARNER_VALID_RATE and SYN-0095-CUSTOMER_VALID_RATE outside the sentence and making the '40' read as the whole derived population. R10 now names all five rate keys explicitly and re-scopes the count as '共 40 個題項鍵' alongside '5 個分軌分母／回收衍生鍵' and '8 個訓後追蹤計算鍵', summing to 53. I verified this by counting the actual CSV body by key name rather than by inheriting the categories: 10 items × 4 (SUM/MEAN/POSN/POSRATE) = 40 item-metric keys, 5 rate keys and 8 follow-up keys = 53 DERIVED_SYNTHETIC_METRIC rows, equal to the manifest count, with every stated value matching my recomputation."
      },
      {
        "id": "NB-R09-04",
        "disposition": "CLOSED",
        "exact_locator": "§10.1 附件 E, PDF p.42 ('R09 exact-SHA 收據已完成；R09 外部語意審查為 PARTIAL、0 blocking、5 nonblocking…provider model identity UNKNOWN…本索引不自行宣告 PASS，R10 收據於本版製稿時待執行'); §10.2 R09 row PDF p.43 ('R09 exact-SHA OpenCode review 為 PARTIAL、0 blocking、5 nonblocking…provider model identity UNKNOWN；本件仍為 CANDIDATE'); §10.2 R10 row PDF p.43 ('R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行'); closing statement PDF p.44",
        "rationale": "R09 asked for two things: that the historical R09 exact-SHA receipt and result be recorded faithfully, and that R10 not self-declare its own QA complete in the body. Both hold in the current R10 text. 附件 E records the R09 receipt as completed with the result PARTIAL, 0 blocking, 5 nonblocking, the response and receipt paths, the requested route and provider model identity UNKNOWN, and the packet-only/no-visual/no-rehash scope — all consistent with the R09 receipt in the packet. R10's own receipts are recorded as 待執行 and the document states expressly 本索引不自行宣告 PASS, repeats that the independent semantic result must come from the external package receipt bound to this version's DOCX SHA (PDF p.43), and the closing statement on p.44 again restricts the review to the specified exact SHA and disclaims association approval. Manifest state remains CANDIDATE_QA_PENDING. The only residual is informational (NB-R10-04): the body statement is conservative relative to the R10 technical/visual receipts now supplied in the package."
      },
      {
        "id": "NB-R09-05",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.32; §7.3 items 1–4, PDF p.33; §7.4, PDF p.33; §6.4 追蹤遺漏處理, PDF p.28; §6.3.3, PDF p.27; §1.3 item 2, PDF p.2; §8.5, PDF pp.36–37",
        "rationale": "R09 asked that the improvement candidate's robustness not rest on the 14-respondent learner sample and 5-respondent customer sample without disclosure. The R10 text keeps the same disclosures unchanged: the L-03 single-record sensitivity is recomputed (n=13, sum 53, mean ≈4.08, 10/13＝76.9%, gap narrowing to 8.8 points and 0.07 points, P1 unchanged) with the explicit statements that it is a情境演算, not a re-test result and not a basis for excluding the response; the customer track's 20-percentage-point-per-respondent effect is stated; nonresponse reasons are UNKNOWN with no bias direction inferred; the n<5 suppression rule is defined and no sub-group data is published; the paired sub-set is limited to 12 records with the other 2 excluded rather than treated as failures; §6.3.3 forbids pooling or cross-group comparison; §1.3 separates satisfaction from performance; and §8.4/§8.5 keep cause, owner, deadline and status UNKNOWN or blank. The samples are therefore disclosed and are nowhere promoted as association performance, and no R10 repair broadened the evidential claim. The inherent limitation itself persists as NB-R10-05 and in unknowns."
      }
    ],
    "blocking_findings": [],
    "nonblocking_findings": [
      {
        "id": "NB-R10-01",
        "severity": "LOW_MEDIUM",
        "title": "§10.1 附件 A prints the register CSV SHA-256 as a 65-character string that does not equal the bound value",
        "locator": "§10.1 附件 A row, PDF pp.41–42: '211 筆、13 欄；SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202ca；每列具章節與 PDF 頁碼定位。'; correct value printed in §10 body, PDF p.41: 'CSV SHA-256 為 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c'; manifest SHA on the same row (附件 A-1) df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0 is correct at 64 characters",
        "finding": "As extracted from the supplied page-bounded PDF text, the Attachment A hash string carries one extra trailing character ('…b1174840202ca') compared with the 64-character SHA-256 203583e4…b1174840202c that the same document prints in §10 on p.41 and that the packet binds for qa/0095_R08_synthetic_replacement_register.csv. Because §10 instructs the reader to 核對此 DOCX 內所列 CSV 與 manifest SHA and to stop using the package on any mismatch, a reader checking the attachment index literally would abort on a transcription error. No fact, value, key or artefact is affected, the correct value appears elsewhere in the same document, and the adjacent manifest hash is correct, so this is a traceability/typing defect rather than a material error; it should be corrected in the attachment index. Because the character is inline before a full-width semicolon within a single extracted line, a rendering-level check (outside packet-only scope) is advisable before treating it as confirmed."
      },
      {
        "id": "NB-R10-02",
        "severity": "LOW_MEDIUM",
        "title": "Replacement-register row-level PDF page anchors and the manifest page_locator_basis are anchored to the 43-page R08 export and are one page behind the current 44-page R10 export for all chapter-6-and-later entries",
        "locator": "CSV document_location column (unchanged R08 artefact, SHA 203583e4…0202c) versus the current 44-page export: SYN-0095-CASE_ID 'PDF p. 23' (chapter 6 opens on p.22); SYN-0095-COURSE_NAME/HOURS/FOLLOWUP_DATE 'PDF p. 23' (p.22); SYN-0095-LEARNER_INVITED…INVALID_REASON 'PDF pp. 24–25' (§6.1 now pp.23–24); SYN-0095-SYN-L01-L-01…L08-L-05 'PDF p. 24' (p.23); SYN-0095-SYN-L09…L14 'PDF p. 25' (p.24); SYN-0095-SYN-C01… 'PDF p. 25' (p.24); SYN-0095-SYN-C02…C05 'PDF p. 26' (p.25); SYN-0095-LEARNER-L-01-SUM…L-05-POSRATE and LEARNER_RETURN_RATE/VALID_RATE 'PDF p. 27' (§6.3.1 now p.26); SYN-0095-CUSTOMER-C-01…C-05 and the four customer rate keys and CUSTOMER_VALID_RETURN_SHARE 'PDF p. 28' (p.27); SYN-0095-SYN-L01-PRE…L12-POST30 'PDF p. 29' (p.28); SYN-0095-FOLLOWUP_* 'PDF p. 30' (p.29); UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY 'PDF p. 39' (§9.5 row 1 now p.38); UNK-0095-UNK_APPROVAL_SIGNATURE 'PDF pp. 35, 39' (§8.1 now p.34; row 2 now p.38); UNK-0095-UNK_FORMAL_EFFECTIVE_DATE 'PDF pp. 11, 15, 39, 41' (row 3 now p.38); UNK-0095-UNK_REAL_COURSE_COHORT 'PDF pp. 23, 39' (pp.22, 38); UNK-0095-UNK_IMPROVEMENT_ORIGINALS 'PDF pp. 37–38, 40' (§8.5 now pp.36–37); UNK-0095-UNK_ATTACHMENT_STORAGE_LOCATION 'PDF pp. 35–36, 40–42' (§8.3 now p.34); §9.5 row 3, PDF p.38 ('索引本列見 PDF p.39'); §10 R08 補充說明 (2), PDF p.41; manifest page_locator_basis 'Companion R08 Word-exported PDF, exact 43-page export inspected'",
        "finding": "The R10 §5.1 layout repair compressed the front matter by one page (the complete §5.1 dictionary table now fits on p.20 and the formula library moved to p.21), which shifted every element from chapter 6 onward up by exactly one page in the 44-page export, while the register CSV and manifest were deliberately retained unchanged and SHA-bound as the R08 artefact. Consequently the register's row-level PDF page anchors no longer match the current export for all chapter-6-and-later entries, and the manifest's page_locator_basis still describes a 43-page export. §10's R08 補充說明 (2) asserts 清冊各列的 PDF 定位已對照本版 Word 匯出 PDF 核對, which cannot hold for those page numbers as printed; the same one-page drift is visible inside the document body itself, where §9.5 row 3 on p.38 states that it is located at PDF p.39. No fact, value, key, formula or row is affected and the §-anchored chapter locators remain correct in every row, so the defect is in the page layer only; the document's own mitigations (章節錨點為主要定位 and 不得沿用舊版頁碼) limit its effect. Recommended remedy: state explicitly in §9.5/§10 that the register's page anchors are bound to the 43-page R08 export (or re-issue the register with R10 anchors under a new SHA while preserving the R08 artefact as the historical target), so that no reader is told the page numbers were checked against the current export."
      },
      {
        "id": "NB-R10-03",
        "severity": "LOW",
        "title": "Three §1.4 locator spans remain imprecise against the current 44-page R10 export",
        "locator": "§1.4 locator column, PDF p.4, row 1 ('§5.1 → p.20；§5.2 → pp.21–22') and row 4 ('§9.5 → PDF pp.38–40'); actual locations: §5.1 heading and complete dictionary table on p.20 with its closing paragraph 回收／有效狀態之候選計數口徑 on p.21; §5.2 heading, six formulae and the rounding/N-A-guard paragraph on p.21 with p.22 opening chapter 6; §9.5 rows 1–8 on pp.38–40 with §9.5's closing paragraph (維持 UNKNOWN，不升格 REAL，本索引僅列示升格路徑與所需來源) on p.41",
        "finding": "R10's itemised rewrite fixed the substantive R09 defects but introduced or left three span imprecisions in the document's primary navigation table: '§5.1 → p.20' under-covers §5.1's final paragraph on p.21; '§5.2 → pp.21–22' over-covers, since p.22 belongs to chapter 6; and '§9.5 → pp.38–40' under-covers §9.5's closing paragraph on p.41. These are directionally correct pointers and the document self-limits page anchors (PDF pp.5, 41), so they are audit-trail precision defects rather than false pointers; anchoring each section to its own start page (and to the page carrying its closing paragraph) would remove them."
      },
      {
        "id": "NB-R10-04",
        "severity": "INFORMATIONAL",
        "title": "R10's own QA chain is open at the semantic receipt by design",
        "locator": "§10.1 附件 E, PDF p.42 ('R10 收據於本版製稿時待執行'); §10.2 R10 row, PDF p.43 ('R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行'); closing statement PDF p.44; manifest state CANDIDATE_QA_PENDING; supplied R10 technical/visual/font-floor receipts in the packet",
        "finding": "The candidate's body does not self-declare PASS and defers the independent semantic result to the external package receipt bound to this version's DOCX SHA, while the manifest carries CANDIDATE_QA_PENDING. The packet now supplies R10 technical, visual and font-floor receipts (with the figure confirmed present on p.32 and the §5.1 table confirmed complete on p.20), so the body's '待執行' wording is conservative rather than false; this review's semantic receipt is the remaining link. This is a workflow state consistent with CANDIDATE, not a body defect, and it must be satisfied, together with the external final-QA list binding the PDF SHA and page count, before any formal acceptance step."
      },
      {
        "id": "NB-R10-05",
        "severity": "INFORMATIONAL",
        "title": "Improvement-candidate robustness continues to rest on a 14-respondent synthetic learner sample and a 5-respondent synthetic customer sample",
        "locator": "§6.1 PDF pp.23–24; §6.2 PDF pp.24–25; §7.2 sensitivity note PDF p.32; §7.3 items 1–4 PDF p.33; §6.4 PDF p.28; §8.5 PDF pp.36–37",
        "finding": "The limitation is fully disclosed — the single-record sensitivity on L-03 is recomputed and shown not to change the P1 ranking, the customer track's 20-points-per-respondent effect is stated, nonresponse reasons remain UNKNOWN, §6.3.3 forbids pooling or cross-group comparison and no sub-group data is published under the n<5 rule — so it is inherent to the SAMPLE/SYNTHETIC design rather than concealed. It requires no change other than continued presentation as SAMPLE/SYNTHETIC and continued refusal to characterise the numbers as association performance, and it must be restated explicitly if any figure derived from these data is later reused outside this document."
      }
    ],
    "material_arithmetic_checks": [
      {
        "item": "Learner population reconciliation (POP_INVITED / POP_RETURNED / POP_VALID / nonresponse)",
        "locator": "§6.1 PDF pp.23–24; §3.2 counting boundary PDF p.9; §5.1 PDF p.20; §6.3.1 PDF p.26",
        "recomputed": "18 invited = 15 returned + 3 nonresponse; 15 returned = 14 valid + 1 invalid; 3 = 18 − 15; 1 = 15 − 14",
        "verdict": "MATCH"
      },
      {
        "item": "Learner return rate and validity rate",
        "locator": "§6.3.1 items 1–2, PDF p.26; register SYN-0095-LEARNER_RETURN_RATE / LEARNER_VALID_RATE",
        "recomputed": "15/18 = 83.333% → 83.3%; 14/15 = 93.333% → 93.3%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-01 任務關聯性: sum, mean, positive count, positive rate",
        "locator": "§6.1 PDF pp.23–24; §6.3.1 item 3, PDF p.26; register SYN-0095-LEARNER-L-01-SUM/MEAN/POSN/POSRATE",
        "recomputed": "5+5+4+3+5+4+4+5+4+4+3+5+4+2 = 57; 57/14 = 4.0714 → 4.07; 11 values ≥ 4 (L01,L02,L03,L05,L06,L07,L08,L09,L10,L12,L13) → 11/14 = 78.571% → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-02 目標引導清晰度",
        "locator": "§6.3.1 item 4, PDF p.26; register SYN-0095-LEARNER-L-02-*",
        "recomputed": "4+4+5+4+5+4+3+5+4+3+4+4+4+3 = 56; 56/14 = 4.0000 → 4.00; positives 11 (L01,L02,L03,L04,L05,L06,L08,L09,L11,L12,L13) → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-03 演練操作價值",
        "locator": "§6.3.1 item 5, PDF p.26; register SYN-0095-LEARNER-L-03-*",
        "recomputed": "5+4+4+3+4+4+4+5+3+4+3+5+4+3 = 55; 55/14 = 3.9285 → 3.93; positives 10 (L01,L02,L03,L05,L06,L07,L08,L10,L12,L13) → 71.428% → 71.4%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-04 講師支持度",
        "locator": "§6.3.1 item 6, PDF p.26; register SYN-0095-LEARNER-L-04-*",
        "recomputed": "5+4+4+4+5+3+4+4+4+3+4+5+4+3 = 56; 56/14 = 4.0000 → 4.00; positives 11 (L01,L02,L03,L04,L05,L07,L08,L09,L11,L12,L13) → 78.6%",
        "verdict": "MATCH"
      },
      {
        "item": "Learner item L-05 整體滿意度",
        "locator": "§6.3.1 item 7, PDF p.26; register SYN-0095-LEARNER-L-05-*",
        "recomputed": "5+5+4+4+5+4+4+5+4+4+3+5+4+2 = 58; 58/14 = 4.1428 → 4.14; positives 12 (L01–L10, L12, L13) → 85.714% → 85.7%",
        "verdict": "MATCH"
      },
      {
        "item": "Customer population reconciliation and rates",
        "locator": "§6.2 PDF pp.24–25; §6.3.2 item 1, PDF p.27; register SYN-0095-CUSTOMER_INVITED/RETURNED/VALID/NONRESPONSE, LEARNER/CUSTOMER rate keys and CUSTOMER_VALID_RETURN_SHARE",
        "recomputed": "6 invited = 5 returned + 1 nonresponse; 5 returned = 5 valid; 5/6 = 83.333% → 83.3% (return rate); 5/5 = 100.0% (validity rate); 5/6 = 83.3% valid-returns-as-share-of-invitations, explicitly distinguished from the validity rate on PDF p.27",
        "verdict": "MATCH"
      },
      {
        "item": "Customer item sums, means, positive counts and rates (C-01…C-05)",
        "locator": "§6.3.2 items 2–6, PDF p.27; register SYN-0095-CUSTOMER-C-01…C-05-* (20 keys)",
        "recomputed": "C-01 5+4+5+3+4 = 21 → 4.20, positives 4 → 80.0%; C-02 5+4+4+3+4 = 20 → 4.00, positives 4 → 80.0%; C-03 4+4+5+3+4 = 20 → 4.00, positives 4 → 80.0%; C-04 5+4+5+3+4 = 21 → 4.20, positives 4 → 80.0%; C-05 5+4+5+3+4 = 21 → 4.20, positives 4 → 80.0%",
        "verdict": "MATCH"
      },
      {
        "item": "Follow-up pairing boundary and outcome figures",
        "locator": "§6.4 PDF p.28; §6.4.1 PDF p.29; register SYN-0095-SYN-L01…L12-PRE/POST30 (24 keys) and SYN-0095-FOLLOWUP_* (8 keys)",
        "recomputed": "14 valid = 12 paired + 2 unavailable (2 excluded from the paired denominator, not counted as failures); Σpre = 4+5+6+3+4+5+6+2+4+5+3+4 = 51 → 4.25; Σpost = 7+8+8+6+7+8+8+5+7+8+6+7 = 85 → 7.0833 → 7.08; Δ_abs = (85−51)/12 = 2.8333 → 2.83; Δ_rel = 34/51 = 0.6666… → 66.7%; post ≥ 7 for L01,L02,L03,L05,L06,L07,L09,L10,L12 = 9 → 9/12 = 75.0%; per-row Δ values +3,+3,+2,+3,+3,+3,+2,+3,+3,+3,+3,+3 and the non-pass cases L04(6), L08(5), L11(6) all match the table",
        "verdict": "MATCH"
      },
      {
        "item": "Learner ranking, gaps and dense-rank application under the §7.2 rule",
        "locator": "§7.2 learner matrix, PDF pp.30–31; §7.1 comparison table, PDF p.30; ranking rules (1)–(6), PDF p.30",
        "recomputed": "Positive rate ascending then mean ascending: L-03 71.4%/3.93 → P1; L-02 78.6%/4.00 and L-04 78.6%/4.00 → P2; L-01 78.6%/4.07 → P3; L-05 85.7%/4.14 → P4. Gaps to the in-group top (85.714%, 4.1429): 14.3/0.21, 7.1/0.14, 7.1/0.14, 7.1/0.07, 0.0/0.00",
        "verdict": "MATCH"
      },
      {
        "item": "Customer ranking, gaps and dense-rank application",
        "locator": "§7.2 customer matrix, PDF p.31; 序位解讀界線, PDF p.32; §7.1, PDF p.30",
        "recomputed": "All five positive rates 4/5 = 80.0%, so ordering is decided by mean alone: C-02 4.00 and C-03 4.00 → P1; C-01 4.20, C-04 4.20, C-05 4.20 → P2; positive-rate gaps 0.0 points for all, mean gaps 0.20 for C-02/C-03 and 0.00 for C-01/C-04/C-05; §7.1's statements (no relative highest or lowest positive-rate customer item; lowest-mean items 辦訓安排 and 實作演練) are consistent",
        "verdict": "MATCH"
      },
      {
        "item": "Single-record sensitivity scenario for L-03",
        "locator": "§7.2 sensitivity note, PDF p.32",
        "recomputed": "Removing SYN-L14's 2-point L-03 response: n = 13, sum = 55 − 2 = 53, mean = 53/13 = 4.0769 → ≈ 4.08, positive = 10/13 = 76.923% → 76.9%; positive-rate gap to L-05 (85.714%) = 8.79 → 8.8 points; mean gap to 4.1429 = 0.0660 → 0.07 points; P1 retained because 76.9% < 78.6% of L-02/L-04/L-01",
        "verdict": "MATCH"
      },
      {
        "item": "Rounding, N/A, missing-value and suppression rules versus the displayed values",
        "locator": "§5.2 rounding and zero-denominator rules, PDF p.21; §4.3 N/A and core-item validity rules, PDF p.19; §5.1 MISSING_ITEM/NA_TREATMENT/SUB_SUPPRESS, PDF p.20; §8.1 decision table, PDF p.34",
        "recomputed": "Means and Δ_abs shown to 2 dp, rates and Δ_rel to 1 dp as required; no displayed figure uses a rounded intermediate (34/51 computed from raw sums 85 and 51, 2.8333 from 34/12, not from 7.08−4.25); N/A excluded from item denominators and never treated as 0; a blank core item invalidates the whole form; n<5 sub-group suppression defined and no sub-group results published",
        "verdict": "MATCH"
      },
      {
        "item": "Register row/column/unique-key totals, status counts and R06→R08 key lineage against the manifest",
        "locator": "Supplied register CSV body; manifest row_count 211, column_count 13, unique_register_key true, fact_status_counts 134/13/7/4/53, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, r06_historical_row_count 208; §10 PDF p.41",
        "recomputed": "Counted the body: 15 case/population SYNTHETIC_FACT rows + 70 learner item rows + 25 customer item rows + 24 follow-up rows = 134 SYNTHETIC_FACT; 7 + 6 = 13 UNKNOWN_NOT_PROVIDED; 7 PROPOSED_CONTROL; 4 PROPOSED_ROLE; 53 DERIVED_SYNTHETIC_METRIC (40 item-metric + 5 rate + 8 follow-up) → 134+13+7+4+53 = 211 rows, 13 columns; 208 (R06) − 3 retired + 6 added = 211, with the three retired combined/pooled keys absent and all six added UNKNOWN index keys present; the contested CUSTOMER_VALID_RETURN_SHARE is present as a retained key",
        "verdict": "MATCH"
      },
      {
        "item": "Population non-aggregation and denominator separation",
        "locator": "§6.3.3, PDF p.27; §6.1/§6.2 denominators, PDF pp.23–25; §6.3.2 note, PDF p.27; §7.1, PDF p.30; 附圖 A 警示, PDF p.33; §7.2 讀表原則, PDF p.32",
        "recomputed": "Learner denominators (18/15/14) and customer denominators (6/5/5) are used separately throughout; no pooled return rate, pooled positive rate or combined satisfaction figure appears anywhere in the R10 text; the three retired combined/pooled register keys are absent; the 5/6 customer figure is labelled as a share of the invitation population, not as a validity rate",
        "verdict": "MATCH"
      },
      {
        "item": "Source-hash internal consistency across the packet and the document body",
        "locator": "§1.2 PDF p.2; §1.3 PDF p.2; §10 body PDF p.41; §10.1 附件 A PDF pp.41–42; 附件 A-1 PDF p.42; §10.2 PDF p.43; packet header",
        "recomputed": "Official source PDF SHA 805386b7…4709 (§1.2) matches; scoring-form source SHA 9d253829…83684 (§1.3) matches the packet's cited parent form; register CSV SHA 203583e4…0202c (§10 body, p.41) and manifest SHA df1b2517…17c0 (§10 body, 附件 A-1) match the packet values; however 附件 A prints the CSV hash as '203583e4…b1174840202ca' (65 characters, one trailing character beyond the bound 64-character value), and §1.3's cited scoring-form hash is the full form's SHA rather than the packet's page-4 extract SHA c789f8f0…adcf, and the packet's official page-6 extract SHA e0ecd2d7…20f02 is not reproduced in the body (only the parent source PDF SHA is). Hashes were compared for internal consistency only and were not independently recomputed.",
        "verdict": "MISMATCH"
      },
      {
        "item": "§1.4 locator spans against the current 44-page pagination",
        "locator": "§1.4 locator column, PDF p.4, rows 1–4; actual headings in the supplied 44-page export",
        "recomputed": "Verified correct: §2.1–§2.4 → pp.5–6; §3.1 → p.6; §3.2 → pp.7–9; §4.1 → pp.10–13; §4.2 → pp.13–17; §4.3 → pp.17–19; §5.1 heading/table → p.20; §6.1–§6.4 → pp.23–29; §6.3.3 → p.27; §6.4 → pp.28–29; §6.4.1 → p.29; §7.1 → p.30; §7.2 → pp.30–33 with 附圖 A → pp.32–33; §7.3–§7.4 → p.33; §8.1–§8.5 → pp.34–37; §10 → pp.41–44. Residual imprecisions: '§5.1 → p.20' omits the closing paragraph on p.21; '§5.2 → pp.21–22' includes p.22 (chapter 6 opening); '§9.5 → pp.38–40' omits the closing paragraph on p.41",
        "verdict": "PARTIAL"
      },
      {
        "item": "Register document_location page anchors against the current 44-page export",
        "locator": "CSV document_location column (211 rows); manifest page_locator_basis ('exact 43-page export inspected'); §10 R08 補充說明 (2), PDF p.41; §9.5 row 3, PDF p.38",
        "recomputed": "Every chapter-6-and-later register anchor is one page later than the current export (e.g. case id 'p. 23' → p.22; learner L-01 item rows 'p. 24' → p.23; learner derived metrics 'p. 27' → p.26; customer derived metrics 'p. 28' → p.27; follow-up rows 'p. 29' → p.28; follow-up derived 'p. 30' → p.29; §9.5 rows 'p. 39' → p.38) because the R10 §5.1 layout repair removed one page before chapter 6 while the register CSV was deliberately retained unchanged and SHA-bound. Chapter anchors, values, keys, statuses and row/column counts are unaffected; the same one-page drift appears in the document's own §9.5 row 3 reference ('索引本列見 PDF p.39').",
        "verdict": "MISMATCH"
      }
    ],
    "unknowns": [
      "Whether the DOCX renders 附圖 A as a drawn object: the packet supplies the figure's full specification, panel values, presentation rules, warnings and alt-text draft (PDF pp.32–33) and the separate R10 visual receipt states the figure is embedded on p.32, but text extraction does not encode pixels; per the packet instruction, no missing chart is alleged and no visual inspection is claimed.",
      "Typography compliance with the Blueprint floors (body ≥ 10.5pt, tables ≥ 9.5pt), column fit, orphan headings, blank pages, header/footer consistency and any image objects: not measurable from text-only PDF extraction; the packet's R10 technical and font-floor receipts report 10.5/9.5pt floors met, but that is a receipt claim I did not and cannot verify independently.",
      "Byte-level identity of the R10 DOCX (262965 bytes) and R10 Word-exported PDF (44 pages, SHA de40911b…5b4d): taken from the packet; the DOCX was not rehashed, the PDF was not re-rendered and no hash was recomputed by me.",
      "Whether the R10 semantic receipt (this review) and the external final-QA list binding the R10 PDF SHA and page count have been filed:附件 E and §10.2 record R10 receipts as 待執行 and the manifest state is CANDIDATE_QA_PENDING.",
      "Whether 附件 A's CSV SHA string (as extracted) genuinely carries a65th character in the rendered PDF or is a text-extraction artefact: the character is inline before a full-width semicolon in the extracted line, but confirming at rendering level is outside packet-only scope.",
      "All association-side facts remain UNKNOWN/NOT PROVIDED by design and are correctly held as such: existing survey system or adoption, committee or unit structure, authorised roles, approval and signature originals, formal and effective dates, real class/cohort identifiers, real invitation/delivery/return/valid counts, original questionnaires, nonresponse reasons, the invalid form's identity and other item values, real respondent roles and organisations, storage/access/retention paths, and the improvement decision, responsible person, deadline and follow-up originals.",
      "Whether the real-system promotion path (§9.5, eight item classes) can be closed, and whether any scored TTQS position follows: not determinable from the packet and outside this review's scope.",
      "Runtime/provider model identity: UNKNOWN absent direct attestation by the executing runtime; the requested route was OpenCode CLI v2.0.32 / opencode/minimax-m3.1-flash-free.",
      "The R06 register body itself was not supplied (only its row count, SHA and the key-set reconciliation), so the 205 retained keys were verified through the deterministic R06/R08 key-set reconciliation and the current body rather than by a full R06 re-count."
    ],
    "reviewer_limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used or attempted; no DOCX binary rehash, no PDF re-render, no DOCX XML extraction, no font-size or layout measurement, no spreadsheet or calculation engine.",
      "No visual inspection of the 44-page export was performed; every page, table, row, cell and heading reference above is read from the packet's page-bounded PDF text. Image presence or absence (including whether 附圖 A exists as a drawn object), typography, column fit, orphan headings and blank pages could not be confirmed, and I did not re-inspect the R10 contact sheets or page images; where I refer to the R10 visual receipt's statements, they are cited as receipt claims.",
      "All arithmetic was recomputed by hand from the raw response rows printed in §6.1, §6.2 and §6.4 and the full CSV body reproduced in the packet; register rows, status classes and key names were counted by reading the supplied body rather than by executing code.",
      "SHA-256 values (DOCX, PDF, CSV, manifest, official sources, Blueprint row) were compared for internal consistency only and were not independently recomputed; the reviewed DOCX SHA is bound exactly as supplied by the packet.",
      "Findings are bound to the DOCX SHA-256 4c52fe99…ee3630 as supplied. Any re-export, re-layout or content change invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, not an evaluation of the association's real practice, and not formal association acceptance. The deliverable remains CANDIDATE.",
      "R08's and R09's findings were reassessed independently from the current R10 text and the deterministic R06/R08 key-set reconciliation; where the reconciliation or the key set contradicts an allegation (R08-02), the allegation was not repeated, and no prior artefact was rewritten in the process."
    ],
    "provider_model_identity": "UNKNOWN — no direct attestation of the executing runtime or provider model was available in the packet; the requested route was OpenCode CLI v2.0.32 / opencode/minimax-m3.1-flash-free, but the reviewer cannot attest which model actually produced this response."
  },
  "R10_receipt": {
    "project_id": "TTQS_ONE",
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "revision": "R10",
    "candidate_state": "CANDIDATE_NOT_FORMALLY_ACCEPTED",
    "reviewer_route": "OpenCode CLI v2.0.32",
    "requested_model": "opencode/minimax-m3.1-flash-free",
    "session_model_id": "minimax-m3.1-flash-free",
    "session_id": "ses_ea6a9ccbcffe4ymF4O3XEyws5m",
    "provider_model_identity": "UNKNOWN",
    "exit_code": 0,
    "verdict": "PARTIAL",
    "blocking_findings": 0,
    "nonblocking_findings": [
      {
        "id": "NB-R10-01",
        "severity": "LOW_MEDIUM",
        "title": "§10.1 附件 A prints the register CSV SHA-256 as a 65-character string that does not equal the bound value"
      },
      {
        "id": "NB-R10-02",
        "severity": "LOW_MEDIUM",
        "title": "Replacement-register row-level PDF page anchors and the manifest page_locator_basis are anchored to the 43-page R08 export and are one page behind the current 44-page R10 export for all chapter-6-and-later entries"
      },
      {
        "id": "NB-R10-03",
        "severity": "LOW",
        "title": "Three §1.4 locator spans remain imprecise against the current 44-page R10 export"
      },
      {
        "id": "NB-R10-04",
        "severity": "INFORMATIONAL",
        "title": "R10's own QA chain is open at the semantic receipt by design"
      },
      {
        "id": "NB-R10-05",
        "severity": "INFORMATIONAL",
        "title": "Improvement-candidate robustness continues to rest on a 14-respondent synthetic learner sample and a 5-respondent synthetic customer sample"
      }
    ],
    "review_scope": "Packet-only independent semantic review of the R10 candidate for DOCX 0095 / I18-E02. All findings derive solely from the packet-supplied current R10 Word-exported PDF text (44 pages), the supplied R08 replacement-register CSV body (211 rows, 13 columns), the supplied register manifest, the Unique Blueprint and source binding, the R08 exact-SHA review and the deterministic R06/R08 register key-set reconciliation, the R09 exact-SHA review response and targeted repair manifest, and the R10 technical / visual / font-floor receipts (scope only). No shell, filesystem, browser, GUI, DOCX-binary rehash, PDF re-render, or visual inspection was performed or claimed; no prior PASS was inherited from the builder or from the R08/R09 reviews, and each R08/R09 finding was re-derived from the current R10 text. The DOCX SHA-256 4c52fe99…ee3630 is bound as the review target exactly as supplied by the packet and was not independently rehashed. This review assesses semantic content only; it is not a TTQS assessment, not a score, and not formal association acceptance. The candidate remains CANDIDATE.",
    "reviewed_sha256": "4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630",
    "pdf_sha256": "de40911be70a852798e285141b7f8536c7ae48c4e2285a715685d5d74bd65b4d",
    "packet_sha256": "040daf98a877c873c836c2e992c5a9e0388ba810ddde5741f5e3a62ec4e5246c",
    "raw_stdout_sha256": "e5a5f866463fc6bb825a3aa71304a764283814e8a24d77042af0b68a27a64682",
    "normalized_response_sha256": "6fe4399f240b92cd7f19e742376ebe46eb139dfe175c0ba0f0b6ba5da85f8ffd",
    "r08_finding_disposition": [
      {
        "id": "R08-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 evidence-locator table, PDF p.4, third column (文件證據定位), rows 1–4; actual section locations in the current 44-page export: §4.1 p.10, §4.2 p.13, §4.3 p.17, §5.1 pp.20–21, §5.2 p.21, §6.1 p.23, §6.3.3 p.27, §6.4 pp.28–29, §6.4.1 p.29, §7.1 p.30, §7.2 pp.30–32, 附圖 A pp.32–33, §7.3/§7.4 p.33, §8.1–§8.5 pp.34–37, §9.5 pp.38–41, §10 pp.41–44",
        "rationale": "The defect R08-01 named is fixed: §7.3–§7.4 is cited to the single page where both headings print (p.33), and the R08 row-1/row-2 spans for §4.1/§4.2/§4.3 and §2–§3 now agree with the observed section starts in the 44-page export. The table is also itemised per section and self-limited by the pagination-anchor warning at PDF p.5 and the R08 lineage note at p.41. It is not fully closed because three spans remain mis-anchored: '§5.1 → p.20' omits §5.1's closing paragraph on p.21; '§5.2 → pp.21–22' includes p.22, which opens chapter 6; and '§9.5 → pp.38–40' omits §9.5's closing paragraph on p.41. These are audit-trail precision defects in the document's primary navigation table, not false pointers, so the finding is marked PARTIALLY_CLOSED and the residuals are itemised as NB-R10-03."
      },
      {
        "id": "R08-02",
        "disposition": "CLOSED",
        "exact_locator": "CSV body row SYN-0095-CUSTOMER_VALID_RETURN_SHARE (fact_status DERIVED_SYNTHETIC_METRIC, fact_type rate, value 83.3, unit percent, document_location '§6.3.2 …；PDF p. 28'); deterministic R06/R08 register lineage countercheck in the packet; §10 lineage sentence PDF p.41 ('208 − 3 + 6 = 211；205 = 208 − 3'); manifest r06_historical_row_count 208, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, row_count 211",
        "rationale": "R08-02 alleged an uncounted added key. The exact key set disproves it: SYN-0095-CUSTOMER_VALID_RETURN_SHARE is present in the supplied current CSV body and in the R06 row quoted in the packet's deterministic R06/R08 key-set reconciliation with identical fact_status, fact_type, value and unit (only document_location gained a page locator), so it is among the 205 retained keys and is neither an addition nor a retirement. The complete key-set difference is exactly the three listed removals and six listed UNKNOWN additions, and I confirmed by counting the supplied body that it holds 211 rows with 13 columns and status counts 134/13/7/4/53. I therefore do not repeat the allegation. The R10 body additionally closes the lineage arithmetic on its face by naming the 208-key R06 base, so the presentational gap R09 identified is also resolved."
      },
      {
        "id": "R08-03",
        "disposition": "CLOSED",
        "exact_locator": "§4.1 PDF p.10, block 【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】 immediately above the blank REAL 班次編號 field; §4.1 PDF p.11, 示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）: SYN-TRN-01 and 示範培訓日期 2026-07-11; §4.2 PDF p.14, same block; §4.2 PDF p.15, 示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11 above the four blank REAL date fields with the no-backfill instruction",
        "rationale": "R08-03 flagged that a literal 'no approved class identifier' statement sat one line above a filled-in synthetic identifier and a pre-filled sample date, creating a residual risk of the sample value being read as an administration fact. R10 (unchanged from R09 here) has closed this: each instrument states in a header block that no verified and approved real class identifier is provided and that the following code is synthetic only; the sample class code and the sample dates are individually labelled SAMPLE／SYNTHETIC／未核定／非正式班次／非實際辦訓日期; every REAL field is blank with format instructions; the 欄位分區說明 legend states the sample sheet leaves every REAL field blank; and the form explicitly forbids back-filling the sample date into the REAL fields. The wording risk R08-03 identified is not present in the current text."
      },
      {
        "id": "R08-04",
        "disposition": "OPEN",
        "exact_locator": "§10.1 附件 D (0095_R10_CANDIDATE.pdf; 'PDF SHA-256 及頁數由同套件最終 QA 清冊綁定') and 附件 E ('R10 各收據須明列 DOCX exact SHA…本索引不自行宣告 PASS，R10 收據於本版製稿時待執行'), PDF p.42; §10.2 R10 row PDF p.43 ('R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行'); manifest state CANDIDATE_QA_PENDING",
        "rationale": "This is a workflow state rather than a document-body defect and it remains open by design: the candidate's own QA chain is open at the semantic receipt for R10, Attachment D binds the Word-exported PDF only through an external final-QA list, and the body consistently refuses to self-declare PASS, deferring the independent result to the external package receipt bound to this version's DOCX SHA. The packet now supplies R10 technical, visual and font-floor receipts, so the body's '待執行' statement is conservative and stale-by-drafting-time rather than false, and the semantic receipt is what this review constitutes. I record it as OPEN because the R10 semantic receipt did not exist in the supplied evidence when the candidate body was written; it is not counted as a material semantic defect and does not affect the body assessment."
      },
      {
        "id": "R08-05",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.32 (L-03 非正向 4 份: 1 份 2 分 SYN-L14, 2 份 3 分 SYN-L04/SYN-L11, 1 份未逐筆識別; 情境演算 n=13, 總分 53, 平均約 4.08, 10/13＝76.9%, 差距收斂為 8.8 個百分點與 0.07 分; 目標客戶端 n=5 每題各 1 份非正向回覆，單一填答者對應 20 個百分點); §7.3 items 1–4, PDF p.33; §7.4, PDF p.33; §6.4 追蹤遺漏處理, PDF p.28; §8.4 PDF p.35; §8.5 PDF pp.36–37",
        "rationale": "R08-05 concerned the residual inherent limitation of a 14-respondent synthetic sample and of the customer track's n=5 giving each respondent 20 percentage points of influence. R10 keeps both sensitivities disclosed with causes UNKNOWN and an explicit prohibition on inferring group differences: the L-03 single-2-point scenario is recomputed and shown not to change the P1 ordering and is expressly not a re-test result nor a basis for excluding the response; the customer20-point effect is stated with the reading limit that the five facets share the same 4/5 positive count and therefore cannot be read as agreement or representativeness. §7.3 adds small-sample, nonresponse-causality and paired-subset limits, §6.4 excludes the two unpaired learners from the paired denominator without treating them as failures, and §8.4/§8.5 keep cause, owner, deadline and status UNKNOWN or blank. The limitation is disclosed rather than concealed and the R10 repairs did not alter any of this text, so the finding is closed; the underlying small-sample limitation persists as an inherent property of the SAMPLE/SYNTHETIC design and is carried as NB-R10-05 and in unknowns."
      }
    ],
    "r09_finding_disposition": [
      {
        "id": "NB-R09-01",
        "disposition": "PARTIALLY_CLOSED",
        "exact_locator": "§1.4 locator column, PDF p.4, rows 1–4, third column; actual locations in the supplied 44-page export: §2.1 p.5, §2.4 p.6, §3.1 p.6, §3.2 pp.7–9, §4.1 pp.10–13, §4.2 pp.13–17, §4.3 pp.17–19, §5.1 pp.20–21, §5.2 p.21, §6.1–§6.4 pp.23–29, §6.3.3 p.27, §6.4.1 p.29, §7.1 p.30, §7.2 pp.30–33 (附圖 A pp.32–33), §7.3/§7.4 p.33, §8.1–§8.5 pp.34–37, §9.5 pp.38–41, §10 pp.41–44",
        "rationale": "I re-derived every §1.4 locator against the current 44-page export rather than reusing R09's 43-page anchors. All four spans R09 named as defective are repaired: §5.1 now points to p.20 (its heading and the complete dictionary table, SUB_SUPPRESS included, print on p.20 after the R10 layout repair), §6.3.3/§6.4/§6.4.1 are itemised to p.27 / pp.28–29 / p.29 and match the observed headings, §7.1/§7.2 are itemised to p.30 / pp.30–33 with 附圖 A at pp.32–33, and §2.1–§2.4 → pp.5–6 now fully contains the §2.4 boundary table that R09 found completing later. The §7.3–§7.4 → p.33 pointer remains correct. The finding is not fully closed because three residual spans remain imprecise against the 44-page export: '§5.1 → p.20' omits §5.1's closing paragraph on p.21; '§5.2 → pp.21–22' includes p.22, which opens chapter 6; and '§9.5 → pp.38–40' omits §9.5's closing paragraph on p.41 (the same one-page drift is visible in the document's own cross-reference at p.38, where §9.5 row 3 states '索引本列見 PDF p.39' although that row prints on p.38). These are navigation-precision defects in the audit trail, not false pointers, so NB-R09-01 is PARTIALLY_CLOSED and the residuals are itemised as NB-R10-03."
      },
      {
        "id": "NB-R09-02",
        "disposition": "CLOSED",
        "exact_locator": "§10 body PDF p.41 ('R06 原有 208 個鍵；R08 移除 3 個…保留其餘 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，故清冊為 208 − 3 + 6 = 211 筆資料列、13 欄'); R08 補充說明 (3) PDF p.41 ('R06 原有 208 鍵…205 = 208 − 3…208 − 3 + 6 = 211；R06、R07 歷史 CSV 與 manifest 均維持原件，不回溯改寫'); manifest r06_historical_row_count 208, r08_current_rows_from_r06 205, r08_added_unknown_index_rows 6, retired_r08_rows 3, row_count 211, column_count 13",
        "rationale": "R09's finding was that the §10 lineage sentence gave 205 + 6 − 3 without naming the 208-key R06 base, so it did not visibly close to the delivered 211 rows. R10 repairs this in two places, not one: both the §10 body paragraph and the R08 補充說明 (3) now state the R06 base of 208 keys, the removal of 3 merged/pooled keys, the 205 retained keys and the 6 added UNKNOWN index keys, and both print the closing equation 208 − 3 + 6 = 211 with 205 = 208 − 3. I independently verified the arithmetic against the supplied CSV body (211 rows, 13 columns, three retired keys absent, six added UNKNOWN keys present, contested key retained) and against the manifest, so the lineage now closes on its face and no row is unaccounted for."
      },
      {
        "id": "NB-R09-03",
        "disposition": "CLOSED",
        "exact_locator": "§9.5 row 6, PDF p.39 ('共 40 個題項鍵；另有 5 個分軌分母／回收衍生鍵（SYN-0095-LEARNER_RETURN_RATE、LEARNER_VALID_RATE、CUSTOMER_RETURN_RATE、CUSTOMER_VALID_RATE、CUSTOMER_VALID_RETURN_SHARE）及 8 個訓後追蹤計算鍵。全清冊共 53 個 DERIVED_SYNTHETIC_METRIC 鍵'); CSV body derived rows; manifest fact_status_counts.DERIVED_SYNTHETIC_METRIC 53",
        "rationale": "R09 found that §9.5 row 6 stated '40 列' for the derived item-metric subset while its own parenthetical named only two of the four derived rate keys, leaving SYN-0095-LEARNER_VALID_RATE and SYN-0095-CUSTOMER_VALID_RATE outside the sentence and making the '40' read as the whole derived population. R10 now names all five rate keys explicitly and re-scopes the count as '共 40 個題項鍵' alongside '5 個分軌分母／回收衍生鍵' and '8 個訓後追蹤計算鍵', summing to 53. I verified this by counting the actual CSV body by key name rather than by inheriting the categories: 10 items × 4 (SUM/MEAN/POSN/POSRATE) = 40 item-metric keys, 5 rate keys and 8 follow-up keys = 53 DERIVED_SYNTHETIC_METRIC rows, equal to the manifest count, with every stated value matching my recomputation."
      },
      {
        "id": "NB-R09-04",
        "disposition": "CLOSED",
        "exact_locator": "§10.1 附件 E, PDF p.42 ('R09 exact-SHA 收據已完成；R09 外部語意審查為 PARTIAL、0 blocking、5 nonblocking…provider model identity UNKNOWN…本索引不自行宣告 PASS，R10 收據於本版製稿時待執行'); §10.2 R09 row PDF p.43 ('R09 exact-SHA OpenCode review 為 PARTIAL、0 blocking、5 nonblocking…provider model identity UNKNOWN；本件仍為 CANDIDATE'); §10.2 R10 row PDF p.43 ('R10 仍為 CANDIDATE；本版 own exact-SHA QA 待執行'); closing statement PDF p.44",
        "rationale": "R09 asked for two things: that the historical R09 exact-SHA receipt and result be recorded faithfully, and that R10 not self-declare its own QA complete in the body. Both hold in the current R10 text. 附件 E records the R09 receipt as completed with the result PARTIAL, 0 blocking, 5 nonblocking, the response and receipt paths, the requested route and provider model identity UNKNOWN, and the packet-only/no-visual/no-rehash scope — all consistent with the R09 receipt in the packet. R10's own receipts are recorded as 待執行 and the document states expressly 本索引不自行宣告 PASS, repeats that the independent semantic result must come from the external package receipt bound to this version's DOCX SHA (PDF p.43), and the closing statement on p.44 again restricts the review to the specified exact SHA and disclaims association approval. Manifest state remains CANDIDATE_QA_PENDING. The only residual is informational (NB-R10-04): the body statement is conservative relative to the R10 technical/visual receipts now supplied in the package."
      },
      {
        "id": "NB-R09-05",
        "disposition": "CLOSED",
        "exact_locator": "§7.2 低分回覆計數與敏感度註記, PDF p.32; §7.3 items 1–4, PDF p.33; §7.4, PDF p.33; §6.4 追蹤遺漏處理, PDF p.28; §6.3.3, PDF p.27; §1.3 item 2, PDF p.2; §8.5, PDF pp.36–37",
        "rationale": "R09 asked that the improvement candidate's robustness not rest on the 14-respondent learner sample and 5-respondent customer sample without disclosure. The R10 text keeps the same disclosures unchanged: the L-03 single-record sensitivity is recomputed (n=13, sum 53, mean ≈4.08, 10/13＝76.9%, gap narrowing to 8.8 points and 0.07 points, P1 unchanged) with the explicit statements that it is a情境演算, not a re-test result and not a basis for excluding the response; the customer track's 20-percentage-point-per-respondent effect is stated; nonresponse reasons are UNKNOWN with no bias direction inferred; the n<5 suppression rule is defined and no sub-group data is published; the paired sub-set is limited to 12 records with the other 2 excluded rather than treated as failures; §6.3.3 forbids pooling or cross-group comparison; §1.3 separates satisfaction from performance; and §8.4/§8.5 keep cause, owner, deadline and status UNKNOWN or blank. The samples are therefore disclosed and are nowhere promoted as association performance, and no R10 repair broadened the evidential claim. The inherent limitation itself persists as NB-R10-05 and in unknowns."
      }
    ],
    "limitations": [
      "Packet-only review: no shell, filesystem, browser, GUI or other tooling was used or attempted; no DOCX binary rehash, no PDF re-render, no DOCX XML extraction, no font-size or layout measurement, no spreadsheet or calculation engine.",
      "No visual inspection of the 44-page export was performed; every page, table, row, cell and heading reference above is read from the packet's page-bounded PDF text. Image presence or absence (including whether 附圖 A exists as a drawn object), typography, column fit, orphan headings and blank pages could not be confirmed, and I did not re-inspect the R10 contact sheets or page images; where I refer to the R10 visual receipt's statements, they are cited as receipt claims.",
      "All arithmetic was recomputed by hand from the raw response rows printed in §6.1, §6.2 and §6.4 and the full CSV body reproduced in the packet; register rows, status classes and key names were counted by reading the supplied body rather than by executing code.",
      "SHA-256 values (DOCX, PDF, CSV, manifest, official sources, Blueprint row) were compared for internal consistency only and were not independently recomputed; the reviewed DOCX SHA is bound exactly as supplied by the packet.",
      "Findings are bound to the DOCX SHA-256 4c52fe99…ee3630 as supplied. Any re-export, re-layout or content change invalidates this verdict and requires a new exact-SHA review.",
      "This is a semantic review of the supplied candidate only. It is not a TTQS assessment, not a score, not an evaluation of the association's real practice, and not formal association acceptance. The deliverable remains CANDIDATE.",
      "R08's and R09's findings were reassessed independently from the current R10 text and the deterministic R06/R08 key-set reconciliation; where the reconciliation or the key set contradicts an allegation (R08-02), the allegation was not repeated, and no prior artefact was rewritten in the process."
    ],
    "formal_acceptance": "NOT_ASSERTED",
    "created_local": "2026-10-20T20:53:03.0540471+08:00"
  }
}
```

## R11 writer change response (evidence, not acceptance)

```json
{
  "patches": [
    {
      "id": "P1",
      "anchor": "§1.2 source-trace passage naming the official-source PDF SHA-256 805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709 (extract SHA not printed in R10)",
      "replacement": "Official source: PDF SHA-256 805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709; page-6 extract of that same PDF SHA-256 e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02. Two labels are stated separately: the parent PDF and the exact extracted page. The page-6 extract carries the official checkbox 建立目標客戶及學員滿意度調查機制（系統及流程面） (DOCX 0095 = I18-E02)."
    },
    {
      "id": "P2",
      "anchor": "§1.3 scoring-form passage naming the scoring-form PDF SHA-256 9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684 (extract SHA not printed in R10)",
      "replacement": "Scoring source: scoring-form PDF SHA-256 9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684; page-4 extract of that same PDF SHA-256 c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf. Two labels are stated separately: the parent PDF and the exact extracted page."
    },
    {
      "id": "P3",
      "anchor": "§1.4 locator table, cell for the §5.1 row",
      "replacement": "§5.1, pp.20–21 (R10 export pages; to be re-anchored to the final R11 PDF)"
    },
    {
      "id": "P4",
      "anchor": "§1.4 locator table, cell for the §5.2 row",
      "replacement": "§5.2, p.21 (R10 export page; to be re-anchored to the final R11 PDF)"
    },
    {
      "id": "P5",
      "anchor": "§1.4 locator table, cell for the §9.5 row",
      "replacement": "§9.5, pp.38–41 (R10 export pages; to be re-anchored to the final R11 PDF)"
    },
    {
      "id": "P6",
      "anchor": "§1.4 locator table, all remaining locator cells other than the §5.1, §5.2 and §9.5 rows",
      "replacement": "{{FINAL_PAGE_LOCATORS:§1.4_<target>}} — each remaining §1.4 locator is set from the final R11 PDF only; R10-export locators are held as provisional until re-verified against that render, and no unverified locator is presented as confirmed."
    },
    {
      "id": "P7",
      "anchor": "§9.5 table, row 3, self-location cell reading 'PDF p.39'",
      "replacement": "PDF p.{{FINAL_PAGE_LOCATORS:§9.5_row3}} (in the 44-page R10 export, SHA-256 de40911be70a852798e285141b7f8536c7ae48c4e2285a715685d5d74bd65b4d, this row is on PDF p.38; the R10 self-location 'PDF p.39' was one page late, and the R11 value is fixed only after the final render)"
    },
    {
      "id": "P8",
      "anchor": "§9.5 table, page-anchor note printed beneath the table (R10 anchor printed as p.39)",
      "replacement": "Page anchor: §9.5 is anchored to PDF p.{{FINAL_PAGE_LOCATORS:§9.5}} of the final R11 export; in the 44-page R10 export the table occupies PDF pp.38–41 and row 3 sits on PDF p.38, so the earlier p.39 anchor was one page late. Row-level anchors are re-verified against the final R11 PDF."
    },
    {
      "id": "P9",
      "anchor": "§10 register/manifest lineage paragraph describing the R08 register (211 rows, 13 columns) and its page-anchor binding",
      "replacement": "Register lineage: the R08 register (211 rows, 13 columns; CSV SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c; manifest SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0) was bound to the 43-page R08 export and is preserved unchanged as a historical artifact; its row-level page locations were not checked against the R10 or R11 exports and are not represented as checked. A new R11 register and manifest will be issued after the final R11 render and bound to that exact PDF (CSV SHA-256 {{CSV_SHA256}}, manifest SHA-256 {{MANIFEST_SHA256}}, PDF SHA-256 {{FINAL_PDF_SHA256}}, {{FINAL_PAGE_COUNT}} pages), with every R11 row anchor re-anchored to that render."
    },
    {
      "id": "P10",
      "anchor": "Appendix A (Attachment A) row for the R08 register, containing the printed SHA 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202ca (65 characters, extra trailing 'a')",
      "replacement": "R08 register (historical, retained unchanged) | 211 rows x 13 columns | CSV SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c (64 characters; the R10 row carried an extra trailing 'a') | manifest SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0 | bound to the 43-page R08 export; row-level page locations not checked against the R10 or R11 exports"
    },
    {
      "id": "P11",
      "anchor": "Appendix A (Attachment A), new R11 attachment row inserted after the R08 row",
      "replacement": "R11 register and manifest (to be issued after the final R11 render) | CSV SHA-256 {{CSV_SHA256}} | manifest SHA-256 {{MANIFEST_SHA256}} | bound to the final R11 PDF SHA-256 {{FINAL_PDF_SHA256}} ({{FINAL_PAGE_COUNT}} pages); every row anchor re-anchored to that render"
    },
    {
      "id": "P12",
      "anchor": "Appendix E independent-review record for the R10 manuscript (OpenCode CLI v2.0.32 review, verdict PARTIAL)",
      "replacement": "Independent review of R10 (packet-only): OpenCode CLI v2.0.32, requested route opencode/minimax-m3.1-flash-free; reported model ID minimax-m3.1-flash-free, provider model identity UNKNOWN. Reviewed DOCX SHA-256 4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630. Verdict PARTIAL — zero blocking findings and five nonblocking findings. The review did not rehash the DOCX, render the PDF or inspect images, and is not formal TTQS acceptance. R10 semantic review closed NB-R09-02, NB-R09-03, NB-R09-04 and NB-R09-05; NB-R09-01 remained only partially closed because of residual page-span precision. R11: independent technical, visual and semantic QA pending; status CANDIDATE."
    },
    {
      "id": "P13",
      "anchor": "Version-history table, new R11 row inserted after the R10 row",
      "replacement": "R11 | CANDIDATE — independent technical, visual and semantic QA pending | Audit-trail repair only: §1.2 and §1.3 now label the parent PDF SHA-256 and the exact extracted-page SHA-256; §1.4 locators set to §5.1 pp.20–21, §5.2 p.21 and §9.5 pp.38–41, with remaining locators held at {{FINAL_PAGE_LOCATORS}} until re-anchored to the final R11 PDF; §9.5 row-3 self-location corrected from 'PDF p.39' to the R10 p.38 anchor with the final value at {{FINAL_PAGE_LOCATORS}}; Appendix A R08 CSV SHA-256 corrected to 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c; a new R11 register and manifest will be bound to the final R11 PDF ({{CSV_SHA256}}, {{MANIFEST_SHA256}}, PDF SHA-256 {{FINAL_PDF_SHA256}}, {{FINAL_PAGE_COUNT}} pages); R10 retained unchanged as history; no analysis, data, calculation, finding, ranking, chart value or role-design content altered"
    },
    {
      "id": "P14",
      "anchor": "Version-history table, R10 row, status cell only (all other R10 row text retained verbatim)",
      "replacement": "Historical (R10 sealed and retained unchanged; superseded by the R11 candidate)"
    }
  ],
  "r11_status_line": "R10 carries an independent OpenCode CLI v2.0.32 review of reviewed DOCX SHA-256 4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630 with a PARTIAL verdict, zero blocking and five nonblocking findings, and R11 remains CANDIDATE with independent technical, visual and semantic QA still pending.",
  "register_policy": "The R08 register and manifest bound to the 43-page R08 export are preserved unchanged as historical artifacts, and a new R11 register and manifest will be issued after the final R11 render and bound to that exact PDF.",
  "values_to_fill_after_final_render": [
    "CSV_SHA256",
    "MANIFEST_SHA256",
    "FINAL_PDF_SHA256",
    "FINAL_PAGE_COUNT",
    "FINAL_PAGE_LOCATORS"
  ],
  "preservation_checks": [
    "R10 is treated as historical: no R10 body text, analysis, questionnaire items, synthetic data, calculations, findings, ranking, chart values, role design or association facts are rewritten; in the version-history table only the R10 status cell is annotated and all other R10 row text is retained verbatim.",
    "No claim that the association adopted, executed or decided anything, and no statement that the R11 review has passed, that R11 QA is complete, or that R11 is accepted; R11 is stated as CANDIDATE with independent technical, visual and semantic QA pending.",
    "R08 register CSV and manifest files remain byte-for-byte unchanged (CSV SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c; manifest SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0) and are described as bound to the 43-page R08 export only.",
    "No claim is made that the R08 row-level page locations were checked against the R10 or R11 exports; R10/R11 page shifts are handled by re-anchoring each row to the final R11 render rather than by subtracting one page from every number (some §10 source references remain at pp.41–42 in the R10 export).",
    "All SHA-256 values appear as exactly 64 hex characters; the 65-character R08 CSV SHA with the trailing 'a' is removed and the corrected value is used in both Appendix A and §10.",
    "Both extract labels are printed with their own SHA-256 in §1.2 (official PDF 805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709, page-6 extract e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02) and §1.3 (scoring PDF 9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684, page-4 extract c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf).",
    "Review facts are reproduced exactly as recorded: OpenCode CLI v2.0.32, requested route opencode/minimax-m3.1-flash-free, reported model ID minimax-m3.1-flash-free, provider model identity UNKNOWN, verdict PARTIAL with zero blocking and five nonblocking findings, packet-only scope (no DOCX rehash, no PDF render, no image inspection), and not formal TTQS acceptance.",
    "R09 finding history is preserved unchanged: NB-R09-02, NB-R09-03, NB-R09-04 and NB-R09-05 closed; NB-R09-01 partially closed only because of residual page-span precision.",
    "All examples remain SAMPLE/SYNTHETIC, and missing REAL source classes remain UNKNOWN; document identity is limited to DOCX 0095 = I18-E02 with official checkbox 建立目標客戶及學員滿意度調查機制（系統及流程面）, and neighbours 0094/I18-E01 and 0096/I18-E03 remain unchanged; the unique Blueprint row SHA-256 9a22b3acd4bdafb15f18c15ee89088f4fb5ee334bfef9a1917fcc5740b7979c2 is carried forward unchanged and no new blueprint rows or source classes are introduced.",
    "No R11 hash, page count or locator is asserted before the final render: every unknown value stays as {{CSV_SHA256}}, {{MANIFEST_SHA256}}, {{FINAL_PDF_SHA256}}, {{FINAL_PAGE_COUNT}} or {{FINAL_PAGE_LOCATORS}}, and the R10 render reference (44 pages, SHA-256 de40911be70a852798e285141b7f8536c7ae48c4e2285a715685d5d74bd65b4d) is cited only as the R10 export."
  ]
}
```

## R11 technical, font-floor, visual and current register evidence

```json
{
  "technical": {
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "state": "PASS_BOUNDED_TECHNICAL_READBACK",
    "docx_sha256": "6fa3f1e3eed3827eb40d7f6916d3e759b2abd3ca8c9dd7525f0dd084df22f420",
    "docx_bytes": 263773,
    "pdf_sha256": "7c2a636b2dd58586366055914eeda5ddf3bb22aa36d2d40e0e962bda35f375d6",
    "pdf_pages": 44,
    "paragraphs": 382,
    "tables": 29,
    "sections": 19,
    "zip_crc_clean": true,
    "required_text_missing": [],
    "unrendered_math_commands": [],
    "register_sha256": "df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee",
    "register_rows": 211,
    "register_columns": 13,
    "manifest_sha256": "45357ed001e8720a129883924630e9d8125f9dc9e0a9f7fd1cefc2d774008c28",
    "manifest_csv_hash_matches": true,
    "table_run_font_floor_pt": 9.5,
    "explicit_table_run_sizes_count": 991,
    "limitations": [
      "Does not establish semantic acceptance, authentic association execution, signatures, approvals, or formal submission."
    ]
  },
  "font_floor": {
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "docx_sha256": "6fa3f1e3eed3827eb40d7f6916d3e759b2abd3ca8c9dd7525f0dd084df22f420",
    "pdf_sha256": "7c2a636b2dd58586366055914eeda5ddf3bb22aa36d2d40e0e962bda35f375d6",
    "minimum_explicit_table_run_font_pt": 9.5,
    "explicitly_sized_table_runs": 991,
    "font_floor": "PASS",
    "basis": "Read directly from word/document.xml w:tbl run properties; inherited style values are not counted as explicit sizes."
  },
  "visual": {
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "docx_sha256": "6fa3f1e3eed3827eb40d7f6916d3e759b2abd3ca8c9dd7525f0dd084df22f420",
    "pdf_sha256": "7c2a636b2dd58586366055914eeda5ddf3bb22aa36d2d40e0e962bda35f375d6",
    "page_count": 44,
    "render_engine": "Microsoft Word COM read-only PDF export; Poppler page rasterization at 90 dpi",
    "status": "PASS_WITH_NONBLOCKING_LAYOUT_NOTE",
    "scope": {
      "all_pages": "All 44 pages reviewed in three full-document contact sheets.",
      "high_resolution_current_revision": [
        "PDF p.19",
        "PDF p.20"
      ],
      "high_resolution_inherited_from_final01_identical_90dpi": [
        "PDF p.2-p.5",
        "PDF p.18",
        "PDF p.21",
        "PDF p.38-p.44"
      ],
      "changed_pages_since_final01": [
        19,
        20
      ]
    },
    "image_sha256": {
      "contact_01_16.jpg": "a8042348da178562cba5b31fee715f13b281401999f5ed4e6c8c45089bb656ad",
      "contact_17_32.jpg": "fd457af76136feca17bca59aa256a688bfd2bf971f1e6f96e2154c9b689d2f3c",
      "contact_33_44.jpg": "3a79e8b908c1850d9e4279f179d3cd8265c7fd48ad38ec562ddfa14a2b60f001",
      "page-19.png": "3244b923445a9f287e53a5e11acfe8c30e140f6afcf404de421fdc80dcaf6e57",
      "page-20.png": "a7590a0158ee09c625a759a826465012ced9b3921a03c9bceb942df60eeb7b60"
    },
    "observations": [
      "No clipping, overlap, or unintended blank page observed in the inspected scope.",
      "p.20 combined section 5 and 5.1 heading fits with the data dictionary table on the same landscape page; the previous orphan parent heading is resolved.",
      "p.19 is a sparse but readable conclusion to section 4.3; retain as nonblocking layout note."
    ],
    "limitations": [
      "Contact sheets support whole-document visual screening; high-resolution page inspection is concentrated on changed pages and previously inspected critical pages.",
      "No independent semantic review is represented by this receipt."
    ]
  },
  "register_manifest": {
    "doc_id": "0095",
    "requirement_id": "I18-E02",
    "official_checkbox": "建立目標客戶及學員滿意度調查機制（系統及流程面）。",
    "state": "CANDIDATE_QA_PENDING",
    "register_file": "0095_R11_synthetic_replacement_register.csv",
    "row_count": 211,
    "column_count": 13,
    "unique_register_key": true,
    "fact_status_counts": {
      "SYNTHETIC_FACT": 134,
      "UNKNOWN_NOT_PROVIDED": 13,
      "PROPOSED_CONTROL": 7,
      "PROPOSED_ROLE": 4,
      "DERIVED_SYNTHETIC_METRIC": 53
    },
    "r08_current_rows_from_r06": 205,
    "r08_added_unknown_index_rows": 6,
    "r06_historical_register_sha256": "7f2034e3a7cc77e3a327a59a49ad90d3e2970c7ac01d7c03336b2ad4d572347f",
    "r06_historical_row_count": 208,
    "r07_historical_register_sha256": "ba5e5e1c8f0191e7298502976e5f9d02a164d4e799a1de2a7f1514f66a7fc3d4",
    "r07_historical_row_count": 214,
    "prior_r08_register_sha256": "615b282278d8c95fa632ed709cc1e358fc9ddcf33fa511ef5b605d9a419b04e9",
    "current_csv_sha256": "df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee",
    "retired_r08_rows": [
      "SYN-0095-COMBINED_RETURN_RATE",
      "SYN-0095-COMBINED_VALID_RATE",
      "SYN-0095-POOLED_POSITIVE_RATE"
    ],
    "retirement_basis": "The three combined/pooled derived metrics were removed from current R08 after §6.3.3 was changed to preserve learner and target-customer populations separately; historical R06/R07 files remain unchanged.",
    "preserved_nonlocation_fields_vs_r07": true,
    "page_locator_basis": "Final 44-page R11 Microsoft Word PDF page map; all 211 register locations checked against the final render and section map. Exact DOCX/PDF SHA and visual scope are recorded in the separate R11 visual QA receipt; no self-referential PDF hash is embedded in this register manifest.",
    "sample_real_boundary": "All synthetic facts remain SAMPLE/SYNTHETIC; six UNKNOWN rows mark missing real-source classes; no real evidence is asserted.",
    "source_refs": {
      "official_source_page6_sha256": "e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02",
      "unique_blueprint_sha256": "9a22b3acd4bdafb15f18c15ee89088f4fb5ee334bfef9a1917fcc5740b7979c2"
    },
    "r08_added_keys_vs_r06": [
      "UNK-0095-UNK_APPROVAL_SIGNATURE",
      "UNK-0095-UNK_ATTACHMENT_STORAGE_LOCATION",
      "UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY",
      "UNK-0095-UNK_FORMAL_EFFECTIVE_DATE",
      "UNK-0095-UNK_IMPROVEMENT_ORIGINALS",
      "UNK-0095-UNK_REAL_COURSE_COHORT"
    ],
    "r08_retained_rows_from_r06": 205,
    "r06_omitted_keys_from_r08": [
      "SYN-0095-COMBINED_RETURN_RATE",
      "SYN-0095-COMBINED_VALID_RATE",
      "SYN-0095-POOLED_POSITIVE_RATE"
    ],
    "register_revision_history": [
      {
        "previous_csv_sha256": "323b5bcd890cf4811f277e89e407650fb295edcf9e9aef8fa3afa28f0a54be6a",
        "reason": "Rebound PDF page locators to the directly inspected 43-page Word export; no fact values changed."
      },
      {
        "previous_csv_sha256": "203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c",
        "reason": "Re-anchored only the document_location page layer from R08 PDF locators to the R10 final04 44-page export, preserving all nonlocation fields; pending final R11 export verification."
      },
      {
        "previous_csv_sha256": "bce85d930d2720efae66710a382d8adbb134355ed982e740b2f2c586dc444816",
        "reason": "Corrected 13 row-level page locators from direct R11 PDF inspection, including customer return/validity rates on p.26, section 5.2 on p.21, and §9.5 rows 7–8 on p.40; all non-location fields preserved."
      }
    ],
    "prior_r08_csv_sha256": "203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c",
    "revision": "R11",
    "candidate_state": "CANDIDATE_QA_PENDING",
    "page_locator_validation": {
      "register_rows_checked": 211,
      "out_of_bounds_page_references": 0,
      "targeted_corrections": 13,
      "verified_pdf_page_count": 44,
      "exact_pdf_sha256_recorded_in_external_visual_qa_receipt": true
    }
  }
}
```

## Full R11 manuscript

# 建立目標客戶及學員滿意度調查機制（系統及流程面）分析報告

> **文件狀態宣告**  
> 本件為 DOCX 0095／I18-E02「建立目標客戶及學員滿意度調查機制（系統及流程面）」之候選分析報告，包含一套供審議的機制設計與完整 SAMPLE／SYNTHETIC 示範。文內角色、程序、表單及控制均屬提案；目前沒有來源證明原始點協會已採納、核准或執行本文制度。協會是否已有相關制度、實際授權、課程、對象、調查和真實結果均為 UNKNOWN／NOT PROVIDED。所有示範數據均在附錄及事實粒度替換清冊中標記；本件不得當作協會既有實績、正式核准紀錄或評核結果。



---

## 1. 執行摘要、決策範疇與官方佐證要求對應

### 1.1 文件性質、決策問題與目標讀者
本候選分析報告供原始點協會訓練行政人員及未來經正式授權之決策者參考。是否設有特定委員會、權責單位或現行調查流程，資料未提供，狀態為 UNKNOWN。報告聚焦以下三項設計問題：
1. **機制健全度問題**：本會如何建立一套兼具「系統面（規範、工具、資料治理）」與「流程面（規劃、發放、回收、檢核、分析、回饋改善）」之滿意度調查機制，以符合勞動部勞動力發展署 TTQS（人才發展品質管理系統）訓練機構版之指標要求？
2. **群體區隔與分析嚴謹度問題**：如何確保「參訓學員」與「目標客戶（派訓單位主管／委託機構聯絡人）」在調查工具、分析口徑及決策回饋上嚴格分軌，避免以單一混合滿意度混淆不同利害關係人之真實評價？
3. **因果防線與品質控制問題**：如何界定滿意度（反應層次）與訓後成效之因果界線，並建立調查回收率、有效率、異常退件與小樣本保護之作業控制標準？

本報告直接回答「建立目標客戶及學員滿意度調查機制（系統及流程面）」的分析需要，以雙對象工具、系統控制、端到端流程、分群計算及改善追蹤作為主線；本件仍是供審議的提案與方法示範，不代表協會已採納或執行。讀者可由本章定位表直接找到各項內容、頁次及限制。

**候選使用時點（非現行規定）**：學員工具建議於最後一堂及課程評量結束後、離場前，由非授課人員提供 5–10 分鐘自願填答；目標客戶工具建議於結訓後 5 個工作日內送達，至第 3 個工作日可中立提醒一次。時點、窗口及提醒次數均待有權者核定；此建議不證明協會現行作法。

### 1.2 官方來源與要求定位
依本次核對之《TTQS 查核佐證文件資料表—訓練機構版》來源檔第 6 頁，原文記載：

* **指標項目**：`18. 訓練系統的一般性功能─目標客戶及學員的評價`
* **評分級距內涵（1分）**：`目標客戶及學員認為訓練有部分效果，然而未有具體紀錄及評量。`（此為官方級距文字，本報告不代替評核者判分。）
* **1分常見參考佐證資料**：`建立目標客戶及學員滿意度調查機制（系統及流程面）。`
* **審查頁次**：官方佐證表第 6 頁（檢核狀態：`PDF_TEXT_EXACT_PAGE_MATCH`）。
* **官方來源檔 SHA-256**：805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709；第 6 頁精確擷取本 SHA-256：e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02。官方下載頁：https://ttqs.wda.gov.tw/ttqs/menu_010_02.php?type_id=5。
* **交付代碼與分件定位**：本報告對應內部交付編號 `DOCX 0095`（檢核代碼 `I18-E02`），本件專注於「機制建立之系統與流程分析」，絕不與相鄰之口述訪談紀錄（`0094 / I18-E01`）或感謝函（`0096 / I18-E03`）混淆或相互取代。

### 1.3 機制設計摘要與候選建議
本報告提出一套待審議的機制設計，並以班次 `SYN-TRN-01` 的 SAMPLE／SYNTHETIC 數據示範計算。下列內容是設計建議及示範觀察，不是協會決議或現行制度成果：
1. **分群設計建議**：學員與目標客戶的題目與解讀面向不同，候選工具分別列示；若經採用，應分開核算並呈現，避免合併數字掩蓋差異。
2. **滿意度與成效分開解讀**：問卷分數呈現受訪者的主觀評價，不能單獨證明技能提升或組織績效改變；任何後續技能評量均須另列資料來源、分母、限制與因果界線。本報告的合成追蹤分數只示範計算，不構成協會成效證據。
3. **候選控制設計**：本文提出中立收集、有效性檢核、小樣本抑制及後續改善等控制選項，目的在於降低資料處理風險。這些控制尚未證明已採用，也不能保證完全防止偏誤或竄改；適用規則須由有權者審議。

#### 官方評核級距與本候選證據強度界線（不代替評分）

下表引用勞動部勞動力發展署《TTQS 人才發展品質管理評核表—訓練機構版》第 4 頁指標 18。它是評分依據；§1.2 的查核佐證資料表則是 I18-E02 檢核框來源，兩份官方文件用途不同。評分表來源 SHA-256：9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684；第 4 頁精確擷取本 SHA-256：c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf。官方下載頁：https://ttqs.wda.gov.tw/ttqs/menu_010_02.php?type_id=4。

| 官方級距 | 指標 18 評分標準原文 |
| :--- | :--- |
| 1 分 | 目標客戶及學員認為訓練有部分效果，然而未有具體紀錄及評量。 |
| 2 分 | 目標客戶及學員認為訓練有達成能力提升的效果。 |
| 3 分 | 目標客戶及學員認為訓練有績效改善的效果。 |
| 4 分 | 目標客戶及學員認為訓練有顯著具體績效。 |

**來源對應聲明（級距與缺口階梯之單一依據）**：上表 1 分至 4 分四個級距的原文，連同其下「由未評定進入可審查的 1 分級距」「由 1 分到 2 分」「由 2 分到 3 分」「由 3 分到 4 分」四段缺口階梯措辭，均對應至本節緊接上方之官方指標 18 評分級距表，即《TTQS 人才發展品質管理評核表—訓練機構版》第 4 頁指標 18「訓練系統的一般性功能─目標客戶及學員的評價」（該頁來源 SHA-256：9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684；精確第 4 頁擷取本 SHA-256：c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf）。四個級距文字為逐字引用，與官方來源擷取本一致；缺口階梯之說明文字屬本候選之分析與補證規劃，非官方文字。本件不對應任何官方分數，亦不代替評核者判分。

**本候選目前不對應任何官方分數**：本文只有待審議機制設計及 SAMPLE／SYNTHETIC 示範，沒有可核實的協會採納、實際調查、能力評量或績效紀錄；所以不能推定 0 分，也不能宣稱 1 分。以下是供補證規劃的候選缺口，不取代評核委員判分：

- **由未評定進入可審查的 1 分級距**：先取得有權使用的真實調查／紀錄，能追溯受訪對象、問題、期間及填答；目前該等資料均 UNKNOWN。
- **由 1 分到 2 分**：除可核實的學員與目標客戶回饋外，補上實際能力評量、前後測或其他可追溯學習資料，顯示能力提升；單靠滿意度不能支持。
- **由 2 分到 3 分**：補上能力提升連結到工作或組織績效改善的實際紀錄，明列期間、指標、基準及限制；不得把訓後滿意度直接當成因果證明。
- **由 3 分到 4 分**：補上足以核實「顯著具體績效」的量化前後資料、來源原件與歸因限制；若無法排除替代解釋，維持未能判定。4 分為本表最高級距。

本表只解釋官方級距與目前證據缺口，不對原始點協會評分、不代替評核者意見，也不把候選稿轉成 REAL 證據。

### 1.4 官方要求—候選結果—證據頁次—覆核追溯表

**官方來源：指標 18「訓練系統的一般性功能─目標客戶及學員的評價」；本交付件依 Unique Blueprint 指派對應 I18-E02 檢核框「建立目標客戶及學員滿意度調查機制（系統及流程面）」，不表示官方佐證表只有此一佐證項目。正式來源頁次為第 6 頁，逐字內容與 SHA-256 見 §1.2；評分級距另見 §1.3。**

| 官方指標 18／I18-E02 覆核面向 | 候選結果 | 文件證據定位（章節 → PDF頁次，逐項對應） | 覆核方式及證據界線 | 候選狀態 |
| :--- | :--- | :--- | :--- | :--- |
| **指標18／I18-E02：調查機制系統面** | 提出兩類對象的量表、資料字典、計算口徑、存取及版本控制建議。 | §2.1–§2.4 → PDF pp.5–6<br>§3.1–§3.2 → PDF pp.6–9<br>§4.1 → pp.10–13；§4.2 → pp.13–17；§4.3 → pp.17–19<br>§5.1 → p.20；§5.2 → p.21 | 核對工具、欄位、分母及公式；均為候選設計，不證明已採用。 | PROPOSED |
| **指標18／I18-E02：端到端作業流程面** | 展開需求界定、對象篩選、告知、發放、回收、檢核、分群分析、審閱及追蹤。 | §2.1–§2.4 → PDF pp.5–6<br>§3.1 → p.6；§3.2 → pp.7–9<br>§8.1–§8.5 → pp.34–37 | 核對流程輸入、控制點、輸出及暫緩／退回條件；實際執行 UNKNOWN。 | PROPOSED |
| **指標18／I18-E02：目標客戶與學員分軌評價** | 提供 Tool-A、Tool-B、完整 SAMPLE／SYNTHETIC 明細及分群計算。 | §4.1 → pp.10–13；§4.2 → pp.13–17；§4.3 → pp.17–19<br>§6.1–§6.4 → pp.23–29<br>§7.1 → p.30；§7.2 → pp.30–33（附圖 A → pp.32–33） | 分別檢查兩種問卷、分母、均分與正向率；不得合併取代分群結果。 | SYNTHETIC |
| **指標18／I18-E02：結果判讀與持續改善** | 說明限制、證據強度、候選改善建議、責任欄位及後續核驗方式。 | §6.3.3 → PDF p.27；§6.4 → pp.28–29；§6.4.1 → p.29<br>§7.3–§7.4 → PDF p.33<br>§8 → PDF pp.34–37<br>§9.5 → PDF pp.38–41<br>§10 → PDF pp.41–44 | 核對合成值、限制與替換清冊；無真實核定、實施或效果證據。 | PROPOSED／SYNTHETIC |

頁次錨點說明：本表頁次已依最終 44 頁 R11 Word 匯出逐項核對；章節錨點為主要定位，PDF exact SHA 與視覺檢查範圍記於外部 QA 收據。若正文或版面再變更，必須重新核頁，不得沿用舊版頁碼。

## 2. 目標客戶及學員滿意度調查系統架構與端到端作業流程

### 2.1 系統架構理念：系統面與流程面之解構
本候選設計把「滿意度調查機制」分為系統面與流程面；以下是供原始點協會審議的建議內容，不代表現況。
* **系統面（候選設計）**：可包括經核定的問卷版本、題項與量尺說明、欄位字典、計算規則、資料存取與版本控制。協會是否已有相同規範、名冊或系統，資料未提供，狀態 UNKNOWN。
* **流程面（候選設計）**：可涵蓋對象界定、邀請、告知、回收、有效性檢核、分群計算、結果審閱、改善建議及後續核驗。實際權責、制度發布及執行紀錄均未提供；本文不表示已成立委員會、CAPA 或檔案管理流程。

### 2.2 端到端十階段生命週期總覽
如經協會權責者審議採用，候選流程可依下列十階段運作；各階段的輸入、控制與產出須在正式採用時確認：

```
【階段一：年度/課程規劃】
  │ 依訓練計畫界定各班次目標客戶與學員範疇
  ▼
【階段二：調查對象名冊界定】
  │ 匯出受訓學員名單及委訓/派訓單位窗口名冊（建立母體與預計邀請數）
  ▼
【階段三：問卷工具核定與編號】
  │ 依課程屬性套用標準量表，核發唯一追蹤編號與填答說明
  ▼
【階段四：知情同意與中立發放】
  │ 候選時點：學員結課與評量後離場前自願填答；客戶於結訓後 5 個工作日內回覆（詳 §1.1）
  ▼
【階段五：獨立回收與盲樣編碼】
  │ 授課講師與行政承辦迴避，由中立收集人封裝回收並進行去識別化編碼
  ▼
【階段六：有效性檢核與資料清理】
  │ 依廢卷標準檢驗漏填與邏輯矛盾，剔除無效卷並確認有效分母
  ▼
【階段七：分群統計與報告產出】
  │ 依標準公式進行學員與目標客戶分軌統計，產出分析圖表與警示清單
  ▼
【階段八：決策審議與改善立案】
  │ 提請經核實之授權者審閱結果；是否提出改善建議及由誰負責，須另行核定
  ▼
【階段九：改善驗證與結案追蹤】
  │ 於次期課程或追蹤期查核改善措施落實度，未達標則重啟檢討
  ▼
【階段十：稽核歸檔與存取控制】
  │ 原始問卷、清理清冊、統計報表與會議紀錄依序歸檔，設定調閱權限
```

### 2.3 流程架構圖與異常迴圈控制

建議流程以資料完整性與授權為控制門。以下為候選流程示意，不代表目前已啟用的系統或已發生的處置：

```text
[授權與調查範圍確認] -> [分群界定] -> [工具及告知內容核定]
             -> [自願填答與中立回收] -> [有效性檢核]
                 | 資料完整且來源可追溯       | 缺同意、分母不明、題項無法判讀
                 v                              v
          [分群計算與限制說明]             [暫緩分析／補正或排除並留痕]
                 -> [授權者審閱並記錄決定]
                    | 有具體待改善事項
                    v
               [提出改善建議與責任／期限（待核定）]
                    -> [後續資料取得後驗證；缺資料則維持待追蹤]
```

不得依單一未核定百分比自動宣稱不合格或已啟動 CAPA。任何內部門檻須先由有權者審議並留存正式依據；本報告未取得此類決定。

### 2.4 制度化機制與現狀之分際

> **制度設計與現況界線**  
> 本章流程與工具是供審議的候選設計。現有制度是否已發布、是否已建置相同系統或是否曾執行調查，均無可核實來源，故標記 UNKNOWN／NOT PROVIDED；本文不推論其已存在或不存在。採用前應由協會有權者確認權責、適用範圍、資料告知、工具版本及保存方式。

## 3. 作業職能分工、權責分離與階段控制點規範

### 3.1 職責分離（Segregation of Duties, SoD）設計矩陣

角色均為候選職能名稱，非已核定職位或現有人員指派。若規模限制無法分工，須由有權者記錄替代控制；不得將未確認的外部第三方或委員會寫成既有安排。

| 候選職能 | 代碼 | 建議責任 | 控制邊界 |
| :--- | :--- | :--- | :--- |
| 調查協調 | ROLE-CRD | 界定對象與時點、備妥核定版工具、整理邀請分母 | 不代替受訪者填答，不修改原始分數 |
| 中立收集 | ROLE-COL | 說明自願參與、提供不受講師影響的填答方式、記錄發放與回收數 | 不要求正向評分，不檢視個別答案或施壓 |
| 資料檢核與分析 | ROLE-ANL | 依規則檢核、去識別化、登錄、分群計算與記錄限制 | 不補填缺漏、不把 N/A 當零、不合併群體掩蓋差異 |
| 授權審議 | ROLE-DEC | 由正式授權者審閱結果、記錄決定及改善責任 | 實際人員／組織及授權依據未提供；未核定前不宣稱決議或 CAPA 已成立 |

### 3.2 流程作業標準表（SOP）與控制點

以下為候選作業表，需經正式採用並依實際職責、工具及資料規範調整。所有存放欄位均只示意資料種類，不代表本會現行路徑或系統。

| 步驟 | 輸入 | 候選操作與控制 | 產出 | 暫緩／退回條件 |
| :--- | :--- | :--- | :--- | :--- |
| P-01 界定母體 | 經核實的課程／對象資料 | 分別界定學員及目標客戶，記錄納入與排除口徑 | 邀請分母與來源註記 | 對象、來源或邀請分母不明則暫緩 |
| P-02 核定工具 | 問卷樣張、資料欄位字典 | 核對題目中立、量尺、告知文字、版本及必要欄位 | 核定版本與發放紀錄欄位 | 未經授權核定或告知內容不清則不得發放 |
| P-03 邀請與填答 | 核定工具及對象清冊 | 由中立角色說明自願填答、用途及退出方式；避免講師或承辦人影響作答 | 邀請／回收紀錄 | 無法確保自願或收集角色可能施壓時暫停 |
| P-04 回收 | 填答表單、已送達邀請名冊與回收方式 | 將邀請發送、實際送達、截止時未回應及實際收回分開登錄；未回應僅記於邀請／送達名冊。實際收回每份表單只計一次 POP_RETURNED，後續狀態另列 | 邀請／送達名冊與回收清冊 | 送達狀態不明時不列入 POP_INVITED；回收數與記錄不一致先查明，不逕行計算 |
| P-05 有效性檢核 | 實際收回表單、候選處理狀態及採用後核定規則 | 先分列撤回、待補正、無效、有效；未回應不屬表單狀態。只將符合事前核定規則之有效件納入 POP_VALID；補正後狀態變更保留軌跡且不重複計份 | 回收處理狀態及有效性檢核清冊 | 規則未核定、處置理由缺失、變更無軌跡或原始值被覆寫則退回 |
| P-06 登錄與核對 | 可追溯之有效原始資料 | 保留來源列與登錄值；對不一致逐筆核對原件並留下更正軌跡 | 可重算資料表 | 分母、題碼或更正來源不清則暫緩分析 |
| P-07 分群分析 | 核對後資料及公式字典 | 分開計算學員與目標客戶；標明 N/A、缺漏及樣本限制 | 分群分析表 | 公式、分母或樣本抑制規則不一致則重算 |
| P-08 審閱與決定 | 分析稿及限制說明 | 由經核實的授權者記錄接受、退回、補件或改善建議 | 審閱／決策紀錄 | 權限來源不明時只列候選建議，不寫成核定決議 |
| P-09 後續驗證 | 已核定的改善事項及後續資料 | 依核定的責任與時點比較可比資料，保留未完成狀態 | 追蹤結果或待辦記錄 | 沒有後續資料時維持 UNKNOWN／待追蹤 |
| P-10 保管與版本 | 核定工具、資料與適用規範 | 由正式管理者設定存取、保存及銷毀規則；依核定版本控管 | 版本與調閱記錄 | 現行位置、期限或權限未確認前不宣稱已建置 |



**回收狀態與計數界線（候選設計，非本會現行政策；正式採用前待有權者核定）**：邀請／送達名冊分開記錄發出、可核實送達及截止時未回應；`POP_INVITED` 僅計可核實已送達／交付的對象。未回應沒有問卷表單，不列為 `POP_RETURNED`，也不推定原因或評價。實際收回的每份問卷只計一次 `POP_RETURNED`；其回收後狀態互斥標示為「撤回」「待補正之未完成」「無效」或「有效」。只有依事前核定規則判定有效者進入 `POP_VALID` 與題項分母；補正後更改狀態須保留原狀態及變更軌跡，不重複計份。撤回後個別回答的留存／移除方式、補正期限及採用規則仍待授權核定，現況為 UNKNOWN。

建議資料路徑如需設計，應在正式採用後由授權管理者確定；本候選不提供協會現行檔案位置。

## 4. 候選調查工具樣張與實務規範（雙軌量表）

本提案附兩套可供審議的候選問卷樣張，分別面向參訓學員及目標客戶。建議學員於最後一堂與評量結束後、離場前由非授課人員提供 5–10 分鐘自願填答；目標客戶問卷建議於結訓後 5 個工作日內送達，至第 3 個工作日可中立提醒一次。採用前須由有權者核定題目、告知內容、施測時點及回收方式；本文不證明現行機制已採用。量表方向與中立性須於試用前再次檢查。

### 4.1 候選工具一：學員滿意度調查問卷（Learner Survey, Tool-A）

```
========================================================================================
【表單代號：SURVEY-TOOL-A-L】
志工服務溝通與紀錄練習 課程學員滿意度調查表
（SAMPLE／SYNTHETIC 候選樣張；非已施測之協會問卷）
========================================================================================

【填答前知情同意與隱私宣告】
親愛的填答者您好：
以下課程名稱、班次與日期均為 SAMPLE／SYNTHETIC 示範，不代表真實辦訓。
本候選樣張供審議使用；若經授權採用，發放前須核定調查目的、使用範圍、
資料處理與聯絡方式，並向填答者清楚說明。
參與應為自願；拒答或中途退出不應影響受訓權益。請依實際經驗作答。
本文件沒有提供已核定的協會告知文本或真實調查紀錄。

【本表欄位分區說明】
（一）示範值（SAMPLE／SYNTHETIC）：僅供樣張呈現，非真實紀錄，
      不得視為已核定、已核准或已施測。
（二）REAL 空白欄位：每份表單各自填寫；本樣張一律留白，未填入任何真實值。
（三）管理者專用欄位：由收集人於回收後填寫，填答者不得填寫。

【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】
下列「示範班次代號」為 SAMPLE／SYNTHETIC 合成值，僅供樣張識別使用，
不是已核定或已核准之班次，不得作為正式紀錄引用。

班次編號（REAL，空白欄位；正式施測時由收集人填列已核定之班次代號）：
[                              ]
示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）：
SYN-TRN-01
培訓日期（REAL，空白欄位；正式施測時填寫，格式 YYYY-MM-DD）：
[                              ]
示範培訓日期（SAMPLE／SYNTHETIC 合成值；非實際辦訓日期）：
2026-07-11
學員流水編號（由收集人黏貼）：[          ]
實際填答日期（REAL，空白欄位；每份表單各自填寫，格式 YYYY-MM-DD）：
[                              ]
（填答說明：示範值與 REAL 欄位分列，不互相取代；本樣張刻意留白所有 REAL 欄位。
正式施測時，「實際填答日期」由填答者當場填寫，或由收集人依發放當日填寫；
不得回填示範日期，亦不得由管理者代填為擬定日期。）

----------------------------------------------------------------------------------------
【第一部分：核心滿意度評估題項】
請針對下列各項內容，於最適當之評分欄位打「V」。
評分標準：[5]=非常滿意 [4]=滿意 [3]=普通/尚可 [2]=不滿意 [1]=非常不滿意 [N/A]=不適用
（填答防護提示：本部分 5 題核心題項為有效問卷判定之必要條件，請勿遺漏）
【跨頁填答提示】本頁為前置說明；L-01 至 L-05 題項矩陣及 Q-06、Q-07 意見欄接續於下一頁。兩頁須成套填寫與回收。

題號  評估構面與題目文字                             [5]   [4]   [3]   [2]   [1]  [N/A]
----------------------------------------------------------------------------------------
L-01 【任務關聯性】
     本次課程內容能切合志工服務日常實務之溝通需求。   ( )   ( )   ( )   ( )   ( )   ( )
L-02 【目標與引導】
     課程學習目標與講師各單元之解說指引清晰易懂。     ( )   ( )   ( )   ( )   ( )   ( )
L-03 【演練價值性】
     課程安排之溝通演練與紀錄操作對技能熟練有幫助。   ( )   ( )   ( )   ( )   ( )   ( )
L-04 【講師支持度】
     講師及助教在課堂中能充分提供互動支持與回饋。     ( )   ( )   ( )   ( )   ( )   ( )
L-05 【整體滿意度】
     綜合考量整體教學設計，我對本次課程品質感到滿意。 ( )   ( )   ( )   ( )   ( )   ( )
----------------------------------------------------------------------------------------

【第二部分：質性意見與改進建議（自由填寫）】
Q-06 您認為本次課程中，哪一個教學環節對您的日常實務助益最大？
     答：_______________________________________________________________________________
     續寫：_____________________________________________________________________________

Q-07 為提升後續辦訓品質，您認為本課程最需要檢討或加強之處為何？
     答：_______________________________________________________________________________
     續寫：_____________________________________________________________________________

----------------------------------------------------------------------------------------
【管理者專用：資格核對與完整性判定欄位】
（由收集人於回收後填寫；填答者不得填寫本欄）
本欄位為候選表單設計建議，不是本會現行作業政策；本文件未載明協會既有之
資格核對或回收判定程序，相關規則狀態為 UNKNOWN。有效性判定規則以本文件
§5.1 適用之規則為準；本表不另訂門檻。

受評者是否實際參與本次課程（資格核對）：[ ] 是　[ ] 否
資格核對依據（管理者註記）：[                              ]
填答完整性核對：[ ] 五項核心題項（L-01～L-05）全部作答　[ ] 有缺漏題項
缺漏題項代號（如有）：[                              ]
回收後表單處理狀態（單選；僅適用於實際收回之表單）：
未回應（NONRESPONSE）沒有單一問卷表單，請依 §3.2 登錄於邀請／送達名冊；不得在本欄選填，亦不得視為負面評價。
[ ] 撤回（WITHDRAWN）：填答者主動撤回，已停止使用其作答。
[ ] 待補正之未完成（INCOMPLETE_PENDING_CORRECTION）：已作答但有缺漏，待補正。
[ ] 無效（INVALID）：不符合有效性規則者，依 §5.1 規則認定。
[ ] 有效（VALID）：符合有效性規則，納入分母計算。
（上述四類為互斥之單選分類；補正期限由採行者另行核定，本件未設定期限。）
判定備註（管理者）：[                              ]
管理者簽核（若經授權）：[                              ]
（計數界線：未回應只在邀請／送達名冊登錄，不列為 POP_RETURNED。已實際收回的表單，不論後續撤回、待補正或判為無效，均只計一次 POP_RETURNED；上述三種狀態不納入 POP_VALID 或題項分母，僅依 §5.1 規則判定為有效的表單納入 §6 計算。更正後狀態變更須留有軌跡，不重複計份。個別回覆資料之留存／移除方式待正式授權核定；目前狀態 UNKNOWN。）

========================================================================================
感謝您的回饋。若經正式採用，請依已核定的中立回收方式交回；本樣張不指定或宣稱協會已有實際回收箱或收集人。
========================================================================================
```

### 4.2 候選工具二：目標客戶聯絡窗口滿意度調查問卷（Target-Customer Survey, Tool-B）

```
========================================================================================
【表單代號：SURVEY-TOOL-B-C】
志工服務溝通與紀錄練習 目標客戶（派訓單位聯絡人）滿意度調查表
（SAMPLE／SYNTHETIC 候選樣張；非已施測之協會問卷）
========================================================================================

【填答前知情同意與隱私宣告】
致目標客戶填答者：
以下課程名稱與班次均為 SAMPLE／SYNTHETIC 示範，不代表曾有委託或開課。
本候選樣張供審議使用；若經授權採用，邀請前應核實對象、調查目的、使用範圍、
資料處理與回收方式，並清楚說明自願參與及退出方式。
是否已有相關機制、委託關係或專責部門，資料未提供，均為 UNKNOWN。

【本表欄位分區說明】
（一）示範值（SAMPLE／SYNTHETIC）：僅供樣張呈現，非真實紀錄，
      不得視為已委託、已核准或已施測。
（二）REAL 空白欄位：每份表單各自填寫；本樣張一律留白，未填入任何真實值。
（三）管理者專用欄位：由收集人於回收後填寫，填答者不得填寫。

【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】
下列「示範班次代號」為 SAMPLE／SYNTHETIC 合成值，僅供樣張識別使用，
不是已核定或已核准之班次，不得作為正式紀錄引用。

目標客戶／聯絡窗口代碼（REAL，空白欄位；由核實後的實際流程填列）：
[                              ]
示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）：
SYN-TRN-01
填答人角色（單選）：
[ ] 派訓主管　[ ] 培訓聯絡人　[ ] 其他（請註明）：[          ]
資格核對（由管理者或邀請單位填寫；填答者不得填寫）：
本填答人是否為貴單位之指定目標客戶聯絡窗口或經授權代表：[ ] 是　[ ] 否　[ ] 待核
提供評價之工作接觸（可複選；不以本人參訓為必要）：[ ] 課前需求／行政溝通　[ ] 訓後追蹤／回饋　[ ] 其他：[          ]
資格核對依據（管理者註記）：[                              ]
邀請發送日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ]
送達日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ]
示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11
實際填答日期（REAL，空白欄位；每份表單各自填寫；格式 YYYY-MM-DD）：[          ]
回收日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ]
（填答說明：邀請發送、送達、填答、回收四個時點分開記錄，俾對應 §1.1、§2.2 之
候選流程時點控制（該時限設定屬候選內容，非本會現行實務紀錄）。
本樣張尚未施測，亦不代表曾有委託或開課；上述四個 REAL 日期欄位於採用後由
各該流程之執行人分別填寫，本版未填入任何真實日期，實際值一律 UNKNOWN；
示範填答日期不得填入 REAL 欄位，亦不得回填示範班次代號。）

----------------------------------------------------------------------------------------
【第一部分：目標客戶專屬滿意度評估題項】
請針對下列辦訓合作各構面，勾選最符合 貴單位感受之評等。
評分標準：[5]=非常滿意 [4]=滿意 [3]=普通/尚可 [2]=不滿意 [1]=非常不滿意 [N/A]=不適用
【跨頁填答提示】本頁為前置說明；C-01 至 C-05 題項矩陣及 Q-06 意見欄接續於下一頁。兩頁須成套填寫與回收。

題號  評估構面與題目文字                             [5]   [4]   [3]   [2]   [1]  [N/A]
----------------------------------------------------------------------------------------
C-01 【目標需求契合】
     本次培訓規劃與 貴單位所提出之志工服務需求目標契合。( )   ( )   ( )   ( )   ( )   ( )
C-02 【辦訓安排明晰】
     本會在課前籌備、行政溝通與課務通知流程清楚明確。   ( )   ( )   ( )   ( )   ( )   ( )
C-03 【實作演練價值】
     課程設計之演練與實作環節符合 貴單位對工作技能之預期。( )   ( )   ( )   ( )   ( )   ( )
C-04 【訓後溝通追蹤】
     本會於訓後所提供之溝通協調與出缺勤反饋及時且具體。 ( )   ( )   ( )   ( )   ( )   ( )
C-05 【整體滿意度】
     綜合整體辦訓服務與合作體驗，貴單位對本會整體表現滿意。( )   ( )   ( )   ( )   ( )   ( )
----------------------------------------------------------------------------------------

【第二部分：委託單位專屬回饋（選填）】
Q-06 貴單位未來指派或委辦同類型志工訓練時，最希望本會增強何種專業支援？
     答：_______________________________________________________________________________
     續寫：_____________________________________________________________________________

----------------------------------------------------------------------------------------
【管理者專用：資格核對與完整性判定欄位】
（由收集人於回收後填寫；填答者不得填寫本欄）
本欄位為候選表單設計建議，不是本會現行作業政策；本文件未載明協會既有之
資格核對或回收判定程序，相關規則狀態為 UNKNOWN。有效性判定規則以本文件
§5.1 適用之規則為準；本表不另訂門檻。

填答完整性核對：[ ] 五項題項（C-01～C-05）全部作答　[ ] 有缺漏題項
缺漏題項代號（如有）：[                              ]
回收後表單處理狀態（單選；僅適用於實際收回之表單）：
未回應（NONRESPONSE）沒有單一問卷表單，請依 §3.2 登錄於邀請／送達名冊；不得在本欄選填，亦不得視為負面評價。
[ ] 撤回（WITHDRAWN）：填答者主動撤回，已停止使用其作答。
[ ] 待補正之未完成（INCOMPLETE_PENDING_CORRECTION）：已作答但有缺漏，待補正。
[ ] 無效（INVALID）：不符合有效性規則者，依 §5.1 規則認定。
[ ] 有效（VALID）：符合有效性規則，納入分母計算。
（上述四類為互斥之單選分類；補正期限由採行者另行核定，本件未設定期限。）
判定備註（管理者）：[                              ]
管理者簽核（若經授權）：[                              ]
（計數界線：未回應只在邀請／送達名冊登錄，不列為 POP_RETURNED。已實際收回的表單，不論後續撤回、待補正或判為無效，均只計一次 POP_RETURNED；上述三種狀態不納入 POP_VALID 或題項分母，僅依 §5.1 規則判定為有效的表單納入 §6 計算。更正後狀態變更須留有軌跡，不重複計份。個別回覆資料之留存／移除方式待正式授權核定；目前狀態 UNKNOWN。）

========================================================================================
如經採用，依正式核定的中立回收方式交回；本候選未指定或宣稱協會已有任何實際回收通道。
========================================================================================
```

### 4.3 量表欄位對映、防偏誤設計與不適用（N/A）防護處理

| 表單題號 | 分析資料庫欄位名稱 | 構面中文定義 | 計分方向 | 量尺區間 | 正向判定規則 | 題項中立性檢核（Anti-bias Verification） |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **L-01** | `LEARN_RELEVANCE` | 實務任務關聯性 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 避免「本課程極具實用性」等誇飾引導詞；平鋪直述陳述需求切合度。 |
| **L-02** | `LEARN_CLARITY` | 目標與引導清晰度 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 聚焦於客觀認知之清晰度，不使用讚美講師個人魅力之情緒性詞彙。 |
| **L-03** | `LEARN_PRACTICE` | 實作演練實用價值 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 檢視演練環節是否實用，無預設成效達成之壓迫性字眼。 |
| **L-04** | `LEARN_SUPPORT` | 講師互動與輔導支持 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 著重於「互動支持機制」，非主觀人氣打分。 |
| **L-05** | `LEARN_OVERALL` | 學員整體綜合滿意度 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 整體檢驗核心題；空白使全卷無效，N/A依下方規則處理。 |
| **C-01** | `CUST_GOAL_FIT` | 組織培訓目標契合度 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 檢核規劃與派訓需求之一致性，供機構客戶客觀衡量合約交付。 |
| **C-02** | `CUST_ARRANGE` | 行政與辦訓溝通明晰 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 針對前期作業與課務行政流程進行評量，切分教學與行政責任。 |
| **C-03** | `CUST_PRACTICE` | 演練環節符合組織預期 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 評估實務演練是否貼近派訓單位實際志工服務情境。 |
| **C-04** | `CUST_COMM_CLAR` | 訓後聯繫與回饋明確度 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 評量訓後續階溝通與配合度，確保服務延伸性。 |
| **C-05** | `CUST_OVERALL` | 目標客戶整體滿意度 | 正向計分（分高益善） | 1～5 分 | 4～5 分為正向 | 整體檢驗核心題；空白使全卷無效，N/A依下方規則處理。 |

**N/A（不適用）防護機制**：  
如工具與統計規則經核定允許選填 `N/A`，該份答卷該題不列入該題平均與分母；N/A 不視為 0 分。這是候選計算規則，並非已建置的系統功能。

**兩套問卷的核心題有效性規則**：Tool-A 的 L-01 至 L-05、Tool-B 的 C-01 至 C-05 均須有明確作答；任何核心題空白即判該份問卷無效。N/A 是明確選項而非空白，可依核定口徑保留為有效問卷，但該題須標示 N/A 並從該題分母剔除；若整體題 L-05／C-05 為 N/A，仍不得以其他題分數替代整體滿意度。

---

### 5. 資料字典、計算公式與統計口徑規範｜5.1 母體、樣本與資料欄位字典


為求統計口徑嚴密且完全重現，所有滿意度調查及後續追蹤指標均嚴格定義分母與分子邊界：

| 欄位名稱代碼 | 指標名稱 | 統計母數／分母界定（Denominator） | 分子界定（Numerator） | 資料來源表單 | 納入排除條件與資料限制說明 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **POP_ELIGIBLE** | 符合條件之對象母體 | 依事前核定納入條件界定的學員或目標客戶。 | 實際納入母體的人數；不等同已送達邀請數。 | 核實後的課程／客戶名冊及納入排除紀錄 | 條件或名冊不明則暫緩；不得自行排除。 |
| **POP_INVITED** | 已送達／交付邀請數 | 實際收到或已交付邀請的對象數（本公式的回收率分母）。 | 已送達或交付之邀請數；如送達狀態不明，分開記錄發出與送達數。 | 邀請發放／送達紀錄（如正式採用） | 無法核實實際邀請數時，回收率不得計算；不以名冊母體代替。 |
| **POP_RETURNED** | 問卷回收總份數 | 已送達邀請數。 | 截止時實際收回之紙本或數位問卷份數。 | 經核定方式產生的邀請／回收紀錄 | 未回覆原因如未取得來源，維持 UNKNOWN；不得推測為拒絕或某種滿意程度。 |
| **POP_VALID** | 有效問卷總份數 | 回收份數（`POP_RETURNED`）。 | 符合預先核定有效規則之問卷數。 | 有效性檢核紀錄（如正式採用） | 缺漏或矛盾的處置依預先核定規則；無規則或無可核對來源時暫緩，不補填答案。 |
| **MISSING_ITEM** | 題項缺漏值 | 依核定工具應填答之題項數。 | 漏填或劃記不清而無法辨識的題數。 | 有效性檢核紀錄（如正式採用） | 核心題缺漏的處置應依事先核定的有效規則；不得補造答案。 |
| **NA_TREATMENT** | 不適用題項標記 | 該題實際回答人數。 | 勾選 `N/A` 的人數。 | 原始回答表（若正式採用） | 僅在工具及統計規則核定後使用；N/A 不視為 0 分。 |
| **POS_RATING** | 正向評價回答數 | 該題有效作答人數。 | 若核定採用此口徑，評分 4 或 5 的有效作答數。 | 原始回答表（若正式採用） | 1～3 分不列正向；此為候選定義，正式使用前需核定量尺。 |
| **EVAL_FOLLOWUP** | 可評估配對追蹤人數 | 在指定時點具有可核對前、後測的對象數。 | 完成符合預先核定條件之配對評量人數。 | 追蹤評量表及原始分數來源 | 未配對、失聯或未提供者不補零；配對條件不清則不得計算變化率。 |
| **SUB_SUPPRESS** | 小樣本抑制門檻 | 分群統計之各次分類樣本數。 | 若次分群有效樣本數 $n < 5$，不呈現可識別的細分結果；僅註記樣本不足，不發布細分百分比、平均或個別值。 | 分群分析表（若正式採用） | $n < 5$ 時建議抑制細分百分比、平均、次數分布及個別值；門檻需依正式授權與資料風險核定。 |



**回收／有效狀態之候選計數口徑（與 §3.2、§4.1、§4.2 一致；非本會現行政策）**：`POP_RETURNED` 為截止前實際收回之表單數，每份只計一次，不因後續狀態改變而重複計數；「撤回」「待補正之未完成」「無效」均不計入 `POP_VALID` 或題項分析分母，只有依事前核定規則判定「有效」的表單納入。未回應須記於邀請／送達名冊，沒有表單，不列為 `POP_RETURNED`。補正與狀態更改須留軌跡；本候選未設定補正期限，亦未主張協會已有任何現行處置規則。

### 5.2 核心指標之數學公式庫（Explicit & Reproducible Formulae）

#### 1. 問卷回收率（Returned Rate, $R_{\text{ret}}$）
$$R_{\text{ret}} = \frac{\text{回收問卷總份數 } (N_{\text{returned}})}{\text{已送達／交付邀請數 } (N_{\text{invited}})} \times 100\%$$
*口徑說明：表示實際回收份數相對於邀請數的比例；不能單獨解讀為配合程度或代表性。*

#### 2. 回收有效率（Validity Rate among Returned, $R_{\text{val}}$）
$$R_{\text{val}} = \frac{\text{有效問卷總份數 } (N_{\text{valid}})}{\text{實際回收問卷總份數 } (N_{\text{returned}})} \times 100\%$$
*口徑說明：描述回收問卷中符合預先核定有效規則的比例；此比例本身不能證明題目或填答說明的品質。*

#### 3. 題項滿意度平均數（Mean Score, $\bar{X}_j$）
$$\bar{X}_j = \frac{\sum_{i=1}^{N_{\text{valid}, j}} X_{ij}}{N_{\text{valid}, j}}$$
*式中 $X_{ij}$ 代表第 $i$ 位有效填答者在第 $j$ 個題項之得分（1～5分）；$N_{\text{valid}, j}$ 為排除該題填寫 `N/A` 後之有效填答人數。四捨五入計算至小數點後第二位。*

#### 4. 滿意度正向率（Positive Response Rate, $P_j$）
$$P_j = \frac{N_{\text{positive}, j} \ (X_{ij} \in \{4, 5\})}{N_{\text{valid}, j}} \times 100\%$$
*式中分子為評等為 4 分或 5 分之有效人數。四捨五入計算至小數點後第一位。*

#### 5. 訓後成果達成率（Follow-up Outcome Rate, $R_{\text{outcome}}$）
$$R_{\text{outcome}} = \frac{\text{符合成果門檻之人數 } (N_{\text{pass}})}{\text{實際可評估之追蹤人數 } (N_{\text{evaluable}})} \times 100\%$$
*口徑說明：僅能以完成追蹤實作評量之有效配對樣本人數為分母。未受測者不得設為 0 分納入，亦不得假設其未達標。*

#### 6. 成效相對變化率（Relative Change Rate, $\Delta_{\text{rel}}$）與絕對差距（Absolute Difference, $\Delta_{\text{abs}}$）
$$\Delta_{\text{abs}} = \bar{Y}_{\text{post}} - \bar{Y}_{\text{pre}} = \frac{\sum Y_{\text{post}}}{N_{\text{paired}}} - \frac{\sum Y_{\text{pre}}}{N_{\text{paired}}}$$
$$\Delta_{\text{rel}} = \frac{\bar{Y}_{\text{post}} - \bar{Y}_{\text{pre}}}{\bar{Y}_{\text{pre}}} \times 100\% = \frac{\sum Y_{\text{post}} - \sum Y_{\text{pre}}}{\sum Y_{\text{pre}}} \times 100\%$$
*防護警示（N/A Guard）：若前測基準均分 $\bar{Y}_{\text{pre}} = 0$，相對變化率無數學意義，系統輸出為 `N/A`，嚴禁標註為無窮大或虛構百分比。*

**統一精度與四捨五入規則**：先保留完整原始分子、分母及未四捨五入中間值，再依下列位數呈現；採一般四捨五入，禁止以已四捨五入的中間值再計算。R_ret、R_val、R_outcome、正向率及 Δ_rel 以百分比表示時四捨五入至小數點後 1 位；題項平均數及 Δ_abs 四捨五入至小數點後 2 位。任何公式分母為 0 或資料不足時輸出 N/A，並明列可計算樣本數；不得以 0 代替缺值。

---

## 6. 合成示範案例完整數據展示與逐步計算驗證

本章採用本寫作任務提供的 SAMPLE／SYNTHETIC 數據，示範資料流轉、驗證與計算。此案例未經官方或協會核定，也不代表實際運作；各示範事實對應文末事實粒度替換清冊。

* **示範班次案號**：`SYN-TRN-01`（SAMPLE／SYNTHETIC，來源為本件寫作任務資料包）
* **示範課程名稱**：志工服務溝通與紀錄練習（SAMPLE / SYNTHETIC）
* **課程教學時數**：6 小時
* **課程辦理日期**：2026年07月11日（示範日期）
* **追蹤測評日期**：2026年08月10日（訓後30日示範追蹤）

### 6.1 學員滿意度調查原始資料列（Learner Survey Raw Data）
本 SAMPLE／SYNTHETIC 案例將 18 設為已送達或交付的邀請數，以符合欄位字典 POP_INVITED 的分母定義；單純發出但送達狀態不明的數量未提供，故不另列。回收 15 份，另 3 人未回覆；未回覆原因未提供。15 份回收中有 1 份因整體滿意度核心題缺漏而無效，因此有效問卷為 14 份。缺漏表的其他題目值與個別識別碼未提供，不臆造或展示；下表僅列 14 份提供的有效評分：

| 填答索引代碼 | 任務關聯性<br>(Relevance) | 目標引導清晰<br>(Clarity) | 演練操作價值<br>(Practice) | 講師支持度<br>(Support) | 整體滿意度<br>(Overall) | 判定狀態 |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **SYN-L01** | 5 | 4 | 5 | 5 | 5 | 有效納入 |
| **SYN-L02** | 5 | 4 | 4 | 4 | 5 | 有效納入 |
| **SYN-L03** | 4 | 5 | 4 | 4 | 4 | 有效納入 |
| **SYN-L04** | 3 | 4 | 3 | 4 | 4 | 有效納入 |
| **SYN-L05** | 5 | 5 | 4 | 5 | 5 | 有效納入 |
| **SYN-L06** | 4 | 4 | 4 | 3 | 4 | 有效納入 |
| **SYN-L07** | 4 | 3 | 4 | 4 | 4 | 有效納入 |
| **SYN-L08** | 5 | 5 | 5 | 4 | 5 | 有效納入 |
| **SYN-L09** | 4 | 4 | 3 | 4 | 4 | 有效納入 |
| **SYN-L10** | 4 | 3 | 4 | 3 | 4 | 有效納入 |
| **SYN-L11** | 3 | 4 | 3 | 4 | 3 | 有效納入 |
| **SYN-L12** | 5 | 4 | 5 | 5 | 5 | 有效納入 |
| **SYN-L13** | 4 | 4 | 4 | 4 | 4 | 有效納入 |
| **SYN-L14** | 2 | 3 | 3 | 3 | 2 | 有效納入 |

### 6.2 目標客戶滿意度調查原始資料列（Target-Customer Raw Data）
目標客戶聯絡對象的合成邀請數為 6，回收 5 份，另 1 人未回覆；未回覆原因、機構名稱及填答者真實角色未提供。5 份均有效。下表以合成代碼表示，不代表任何真實第三方組織或人員：

| 填答索引代碼 | 目標需求契合<br>(Goal Fit) | 辦訓安排明晰<br>(Arrangement) | 實作演練價值<br>(Practice) | 訓後溝通追蹤<br>(Follow-up) | 整體滿意度<br>(Overall) | 判定狀態 |
| :--- | :---: | :---: | :---: | :---: | :---: | :--- |
| **SYN-C01** | 5 | 5 | 4 | 5 | 5 | 有效納入 |
| **SYN-C02** | 4 | 4 | 4 | 4 | 4 | 有效納入 |
| **SYN-C03** | 5 | 4 | 5 | 5 | 5 | 有效納入 |
| **SYN-C04** | 3 | 3 | 3 | 3 | 3 | 有效納入 |
| **SYN-C05** | 4 | 4 | 4 | 4 | 4 | 有效納入 |

### 6.3 逐步計算推導歷程（Step-by-Step Explicit Arithmetic）

#### 6.3.1 學員端滿意度指標計算推導
1. **問卷回收率**：
   $$R_{\text{ret, Learner}} = \frac{15}{18} = 83.333\% \longrightarrow \mathbf{83.3\%}$$
2. **回收有效率**：
   $$R_{\text{val, Learner}} = \frac{14}{15} = 93.333\% \longrightarrow \mathbf{93.3\%}$$
3. **任務關聯性（Relevance）**：
   * 總分總和：$5+5+4+3+5+4+4+5+4+4+3+5+4+2 = 57$
   * 平均分數：$\bar{X} = \frac{57}{14} = 4.0714 \longrightarrow \mathbf{4.07}$ 分（滿分 5.00）
   * 正向評分個數（4～5分）：共 11 人（SYN-L01, L02, L03, L05, L06, L07, L08, L09, L10, L12, L13）
   * 正向率：$P = \frac{11}{14} = 78.571\% \longrightarrow \mathbf{78.6\%}$
4. **目標引導清晰度（Clarity）**：
   * 總分總和：$4+4+5+4+5+4+3+5+4+3+4+4+4+3 = 56$
   * 平均分數：$\bar{X} = \frac{56}{14} = 4.0000 \longrightarrow \mathbf{4.00}$ 分
   * 正向評分個數（4～5分）：共 11 人（SYN-L01, L02, L03, L04, L05, L06, L08, L09, L11, L12, L13）
   * 正向率：$P = \frac{11}{14} = 78.571\% \longrightarrow \mathbf{78.6\%}$
5. **演練操作價值（Practice）**：
   * 總分總和：$5+4+4+3+4+4+4+5+3+4+3+5+4+3 = 55$
   * 平均分數：$\bar{X} = \frac{55}{14} = 3.9285 \longrightarrow \mathbf{3.93}$ 分
   * 正向評分個數（4～5分）：共 10 人（SYN-L01, L02, L03, L05, L06, L07, L08, L10, L12, L13）
   * 正向率：$P = \frac{10}{14} = 71.428\% \longrightarrow \mathbf{71.4\%}$
6. **講師支持度（Support）**：
   * 總分總和：$5+4+4+4+5+3+4+4+4+3+4+5+4+3 = 56$
   * 平均分數：$\bar{X} = \frac{56}{14} = 4.0000 \longrightarrow \mathbf{4.00}$ 分
   * 正向評分個數（4～5分）：共 11 人（SYN-L01, L02, L03, L04, L05, L07, L08, L09, L11, L12, L13）
   * 正向率：$P = \frac{11}{14} = 78.571\% \longrightarrow \mathbf{78.6\%}$
7. **整體滿意度（Overall）**：
   * 總分總和：$5+5+4+4+5+4+4+5+4+4+3+5+4+2 = 58$
   * 平均分數：$\bar{X} = \frac{58}{14} = 4.1428 \longrightarrow \mathbf{4.14}$ 分
   * 正向評分個數（4～5分）：共 12 人（SYN-L01～L10, L12, L13）
   * 正向率：$P = \frac{12}{14} = 85.714\% \longrightarrow \mathbf{85.7\%}$

#### 6.3.2 目標客戶端滿意度指標計算推導
1. **問卷回收與有效率**：
   $$R_{\text{ret, Customer}} = \frac{5}{6} = 83.333\% \longrightarrow \mathbf{83.3\%}$$
   $$R_{\text{val, Customer}} = \frac{5}{5} = \mathbf{100.0\%}$$

另列有效回收占邀請數：$5/6=83.3\%$；此數為邀請母體中的有效份數比例，不是回收有效率。
2. **目標需求契合（Goal Fit）**：
   * 總分總和：$5+4+5+3+4 = 21$
   * 平均分數：$\bar{X} = \frac{21}{5} = 4.2000 \longrightarrow \mathbf{4.20}$ 分
   * 正向評分個數：共 4 人（SYN-C01, C02, C03, C05）
   * 正向率：$P = \frac{4}{5} = 80.000\% \longrightarrow \mathbf{80.0\%}$
3. **辦訓安排明晰（Arrangement Clarity）**：
   * 總分總和：$5+4+4+3+4 = 20$
   * 平均分數：$\bar{X} = \frac{20}{5} = 4.0000 \longrightarrow \mathbf{4.00}$ 分
   * 正向評分個數：共 4 人；正向率：$P = \frac{4}{5} = \mathbf{80.0\%}$
4. **實作演練價值（Practice Value）**：
   * 總分總和：$4+4+5+3+4 = 20$
   * 平均分數：$\bar{X} = \frac{20}{5} = 4.0000 \longrightarrow \mathbf{4.00}$ 分
   * 正向評分個數：共 4 人；正向率：$P = \frac{4}{5} = \mathbf{80.0\%}$
5. **訓後溝通追蹤（Follow-up Clarity）**：
   * 總分總和：$5+4+5+3+4 = 21$
   * 平均分數：$\bar{X} = \frac{21}{5} = 4.2000 \longrightarrow \mathbf{4.20}$ 分
   * 正向評分個數：共 4 人；正向率：$P = \frac{4}{5} = \mathbf{80.0\%}$
6. **整體滿意度（Overall）**：
   * 總分總和：$5+4+5+3+4 = 21$
   * 平均分數：$\bar{X} = \frac{21}{5} = 4.2000 \longrightarrow \mathbf{4.20}$ 分
   * 正向評分個數：共 4 人；正向率：$P = \frac{4}{5} = \mathbf{80.0\%}$

#### 6.3.3 分軌呈現限制（不合併推論）

> 學員與目標客戶的對象、問卷題意及構面不同。本報告分別列示兩群的送達、回收、有效份數、均分與正向率；不得將分群結果加總成合併滿意度或正向率，也不得跨群比較高低。如需行政核對總件數，須保留兩群各自的分母並分項列出，合計數不得作成效指標。

---

### 6.4 補充追蹤案例：30日實務演練成效檢核（Supplementary Skill Check）
為示範滿意度調查（反應層次）如何與後續學習評估銜接，本案例引入一組 30 天實務紀錄操作評量（0～10分量規）。本評量為**補充性 SAMPLE／SYNTHETIC 衍生範例**，其測驗分數絕非滿意度評分，亦不得宣稱為訓練之必然因果實績。表內「7 分」只是假設示例的判讀規則，不是原始點協會已核定的合格門檻；實際採用須由有權者另行核定量尺與標準。

* **受測對象**：14 位有效學員中，共 12 位學員具備完整之前測與 30 日後追蹤測評配對資料（SYN-L01 至 SYN-L12）。
* **追蹤遺漏處理**：提供的合成資料指出 14 位有效學員中有 12 組完整配對分數，另 2 組追蹤值不可得；不可得原因及前測分數未提供，故不臆造。缺值不以 0 分填補，亦不納入配對統計分母。

| 學員代碼 | 訓前實務測評基準 (Before, 0-10) | 訓後30日實務評量 (30-day, 0-10) | 個別分數差異值 ($\Delta = \text{Post} - \text{Pre}$) | 達標判定 ($\ge 7$ 分) |
| :--- | :---: | :---: | :---: | :--- |
| **SYN-L01** | 4 | 7 | +3 | 達標 |
| **SYN-L02** | 5 | 8 | +3 | 達標 |
| **SYN-L03** | 6 | 8 | +2 | 達標 |
| **SYN-L04** | 3 | 6 | +3 | 未達標 (6分) |
| **SYN-L05** | 4 | 7 | +3 | 達標 |
| **SYN-L06** | 5 | 8 | +3 | 達標 |
| **SYN-L07** | 6 | 8 | +2 | 達標 |
| **SYN-L08** | 2 | 5 | +3 | 未達標 (5分) |
| **SYN-L09** | 4 | 7 | +3 | 達標 |
| **SYN-L10** | 5 | 8 | +3 | 達標 |
| **SYN-L11** | 3 | 6 | +3 | 未達標 (6分) |
| **SYN-L12** | 4 | 7 | +3 | 達標 |

#### 6.4.1 配對成效指標推導歷程

**配對母數核對：**14 位有效學員 = 12 位有完整前後測配對資料 + 2 位追蹤值不可得；後 2 位不納入配對成效分母，也不視為未達標。
1. **訓前平均分數（Baseline Mean, $\bar{Y}_{\text{pre}}$）**：
   $$\sum Y_{\text{pre}} = 4+5+6+3+4+5+6+2+4+5+3+4 = 51$$
   $$\bar{Y}_{\text{pre}} = \frac{51}{12} = 4.2500 \longrightarrow \mathbf{4.25} \text{ 分}$$
2. **訓後30日平均分數（Post Mean, $\bar{Y}_{\text{post}}$）**：
   $$\sum Y_{\text{post}} = 7+8+8+6+7+8+8+5+7+8+6+7 = 85$$
   $$\bar{Y}_{\text{post}} = \frac{85}{12} = 7.0833 \longrightarrow \mathbf{7.08} \text{ 分}$$
3. **平均絕對變化量（Absolute Mean Difference, $\Delta_{\text{abs}}$）**：
   $$\Delta_{\text{abs}} = \bar{Y}_{\text{post}} - \bar{Y}_{\text{pre}} = 7.0833 - 4.2500 = \frac{85 - 51}{12} = \frac{34}{12} = 2.8333 \longrightarrow \mathbf{2.83} \text{ 分}$$
4. **相對描述性變化率（Relative Descriptive Change, $\Delta_{\text{rel}}$）**：
   $$\Delta_{\text{rel}} = \frac{85 - 51}{51} = \frac{34}{51} = 0.6666... \times 100\% \longrightarrow \mathbf{66.7\%}$$
   *(防護檢核：基準值 51 不為 0，故算式有效可解)*
5. **成果門檻達成率（Outcome Achievement Rate, $\ge 7$ 分）**：
   $$\text{達標人數 } (N_{\ge 7}) = 9 \text{ 人} \quad (\text{未達標者：L04 為 6分, L08 為 5分, L11 為 6分})$$
   $$R_{\text{outcome}} = \frac{9}{12} = 75.000\% \longrightarrow \mathbf{75.0\%}$$

---

## 7. 分群分析、品質限制與因果界線闡明

### 7.1 分群報告核心原則：雙軌矩陣對照
依據 TTQS 指標要求，調查報告必須分別凸顯「學員」與「目標客戶」之滿意度輪廓。兩者在認知重點與敏感度上展現顯著落差：

```
【滿意度指標分群比較矩陣】

評估構面維度        學員端 (Learner, n=14)          目標客戶端 (Customer, n=5)
──────────────────────────────────────────────────────────────────────────
核心關注焦點        課程實用度、講師引導、演練體驗    需求契合度、行政協調、後續追蹤
正向率最高項目      整體滿意度 (85.7%)              五項並列 4/5＝80.0%（無相對最高項目）
正向率最低項目      實作演練價值 (71.4%)            五項並列 4/5＝80.0%（無相對最低項目）
平均得分最高項目    整體滿意度 (4.14分)             目標需求契合 (4.20分)、溝通追蹤 (4.20分)、整體滿意度 (4.20分)
平均得分最低項目    實作演練價值 (3.93分)           辦訓安排 (4.00分)、實作演練 (4.00分)
──────────────────────────────────────────────────────────────────────────
```


### 7.2 視覺化就緒表格：指標差距與優先改善排序矩陣

下表只按提供的合成數據描述各群體，不套用未經核定的內部門檻，也不推論成因。

【群內排序規則（可重現）】
(1) 排序範圍限於同一群體內，學員端與目標客戶端分別計算，不合併、不加權、不跨群比較序位。
(2) 先以正向率由低到高排序。
(3) 正向率相同者，再以平均分由低到高排序。
(4) 正向率與平均分皆相同者，並列同一序位；序位採不跳號之密集計法（P1、P2、P3…）。
(5) 差距之比較基準取各群體「組內最高項目」，僅作描述性對照，不是核定的合格門檻、門檻值或績效目標。
(6) 「正向」係指評分 4 或 5（口徑見 §5.1）。

【學員端（Learner，有效 n=14）】
比較基準（組內最高項目）：L-05 整體滿意度，正向率 85.7%、平均 4.14 分。

| 序位 | 題號／構面 | 有效 N | 正向人數／有效 N | 正向率 | 平均分 | 與組內基準之正向率差距（百分點） | 與組內基準之平均分差距（分） | 描述性觀察 |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| P1 | L-03 演練操作價值 | 14 | 10/14 | 71.4% | 3.93 | 14.3 | 0.21 | 本群體正向率與平均分皆最低；原因 UNKNOWN |
| P2 | L-02 目標引導清晰 | 14 | 11/14 | 78.6% | 4.00 | 7.1 | 0.14 | 與 L-04 正向率與平均分並列（同序位） |
| P2 | L-04 講師支持度 | 14 | 11/14 | 78.6% | 4.00 | 7.1 | 0.14 | 與 L-02 正向率與平均分並列（同序位） |
| P3 | L-01 任務關聯性 | 14 | 11/14 | 78.6% | 4.07 | 7.1 | 0.07 | 正向率與 L-02／L-04 相同，僅平均分較高 |
| P4 | L-05 整體滿意度 | 14 | 12/14 | 85.7% | 4.14 | 0.0 | 0.00 | 本群體比較基準（組內最高項目） |

【目標客戶端（Customer，有效 n=5）】
比較基準（組內最高項目）：C-01 目標需求契合、C-04 訓後溝通追蹤、C-05 整體滿意度，正向率 80.0%、平均 4.20 分（三項並列）。

| 序位 | 題號／構面 | 有效 N | 正向人數／有效 N | 正向率 | 平均分 | 與組內基準之正向率差距（百分點） | 與組內基準之平均分差距（分） | 描述性觀察 |
| :--- | :--- | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| P1 | C-02 辦訓安排明晰 | 5 | 4/5 | 80.0% | 4.00 | 0.0 | 0.20 | 與 C-03 平均分並列最低；正向率與其餘各項相同 |
| P1 | C-03 實作演練價值 | 5 | 4/5 | 80.0% | 4.00 | 0.0 | 0.20 | 與 C-02 平均分並列最低；正向率與其餘各項相同 |
| P2 | C-01 目標需求契合 | 5 | 4/5 | 80.0% | 4.20 | 0.0 | 0.00 | 與 C-04、C-05 並列為組內最高項目（比較基準） |
| P2 | C-04 訓後溝通追蹤 | 5 | 4/5 | 80.0% | 4.20 | 0.0 | 0.00 | 與 C-01、C-05 並列為組內最高項目（比較基準） |
| P2 | C-05 整體滿意度 | 5 | 4/5 | 80.0% | 4.20 | 0.0 | 0.00 | 與 C-01、C-04 並列為組內最高項目（比較基準） |

【目標客戶端序位之解讀界線】
五項構面正向率同為 4/5＝80.0%，彼此之正向率差距為 0 個百分點，故本群體之序位差異完全來自平均分（4.00 對 4.20，差距 0.20 分）。C-02、C-03 之並列最低平均分，僅屬本組描述性排序，不得解讀為該二項之滿意度較低、正向率較低或存在群體差異；亦不得據以認定任何構面之優劣或成因。

【低分回覆計數與敏感度註記（供改善議題之穩健性判讀）】
學員端（n=14；「正向」為 4 或 5 分）：
- L-03 演練操作價值：有效 n=14、正向 10 份，非正向 4 份。已識別者包括 1 份 2 分回覆（合成回覆 SYN-L14）與 2 份 3 分回覆（SYN-L04、SYN-L11），合計 3 份；另 1 份非正向回覆於本包件未逐筆識別。
- L-04 講師支持度：已識別 1 份 3 分回覆（SYN-L11）；其餘非正向回覆於本包件未逐筆識別。
- 情境演算（非重新施測結果）：若僅自 L-03 排除 SYN-L14 之 2 分回覆，L-03 之有效 n 為 13、總分 53、平均約 4.08、正向 10/13＝76.9%；與組內基準 L-05 之正向率差距由 14.3 個百分點收斂為 8.8 個百分點，平均分差距由 0.21 分收斂為 0.07 分。依 (2)(3) 之規則，L-03 仍為本群體 P1 序位。該演算僅顯示本差距對單一 2 分回覆具敏感度，不得據以推論成因、不得視為重新施測或重測結果、不得作為排除該回覆之依據。
目標客戶端（n=5）：每題各 1 份非正向回覆（5 份中 4 份為正向），其分數值於本包件未逐筆識別；n=5 意味單一填答者之評等即對應 20 個百分點之正向率差異，故本群體任何正向率數值之描述力有限。

讀表原則：學員組的演練價值分數在本組資料中相對較低，適合作為後續討論議題；資料沒有提供開放式回饋或原因證據，不能推定問題成因。目標客戶五個構面的正向人數比例相同，不能因此推論其意見一致或代表其他對象。

#### 7.2 附圖 A：圖表解讀—學員端／目標客戶端正向率分軌比較（SAMPLE／SYNTHETIC）

[[FIGURE:0095_R08_POSITIVE_RATE]]

圖 A 標題：學員端與目標客戶端各構面正向率比較（合成資料 SAMPLE／SYNTHETIC；雙面板、同一 0–100% 橫軸刻度）

圖 A 圖面內容（兩面板分軌呈現，不合併）：
- 左面板（學員端，n=14）：L-01 任務關聯性 78.6%、L-02 目標引導清晰 78.6%、L-03 演練操作價值 71.4%、L-04 講師支持度 78.6%、L-05 整體滿意度 85.7%。
- 右面板（目標客戶端，n=5）：C-01 目標需求契合 80.0%、C-02 辦訓安排明晰 80.0%、C-03 實作演練價值 80.0%、C-04 訓後溝通追蹤 80.0%、C-05 整體滿意度 80.0%。

圖 A 呈現規則：兩面板使用同一 0–100% 之橫軸刻度與同一比例基準；每個柱狀標註百分比與該面板之 n；兩軌以面板標題、位置與標註區分，不得僅以顏色作為區辨依據；不得於圖面加入門檻線、目標值或趨勢線。

圖 A 警示：學員端 n=14、目標客戶端 n=5，樣本數與母體不同，兩軌數值不得合併、不得加權、不得解讀為同一母體之整體滿意度，亦不得跨軌比較高低；目標客戶端五項同為 80.0%，圖面不得以柱高差異暗示其有高下之別。

圖 A 資料界限：圖面全部數值為 SAMPLE／SYNTHETIC 合成值，非真實施測結果，不代表任何已核定之門檻、門檻值或考核等第；本圖不得作為核可、績效認定、評比或改善成效之依據，詳見 §7.2 排序規則與敏感度註記。

圖 A 文字替代說明（alt text 草案，供整合端產出可存取圖表時使用）：合成資料之兩軌正向率柱狀比較圖，分為左右兩個面板且共用 0–100% 橫軸刻度。學員端（n=14）五項正向率介於 71.4%（L-03 演練操作價值）與 85.7%（L-05 整體滿意度），其餘 L-01、L-02、L-04 均為 78.6%。目標客戶端（n=5）C-01 至 C-05 五項正向率皆為 80.0%。兩群樣本數不同，未合併或加權計算；全部數值為合成示範資料。

### 7.3 調查品質限制與統計邊界分析

解讀本示範時須保留以下限制：

1. **小樣本限制**：學員有效樣本為 14、目標客戶有效樣本為 5。單一評分即可改變比例；結果僅描述提供的合成樣本，不推論至任何實際母體。
2. **未回覆原因未知**：學員與目標客戶各有未回覆者，但原因未提供。不得推測其冷漠、滿意或不滿意，也不得判定偏誤方向。
3. **次分群抑制**：若任何次分群有效樣本 $n<5$，不呈現該分群的百分比、平均、次數分布或個別值，只標示樣本不足。本文沒有提供進一步分群資料。
4. **追蹤子集限制**：配對技能評量只有 12 組，另 2 組不可得且原因未知。配對子集可能與其他對象不同，不得推論為全體表現。

### 7.4 因果歸因之嚴格防線（Causal Attribution Defense）

本報告將問卷評價與技能追蹤分開呈現。滿意度只反映提供的主觀評分；配對分數變化只描述 12 組合成觀察值。缺少真實來源、比較設計及其他影響因素資料時，不得稱為訓練造成的能力或組織績效改變，也不得將示範結果寫成協會實績。

## 8. 機制作業控制、資料治理與持續改善追蹤

### 8.1 驗收、暫緩與退件控制標準（提案作業參數）

以下是候選資料控制條件，不是 TTQS 官方分數線，也不是已核定的協會政策。

| 判定 | 可操作條件 | 處置與留痕 |
| :--- | :--- | :--- |
| 可計算 | DOCX 與 I18-E02 綁定正確；來源、對象與邀請分母可追溯；核心題有效值及 N/A 分別記錄；公式可重算 | 先由資料檢核者確認，再分群計算；保留原始來源與計算式 |
| 暫緩 | 授權或填答告知未核實；分母、題碼、回收數或更正來源不明；必要題漏填規則尚未核定；原始值互相矛盾 | 暫不對外形成結論；列出缺項、來源與補正責任 |
| 排除單份 | 核心題漏填、重複答案無法辨識或記錄經核定規則判為無效 | 記錄排除理由；不得補造答案；分母依事先核定的有效性定義重算 |
| 抑制次分群 | 有效樣本 $n<5$ | 不發布次分群百分比、平均、次數分布或個別值；標示樣本不足 |
| 不得升格 REAL | 沒有原始問卷、可核實日期、授權與實際結果等必要證據 | 維持 SAMPLE／SYNTHETIC 或 UNKNOWN；不得把候選提案寫成實績 |

正式使用前，須由有權者核定上述規則及其適用版本。

### 8.2 異常更正、稽核軌跡（Audit Trail）與版本控制

1. **保留原始值**：更正不得覆寫原始回答。記錄原值、修正值、原因、時間及執行者來源；若沒有可核對原件，維持 UNKNOWN 並暫緩。
2. **差異核對**：如使用雙人登錄，對所有不一致逐筆回查原始問卷，直到差異有記錄地解決；不以任意百分比門檻取代核對。
3. **版本管理**：表單標示候選版本及生效依據。正式採用、修訂或停用須由有權者核定並保留版本變更紀錄；不得因版本更新刪除受保護的歷史原始證據。

### 8.3 資料安全、隱私與保存期限待核實

本報告未取得協會現行資料保管位置、存取權限、加密狀態或保存期限，以上均為 UNKNOWN／NOT PROVIDED，不自行指定法定年限或聲稱已有伺服器、備份及保管人。

如經授權採用，應在收集前由正式管理者確認資料目的、最少必要欄位、可存取角色、傳輸及儲存方式、調閱紀錄、保存期限與銷毀程序，並核實適用規範。分析資料宜去識別化；身分對照表若確有必要，應與分析資料分開並限權存取。

### 8.4 持續改善行動追蹤流程與閉環驗證責任（PDCA）

提供的合成學員資料中，演練操作價值為本群體五項中相對較低的構面。資料沒有開放式意見、根因調查、會議或改善紀錄，因此原因與任何已核定行動均為 UNKNOWN。下表只提供可供審議的候選閉環流程；未取得資料授權、正式決定及後續可比資料前，不得宣稱已查明根因、已改課或改善完成。

**候選作業流程，非本會現行規則；實際角色、授權與時點待核定。** 表內角色碼只代表本文件的候選職能，不代表已任命人員。

| 階段／啟動條件 | 候選職能 | 必要操作與應留紀錄 | 暫緩／結案判準 |
| :--- | :--- | :--- | :--- |
| 1 資料核實｜僅於資料可追溯且授權者核准啟動；本次核准證據 UNKNOWN | ROLE-ANL（計算核對）<br>ROLE-CRD（分母與來源確認） | 依同版問卷重算本構面均分及正向率，核對題碼、分母、N/A與排除理由；留存來源、版本及計算式 | 來源、分母或版本不能追溯，或漏答規則未核定：維持 UNKNOWN 並暫緩；合成資料不得當作真實改善立案依據 |
| 2 根因查證｜第一階段可重算，且已核准資料用途與回饋方式 | ROLE-CRD（協調與中立收集）<br>ROLE-ANL（紀錄與分類） | 僅查核授權範圍內的課程設計、教材、教學紀錄及中立回饋；記錄來源、限制、候選原因與尚未排除的替代解釋，不追問個人分數 | 未授權、範圍不清或回饋有誘導：暫緩並標 UNKNOWN；替代解釋未查清前不得認定根因 |
| 3 方案比較｜根因有可追溯資料支持，並完成限制說明 | ROLE-ANL（證據與方案評估）<br>ROLE-CRD（資源及時程彙整） | 提出至少兩個可行方案，比較所需資源、對課程與學員的影響、風險及限制；保留依據與不採其他方案的理由 | 少於兩個可行方案，或比較缺少依據／資源資訊：暫緩送審並補件；不得自行選定方案 |
| 4 決定與指派｜方案比較完成，且決定權限來源已核實 | ROLE-DEC（審議與決定）<br>ROLE-CRD（後續協調） | 由核實的授權者記錄採用、退回或不採及理由、待辦職能與期限；姓名、職稱及日期只在取得真實核准紀錄後填入 | 權限或決定紀錄未核實：僅保留候選建議，維持待審／UNKNOWN；不得寫成協會決議或已執行事項 |
| 5 成效核驗與閉環｜已有核准行動，且取得可比的後續資料 | ROLE-ANL（重算與比對）<br>ROLE-DEC（核驗結案） | 依相同題項、量尺、有效規則及計算式，選取條件可比的對象重測；留存各期分母、未回覆與排除紀錄、限制及原始來源 | 無可比對象／資料或方法不一致：維持待追蹤／UNKNOWN，不得結案或宣稱已改善；不得將前後差異直接歸因課程效果 |

### 8.5 改善建議追蹤表（SAMPLE／SYNTHETIC）

下表是候選改善追蹤欄位示例，不代表真實立案、決議、責任指派或執行。日期與授權均未提供。本表依「可直接填寫」形式設計：合成觀察與改善建議屬候選內容；責任職能、負責人、期限與狀態拆為四個獨立欄位，於正式授權後由有權者逐欄填寫，本版一律保持空白或 UNKNOWN。

| 合成觀察 | 成因狀態 | 可供審議的改善建議 | 後續核驗方式 | 建議責任職能（待核定） | 建議負責人（待指派） | 預定期限（待核定） | 狀態（待核定） |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 學員演練操作價值：10/14 正向、平均 3.93/5；SAMPLE／SYNTHETIC | UNKNOWN；未提供開放式意見或根因證據 | 若經正式授權，可檢視練習說明、演練參與機會與課程安排，並記錄審議依據 | 核定後於可比課程使用同一題項，記錄正向率、平均分、有效 N 及回收有效率；若無後續資料則保持待追蹤，並說明量測範圍限制 | ＿＿＿＿＿＿<br>（候選職能代碼：ROLE-CRD／ROLE-ANL／ROLE-DEC，見 §3.1；實際指派未核定） | ＿＿＿＿＿＿<br>（姓名未提供；UNKNOWN，不得填入推定人選） | ＿＿＿＿＿＿<br>（YYYY-MM-DD；期限未定；UNKNOWN） | ＿＿＿＿＿＿<br>（未立案、未執行；待有權者核定） |

**欄位填寫規則（候選）**：①「建議責任職能」僅填候選職能代碼，未經核定不得視為已指派；②「建議負責人」在取得正式授權指派前保持空白，不得填入任何姓名或推定人選；③「預定期限」由有權者核定後以 YYYY-MM-DD 填寫，未定前保持空白且狀態為 UNKNOWN；④「狀態」僅可填候選值「未立案／追蹤中／待驗證／已完成（附證據）」，無可核實後續資料時不得填「已改善」。

**空白追蹤登錄表（每次立案或追蹤各填一列；欄位同上，本版未填入任何實際值）**

| 追蹤編號 | 合成觀察／現象 | 改善建議 | 責任職能 | 負責人 | 期限（YYYY-MM-DD） | 狀態 | 驗證日期 | 驗證結果與證據位置 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| TRK-＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ |
| TRK-＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ |
| TRK-＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ | ＿＿＿＿ |

本表之責任人選、期限、採納與否、立案狀態與改善結果，在取得有權者核定與後續可比資料前，一律為 UNKNOWN 或待核定；不得由本表推論協會已立案、已指派或已完成改善。

## 9. 相鄰文件與工作物差異

本節對照 I18-E02 與相鄰文件的官方文字及工作物差異，供確認本候選報告的專屬用途；不表示本件已獲 TTQS 評核通過。

### 9.1 四項相鄰文件之文類與職責對照表

| DOCX ID | 要求代碼 | 官方參考佐證文字 | 本報告與其界線 |
| :--- | :--- | :--- | :--- |
| 0093 | I17D-E07（內部索引；官方原頁未於本件核驗） | 未核驗的額外近鄰，不作本件官方需求引據。 | 僅作分件提醒；0095 不代替或複製其他文件內容。 |
| 0094 | I18-E01 | 口述目標客戶及學員認為訓練有其功能，僅有滿意度調查，但未有具體紀錄及評量。 | 口述紀錄與評量工具不同於本件系統及流程分析報告。 |
| 0095 | I18-E02 | 建立目標客戶及學員滿意度調查機制（系統及流程面）。 | 本件專屬於滿意度調查機制設計、流程、工具及分析口徑。 |
| 0096 | I18-E03 | 感謝函。 | 感謝函為另一獨立文件；其出具者及原件狀態須依實際來源核實，0095 不代製或取代。 |

以上區分只依正式要求文字及 Blueprint 的文件分工，不推定鄰近文件的真實內容、出具者或執行情況。

### 9.2 與 0093 I17D-E07 雇主調查表的差異

內部來源對照索引將 DOCX 0093／I17D-E07 列為相鄰工作物；本件未附其官方來源頁，故此處只作未核驗的額外分件提醒，不把該項文字當作正式需求證據。0095 則依 §1.2 所列 I18-E02 檢核框，提供候選系統設計與合成分析，兩者內容不互相替代。

### 9.3 與 0094 I18-E01 口述訪談紀錄的差異

I18-E01 對應的官方文字為口述目標客戶及學員認為訓練有其功能，但只有滿意度調查且缺少具體紀錄及評量。0095 則對應 I18-E02 的系統與流程機制。兩項各自成件；本報告不將訪談原話、訪談人或真實口述資料冒充為本件調查結果。

### 9.4 與 0096 I18-E03 感謝函的差異

I18-E03 的參考佐證文字為「感謝函」。其實際出具者、內容與原件狀態須由合法來源核實。0095 是候選機制分析報告，不得冒充、代製或填補 0096 的真實原件。

### 9.5 升格真實（REAL）所需外部佐證路徑與索引清單

本索引逐項對應 Unique Blueprint `real_data_required` 之升格類別（正式日期；真實人名／角色；核准／簽章；真實班次／課程；實際數字／比例；真實附件與檔案位置），並就本件之實際需求細分為 8 個可核對項目。每列均載明所需真實來源、可對應之事實粒度清冊鍵，以及本次取得狀態；目前清冊鍵以 `qa/0095_R11_synthetic_replacement_register.csv` 為準；R08 CSV／manifest 保留為歷史原件，不作為本版頁碼依據（R07 版清冊 `qa/0095_R07_synthetic_replacement_register.csv` 為歷史標的，維持不變）。

| # | 升格核實項目（對應 Blueprint real_data_required 類別） | 需要的真實來源 | 對應清冊鍵 | 本次狀態 |
| :--- | :--- | :--- | :--- | :--- |
| 1 | 真實作者與覆核者姓名／角色（真實人名／角色） | 協會編製者與正式覆核者之具名紀錄、職稱及授權依據 | UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY（R07 新增）；PROP-0095-ROLE-CRD、PROP-0095-ROLE-COL、PROP-0095-ROLE-ANL、PROP-0095-ROLE-DEC 僅為候選職能標籤，非人名 | 未提供；UNKNOWN |
| 2 | 核准／簽章原件（核准／簽章） | 有權核准者之核定文件、簽章或會議決議原件及其生效依據 | UNK-0095-UNK_APPROVAL_SIGNATURE（R07 新增）；UNK-0095-UNK_REAL_SYSTEM | 未提供；UNKNOWN |
| 3 | 正式／生效日期（正式日期） | 制度或工具之核定發布日、生效日，以及真實問卷之施測與回收日期 | UNK-0095-UNK_FORMAL_EFFECTIVE_DATE（R07 新增；本版 REAL 日期欄位留白，Tool-A／Tool-B REAL 空白日期欄位見 R11 PDF pp.11、15；本索引第 3 列見 R11 PDF p.38）；SYN-0095-COURSE_DATE、SYN-0095-FOLLOWUP_DATE 為合成日期 | 未提供；UNKNOWN |
| 4 | 真實班次／課程／期別（真實班次／課程） | 經核實之課程計畫、辦訓名冊、期別／班次識別與時數 | UNK-0095-UNK_REAL_COURSE_COHORT（R07 新增）；SYN-0095-CASE_ID、SYN-0095-COURSE_NAME、SYN-0095-COURSE_HOURS 為合成值 | 未提供；UNKNOWN |
| 5 | 實際合格／邀請／回收／有效份數與原始問卷（實際數字／比例） | 可核對之對象清冊、發放／送達紀錄、回收清冊、有效性判定紀錄與原始問卷（如存在且有權使用） | SYN-0095-LEARNER_INVITED、SYN-0095-LEARNER_RETURNED、SYN-0095-LEARNER_VALID、SYN-0095-CUSTOMER_INVITED、SYN-0095-CUSTOMER_RETURNED、SYN-0095-CUSTOMER_VALID、UNK-0095-UNK_NONRESPONSE_REASON、UNK-0095-UNK_INVALID_ID、UNK-0095-UNK_INVALID_OTHER_SCORES、UNK-0095-UNK_REAL_RESPONSES | 未提供；UNKNOWN |
| 6 | 實際計算與分析（實際數字／比例） | 與原始回答可追溯連結之資料表、公式、計算過程與分析覆核記錄 | L-01–L-05 與 C-01–C-05 各題 SUM／MEAN／POSN／POSRATE，共 40 個題項鍵；另有 5 個分軌分母／回收衍生鍵（SYN-0095-LEARNER_RETURN_RATE、LEARNER_VALID_RATE、CUSTOMER_RETURN_RATE、CUSTOMER_VALID_RATE、CUSTOMER_VALID_RETURN_SHARE）及 8 個訓後追蹤計算鍵。全清冊共 53 個 DERIVED_SYNTHETIC_METRIC 鍵，完整鍵名與值以 R11 CSV／manifest 為準；UNK-0095-UNK_REAL_RESPONSES | 未提供；UNKNOWN |
| 7 | 實際改善決定、責任、期限與後續追蹤 | 有權者之決定原件、責任指派、期限核定及後續可比資料 | UNK-0095-UNK_IMPROVEMENT_ORIGINALS（R07 新增）；UNK-0095-UNK_REAL_RESPONSES；§8.5 之責任／負責人／期限／狀態欄位現為空白 | 未提供；UNKNOWN |
| 8 | 真實附件與經授權之儲存／存取路徑（真實附件與檔案位置） | 由正式資料管理者核實之檔案位置、存取權限、調閱紀錄與保存規則 | UNK-0095-UNK_ATTACHMENT_STORAGE_LOCATION（R07 新增） | 未提供；UNKNOWN |

不得以本報告虛構路徑、組織名稱、人員或簽章替代上述原件；亦不得以上表任一列之 UNKNOWN 狀態推論該項目不存在或本會未曾辦理。必要來源未提供時，維持 UNKNOWN，不升格 REAL。本索引僅列示升格路徑與所需來源，不對原始點協會評分，亦不宣稱任何項目已取得。

R08 歷史版本補充說明（定位與完整性界線；不代表 R11 頁次）：
(1) 定位：UNK-0095-UNK_FORMAL_EFFECTIVE_DATE 之 document_location 已由「§4.2 Tool-B real response-date and return-date fields；PDF pp. 10–11, 32」更正為實際存在於本版表單之 REAL 空白日期欄位（§4.1 Tool-A「實際填答日期」；§4.2 Tool-B「邀請發送日期」「送達日期」「實際填答日期」「回收日期」），並以 §9.5 第 3 列對應之。該欄位皆為空白，本版未填入任何真實日期，不得聲稱已有既存日期值。
(2) 頁碼錨點：此段只記錄歷史 R08 CSV 的定位基礎；R08 列位置僅以 R08 匯出為準，不得表示已對照 R10 或 R11。R11 的列位置以新 R11 CSV、manifest 與最終 R11 Word 匯出 PDF 交叉核對。
(3) 完整性：R08 清冊共 211 筆資料列、13 欄與唯一 register_key。R06 原有 208 鍵，移除 3 個不再使用的合併／合併正向率鍵後保留 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，因此 208 − 3 + 6 = 211；205 = 208 − 3。R06、R07 歷史 CSV 與 manifest 均維持原件，不回溯改寫；本版實際位元組與鍵集合以隨附 manifest 為準。

## 10. 合成事實替換登錄表與文件版本

本報告所用 SAMPLE／SYNTHETIC 資料附有事實粒度 CSV。R08 register（211 筆、13 欄；CSV SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c；manifest SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0）為歷史原件，列位置綁定 43 頁 R08 匯出，未核對 R10／R11 頁次。R11 current register 為 qa/0095_R11_synthetic_replacement_register.csv（211 筆、13 欄；CSV SHA-256 df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee；manifest SHA-256 45357ed001e8720a129883924630e9d8125f9dc9e0a9f7fd1cefc2d774008c28）。R11 頁碼清冊已逐列依最終 44 頁 R11 PDF 校核；PDF exact SHA 見外部視覺 QA 收據；R08 原件與歷史鍵集合均不回溯改寫。R06 原有 208 個鍵，R08 移除 3 個合併／合併正向率衍生鍵並保留 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，合計 211 筆、13 欄。§6.3.3 分軌解讀學員與目標客戶；任一 CSV 或 manifest SHA 不符即停止使用並重新取得完整套件。清冊不含個人真實資料。

### 10.1 附件索引

| 附件 | 檔案或來源 | 用途與核對方式 |
| :--- | :--- | :--- |
| A | qa/0095_R08_synthetic_replacement_register.csv（歷史） | 211 筆、13 欄；CSV SHA-256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c（64 字元；R10 多出 1 個尾碼 a）；manifest SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0；綁定 43 頁 R08 PDF，列位置未對 R10/R11 核驗。 |
| A-1 | qa/0095_R08_synthetic_replacement_register_manifest.json | 列數、欄數、唯一鍵、歷史鍵集合與來源 SHA；SHA-256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0。 |
| A-2 | qa/0095_R07_synthetic_replacement_register.csv | R07 歷史標的（未回溯改寫）；214 筆、13 欄；SHA-256 `ba5e5e1c8f0191e7298502976e5f9d02a164d4e799a1de2a7f1514f66a7fc3d4`。 |
| A-3 | qa/0095_R07_synthetic_replacement_register_manifest.json | R07 歷史標的（未回溯改寫）；SHA-256 `7d90e5af2e2259c0a8e9ea4246ca3be848cd8c57cf68962e751be4d90a0cb01c`。 |
| A-4 | qa/0095_R11_synthetic_replacement_register.csv 與 manifest | 211 筆、13 欄；CSV SHA-256 df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee；manifest SHA-256 45357ed001e8720a129883924630e9d8125f9dc9e0a9f7fd1cefc2d774008c28；頁碼逐列依最終 44 頁 R11 Word 匯出核對，PDF exact SHA 記於外部視覺 QA 收據。 |
| B | TTQS 查核佐證文件資料表—訓練機構版，第 6 頁 | I18-E02 檢核框原文；SHA-256 見 §1.2，官方下載頁 type_id=5。 |
| C | TTQS 人才發展品質管理評核表—訓練機構版，第 4 頁 | 指標 18 的 1 至 4 分評分標準；SHA-256 見 §1.3，官方下載頁 type_id=4。 |
| D | 0095_R11_CANDIDATE.pdf | 本 DOCX 的同版 Word 匯出全文；PDF SHA-256 及頁數由外部 visual QA 收據綁定。 |
| E | 0095_R11 technical, visual and semantic review receipts | R10 歷史獨立語意審查：OpenCode CLI v2.0.32，requested route opencode/minimax-m3.1-flash-free；reported model ID minimax-m3.1-flash-free，provider model identity UNKNOWN；Reviewed DOCX SHA-256 4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630；結果 PARTIAL、0 blocking、5 nonblocking。R10 為 packet-only，未重算 DOCX、未渲染／目視；完整原始回覆及收據見套件。R11 的技術、視覺及獨立語意結論只以套件中綁定 R11 exact DOCX SHA 的收據為準；本附件索引不自行宣告 PASS。 |

### 10.2 文件版本與覆核紀錄

| 版本 | 日期 | 變更與審查狀態 |
| :--- | :--- | :--- |
| R05 | 2026-10-20 | OpenCode CLI v2 exact-SHA 語意審查結果為 PARTIAL，無 blocking finding；14 項低度／資訊性觀察已保留於 R05 原始審查回覆。該審查未做獨立視覺或 DOCX 位元組驗證；模型供應端身分 UNKNOWN。 |
| R06 | 2026-10-20 | 依 R05 具體 finding 修正官方級距與證據界線、來源雜湊、施測時點、核心題有效規則、計算精度、合併分母、客戶均分並列、附件索引及版本紀錄；候選狀態，新的 exact-SHA 覆核依本版套件收據記錄。 |
| R07 | 2026-10-20 | 依 R06 review 修正官方來源、公式／分母、REAL 日期欄、清冊索引及改善追蹤；修復跨頁版面。R07 exact-SHA 語意審查 PARTIAL、0 blocking、10 findings；原始回覆：review/0095_R07_opencode_minimax_R01_response.json。 |
| R08 | 2026-10-20 | 依 R07 finding 修正 REAL 空白欄位與清冊定位；§6.3.3 改為分軌、不合併推論，移除 3 項不再使用的合併計算；§8.4 增列候選 PDCA 五階段及暫緩／結案判準。R08 清冊 211 筆；保留 R06、R07 歷史原件。R08 exact-SHA 語意審查為 PARTIAL、無 blocking finding。 |
| R09 | 2026-10-20 | 依 R08 exact-SHA review PARTIAL 精確修正 §1.4 導引及合成班次文字；問卷、數據及 R08 register／manifest 不變。R08 NB-R08-02 經 R06／R08 鍵集合核對為誤判。R09 exact-SHA OpenCode review 為 PARTIAL、0 blocking、5 nonblocking；原始回覆及收據見外部套件。provider model identity UNKNOWN；本件仍為 CANDIDATE。 |
| R10 | 2026-10-20 | 依 R09 exact-SHA review 精確修正 §1.4 頁次、R06→R08 清冊算式及 §9.5 衍生鍵分類；R08 CSV／manifest、問卷及示範數值不變。R10 DOCX SHA-256 4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630；技術與視覺檢查完成，獨立語意審查 PARTIAL、0 blocking、5 nonblocking，provider model identity UNKNOWN；不升格正式接受。 |
| R11 | 2026-10-20 | 修正兩份官方來源的 parent PDF／精確頁擷取本 SHA 標示；更正 Appendix A 的 R08 CSV 64 字元 SHA；另以 R11 register 取代其作為 current page locator 清冊，R08 歷史原件不改寫；依 R10 finding 修正 §1.4／§9.5 頁碼鏈結。保留問卷、示範資料、計算與政策內容不變。R11 為候選；技術、視覺、獨立語意驗收以外部 exact-SHA 收據為準。 |
**歷史覆核標的**：R06 DOCX SHA `71398b1095d2987a1e0064657a1f6b942fe6f875697b5f99443fb9002e82efa4`；R07 SHA `ba6100f3aaeb547ad9d3f5ecfa1f30f563424fc368c28015efb00ff076cb9394`；R08 SHA `e9322191eb70554311f506db2eedf0800c1e786012a6b854cbe4b31864ce31a1`（OpenCode exact-SHA review PARTIAL、0 blocking、5 nonblocking；response `review/0095_R08_opencode_minimax_R01_response.json`，SHA `914a9d8f34186b5f7bbfec0d8c1183d81ff4435bf3adb2ddc0261f42e5189a89`）。R06–R08 原件及收據均維持不變；R09 exact-SHA 審查結果 PARTIAL、0 blocking、5 nonblocking，provider model identity UNKNOWN；R10 exact DOCX SHA-256 `4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630` 的 OpenCode CLI v2.0.32 語意審查為 PARTIAL、0 blocking、5 nonblocking，provider model identity UNKNOWN；R10 原始 response SHA-256 `6fe4399f240b92cd7f19e742376ebe46eb139dfe175c0ba0f0b6ba5da85f8ffd`；R11 結果以套件中綁定最終 R11 exact DOCX SHA 的原始回覆及收據為準。

本文件的協會編製者、正式覆核者、採用權責者及其簽署均未提供，狀態為 UNKNOWN；不得以工具路由或系統輸出冒充協會人員、正式核准或簽章。獨立語意審查結果應以外部套件中綁定本版 DOCX SHA 的原始回覆與收據為準，不得由本表替代。

> **報告總結說明與覆核聲明**

> **候選狀態與使用界線**  
> 本報告為 I18-E02 候選機制、問卷及 SAMPLE／SYNTHETIC 示例，不證明協會採納、實施或任何真實調查／評核。真實資料與授權須依原件核實；未提供者維持 UNKNOWN。本文為 CANDIDATE；審查僅對指定 DOCX exact SHA 有效，不代表協會核准或 TTQS 通過。

## Current Word-exported PDF text by page

### PDF page 1

候選分析報告  DOCX 0095  /  I18-E02     •     第 1 頁 
建立目標客戶及學員滿意度調查機制（系統及流程
面）分析報告 
文件狀態宣告 
本件為 DOCX 0095／I18-E02「建立目標客戶及學員滿意度調查機制（系統及流程面）」之候選分析
報告，包含一套供審議的機制設計與完整 SAMPLE／SYNTHETIC 示範。文內角色、程序、表單及控制
均屬提案；目前沒有來源證明原始點協會已採納、核准或執行本文制度。協會是否已有相關制度、實際
授權、課程、對象、調查和真實結果均為 UNKNOWN／NOT PROVIDED。所有示範數據均在附錄及
事實粒度替換清冊中標記；本件不得當作協會既有實績、正式核准紀錄或評核結果。 
 
1. 執行摘要、決策範疇與官方佐證要求對應 
1.1 文件性質、決策問題與目標讀者 
本候選分析報告供原始點協會訓練行政人員及未來經正式授權之決策者參考。是否設有特定委員會、權責
單位或現行調查流程，資料未提供，狀態為 UNKNOWN。報告聚焦以下三項設計問題： 
1. 機制健全度問題：本會如何建立一套兼具「系統面（規範、工具、資料治理）」與「流程面（規劃、發
放、回收、檢核、分析、回饋改善）」之滿意度調查機制，以符合勞動部勞動力發展署 TTQS（人才發展品
質管理系統）訓練機構版之指標要求？ 
2. 群體區隔與分析嚴謹度問題：如何確保「參訓學員」與「目標客戶（派訓單位主管／委託機構聯絡人）」
在調查工具、分析口徑及決策回饋上嚴格分軌，避免以單一混合滿意度混淆不同利害關係人之真實評價？ 
3. 因果防線與品質控制問題：如何界定滿意度（反應層次）與訓後成效之因果界線，並建立調查回收率、
有效率、異常退件與小樣本保護之作業控制標準？ 
本報告直接回答「建立目標客戶及學員滿意度調查機制（系統及流程面）」的分析需要，以雙對象工具、
系統控制、端到端流程、分群計算及改善追蹤作為主線；本件仍是供審議的提案與方法示範，不代表協會
已採納或執行。讀者可由本章定位表直接找到各項內容、頁次及限制。 
候選使用時點（非現行規定）：學員工具建議於最後一堂及課程評量結束後、離場前，由非授課人員提供 
5–10 分鐘自願填答；目標客戶工具建議於結訓後 5 個工作日內送達，至第 3 個工作日可中立提醒一次。時
點、窗口及提醒次數均待有權者核定；此建議不證明協會現行作法。 
1.2 官方來源與要求定位 
依本次核對之《TTQS 查核佐證文件資料表—訓練機構版》來源檔第 6 頁，原文記載： 
• 指標項目：18. 訓練系統的一般性功能─目標客戶及學員的評價

### PDF page 2

候選分析報告  DOCX 0095  /  I18-E02     •     第 2 頁 
• 評分級距內涵（1 分）：目標客戶及學員認為訓練有部分效果，然而未有具體紀錄及評量。（此為官方
級距文字，本報告不代替評核者判分。） 
• 1 分常見參考佐證資料：建立目標客戶及學員滿意度調查機制（系統及流程面）。 
• 審查頁次：官方佐證表第 6 頁（檢核狀態：PDF_TEXT_EXACT_PAGE_MATCH）。 
• 官方來源檔 SHA-256：
805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709；第 6 頁精確擷取
本 SHA-256：e0ecd2d7b1fd8c20e03b9e651083ee767ccaf3c4a6297f9cb0e7709d07620f02。官
方下載頁：https://ttqs.wda.gov.tw/ttqs/menu_010_02.php?type_id=5。 
• 交付代碼與分件定位：本報告對應內部交付編號 DOCX 0095（檢核代碼 I18-E02），本件專注於「機
制建立之系統與流程分析」，絕不與相鄰之口述訪談紀錄（0094 / I18-E01）或感謝函（0096 / 
I18-E03）混淆或相互取代。 
1.3 機制設計摘要與候選建議 
本報告提出一套待審議的機制設計，並以班次 SYN-TRN-01 的 SAMPLE／SYNTHETIC 數據示範計算。下列
內容是設計建議及示範觀察，不是協會決議或現行制度成果： 
1. 分群設計建議：學員與目標客戶的題目與解讀面向不同，候選工具分別列示；若經採用，應分開核算並
呈現，避免合併數字掩蓋差異。 
2. 滿意度與成效分開解讀：問卷分數呈現受訪者的主觀評價，不能單獨證明技能提升或組織績效改變；任
何後續技能評量均須另列資料來源、分母、限制與因果界線。本報告的合成追蹤分數只示範計算，不構成
協會成效證據。 
3. 候選控制設計：本文提出中立收集、有效性檢核、小樣本抑制及後續改善等控制選項，目的在於降低資
料處理風險。這些控制尚未證明已採用，也不能保證完全防止偏誤或竄改；適用規則須由有權者審議。 
官方評核級距與本候選證據強度界線（不代替評分） 
下表引用勞動部勞動力發展署《TTQS 人才發展品質管理評核表—訓練機構版》第 4 頁指標 18。它是評分
依據；§1.2 的查核佐證資料表則是 I18-E02 檢核框來源，兩份官方文件用途不同。評分表來源 SHA-256：
9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684；第 4 頁精確擷取本 
SHA-256：c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf。官方下載頁：
https://ttqs.wda.gov.tw/ttqs/menu_010_02.php?type_id=4。 
官方級距 指標 18 評分標準原文 
1 分 目標客戶及學員認為訓練有部分效果，然而未有具體紀錄及評量。 
2 分 目標客戶及學員認為訓練有達成能力提升的效果。 
3 分 目標客戶及學員認為訓練有績效改善的效果。 
4 分 目標客戶及學員認為訓練有顯著具體績效。

### PDF page 3

候選分析報告  DOCX 0095  /  I18-E02     •     第 3 頁 
來源對應聲明（級距與缺口階梯之單一依據）：上表 1 分至 4 分四個級距的原文，連同其下「由未評定進
入可審查的 1 分級距」「由 1 分到 2 分」「由 2 分到 3 分」「由 3 分到 4 分」四段缺口階梯措辭，均對應
至本節緊接上方之官方指標 18 評分級距表，即《TTQS 人才發展品質管理評核表—訓練機構版》第 4 頁指
標 18「訓練系統的一般性功能─目標客戶及學員的評價」（該頁來源 SHA-256：
9d253829410a505c77d8a59fa0203b4c052aa223e2c98d1d509c7c1a57083684；精確第 4 頁擷取本 
SHA-256：c789f8f0e48dd14286a76c88b168526c2a70fb4f022fe52180c034007988adcf）。四個級距
文字為逐字引用，與官方來源擷取本一致；缺口階梯之說明文字屬本候選之分析與補證規劃，非官方文字。
本件不對應任何官方分數，亦不代替評核者判分。 
本候選目前不對應任何官方分數：本文只有待審議機制設計及 SAMPLE／SYNTHETIC 示範，沒有可核實的
協會採納、實際調查、能力評量或績效紀錄；所以不能推定 0 分，也不能宣稱 1 分。以下是供補證規劃的
候選缺口，不取代評核委員判分： 
• 由未評定進入可審查的 1 分級距：先取得有權使用的真實調查／紀錄，能追溯受訪對象、問題、期間及
填答；目前該等資料均 UNKNOWN。 
• 由 1 分到 2 分：除可核實的學員與目標客戶回饋外，補上實際能力評量、前後測或其他可追溯學習資
料，顯示能力提升；單靠滿意度不能支持。 
• 由 2 分到 3 分：補上能力提升連結到工作或組織績效改善的實際紀錄，明列期間、指標、基準及限制；
不得把訓後滿意度直接當成因果證明。 
• 由 3 分到 4 分：補上足以核實「顯著具體績效」的量化前後資料、來源原件與歸因限制；若無法排除
替代解釋，維持未能判定。4 分為本表最高級距。 
本表只解釋官方級距與目前證據缺口，不對原始點協會評分、不代替評核者意見，也不把候選稿轉成 REAL 
證據。

### PDF page 4

候選分析報告  DOCX 0095  /  I18-E02     •     第 4 頁 
1.4 官方要求—候選結果—證據頁次—覆核追溯表 
官方來源：指標 18「訓練系統的一般性功能─目標客戶及學員的評價」；本交付件依 Unique Blueprint 指派對應 I18-E02 檢核框「建立目標客戶及學員滿意度調查機
制（系統及流程面）」，不表示官方佐證表只有此一佐證項目。正式來源頁次為第 6 頁，逐字內容與 SHA-256 見 §1.2；評分級距另見 §1.3。 
官方指標 18／I18-E02 覆核面向 候選結果 
文件證據定位（章節 → PDF 頁次，逐
項對應） 
覆核方式及證據界線 候選狀態 
指標 18／I18-E02：調查機制系
統面 
提出兩類對象的量表、資料字典、計
算口徑、存取及版本控制建議。 
§2.1–§2.4 → PDF pp.5–6 
§3.1–§3.2 → PDF pp.6–9 
§4.1 → pp.10–13；§4.2 → pp.13–
17；§4.3 → pp.17–19 
§5.1 → p.20；§5.2 → p.21 
核對工具、欄位、分母及公式；均為
候選設計，不證明已採用。 
PROPOSED 
指標 18／I18-E02：端到端作業
流程面 
展開需求界定、對象篩選、告知、發
放、回收、檢核、分群分析、審閱及
追蹤。 
§2.1–§2.4 → PDF pp.5–6 
§3.1 → p.6；§3.2 → pp.7–9 
§8.1–§8.5 → pp.34–37 
核對流程輸入、控制點、輸出及暫緩
／退回條件；實際執行 UNKNOWN。 
PROPOSED 
指標 18／I18-E02：目標客戶與
學員分軌評價 
提供 Tool-A、Tool-B、完整 SAMPLE
／SYNTHETIC 明細及分群計算。 
§4.1 → pp.10–13；§4.2 → pp.13–
17；§4.3 → pp.17–19 
§6.1–§6.4 → pp.23–29 
§7.1 → p.30；§7.2 → pp.30–33（附
圖 A → pp.32–33） 
分別檢查兩種問卷、分母、均分與正
向率；不得合併取代分群結果。 
SYNTHETIC 
指標 18／I18-E02：結果判讀與
持續改善 
說明限制、證據強度、候選改善建
議、責任欄位及後續核驗方式。 
§6.3.3 → PDF p.27；§6.4 → pp.28–
29；§6.4.1 → p.29 
§7.3–§7.4 → PDF p.33 
§8 → PDF pp.34–37 
§9.5 → PDF pp.38–41 
§10 → PDF pp.41–44 
核對合成值、限制與替換清冊；無真
實核定、實施或效果證據。 
PROPOSED／
SYNTHETIC

### PDF page 5

候選分析報告  DOCX 0095  /  I18-E02     •     第 5 頁 
頁次錨點說明：本表頁次已依最終 44 頁 R11 Word 匯出逐項核對；章節錨點為主要定位，PDF exact SHA 
與視覺檢查範圍記於外部 QA 收據。若正文或版面再變更，必須重新核頁，不得沿用舊版頁碼。 
2. 目標客戶及學員滿意度調查系統架構與端到端作業流程 
2.1 系統架構理念：系統面與流程面之解構 
本候選設計把「滿意度調查機制」分為系統面與流程面；以下是供原始點協會審議的建議內容，不代表現
況。 
• 系統面（候選設計）：可包括經核定的問卷版本、題項與量尺說明、欄位字典、計算規則、資料存取與
版本控制。協會是否已有相同規範、名冊或系統，資料未提供，狀態 UNKNOWN。 
• 流程面（候選設計）：可涵蓋對象界定、邀請、告知、回收、有效性檢核、分群計算、結果審閱、改善
建議及後續核驗。實際權責、制度發布及執行紀錄均未提供；本文不表示已成立委員會、CAPA 或檔案
管理流程。 
2.2 端到端十階段生命週期總覽 
如經協會權責者審議採用，候選流程可依下列十階段運作；各階段的輸入、控制與產出須在正式採用時確
認： 
階段 候選操作 
一：年度/課程規劃 依訓練計畫界定各班次目標客戶與學員範疇 
二：調查對象名冊界定 匯出受訓學員名單及委訓/派訓單位窗口名冊（建立母體與預計邀請數） 
三：問卷工具核定與編號 依課程屬性套用標準量表，核發唯一追蹤編號與填答說明 
四：知情同意與中立發放 
候選時點：學員結課與評量後離場前自願填答；客戶於結訓後 5 個工作日內回
覆（詳 §1.1） 
五：獨立回收與盲樣編碼 授課講師與行政承辦迴避，由中立收集人封裝回收並進行去識別化編碼 
六：有效性檢核與資料清理 依廢卷標準檢驗漏填與邏輯矛盾，剔除無效卷並確認有效分母 
七：分群統計與報告產出 依標準公式進行學員與目標客戶分軌統計，產出分析圖表與警示清單 
八：決策審議與改善立案 提請經核實之授權者審閱結果；是否提出改善建議及由誰負責，須另行核定 
九：改善驗證與結案追蹤 於次期課程或追蹤期查核改善措施落實度，未達標則重啟檢討 
十：稽核歸檔與存取控制 原始問卷、清理清冊、統計報表與會議紀錄依序歸檔，設定調閱權限 
2.3 流程架構圖與異常迴圈控制 
建議流程以資料完整性與授權為控制門。以下為候選流程示意，不代表目前已啟用的系統或已發生的處置：  
候選步驟 判斷／輸出 
確認授權及調查範圍 → 分群 → 工具與告知內容核定 範圍、對象及使用方式須能追溯；未核定時暫緩。

### PDF page 6

候選分析報告  DOCX 0095  /  I18-E02     •     第 6 頁 
候選步驟 判斷／輸出 
自願填答與中立回收 → 有效性檢核 保留回收數與預先核定的有效性判定依據。 
資料完整且來源可追溯 進行分群計算並說明限制。 
缺少告知、分母不明或題項無法判讀 暫緩分析；補正或依核定規則排除並留下理由。 
授權者審閱 
記錄接受、退回、補件或待審事項；權限未核實不得寫成
決議。 
提出改善建議及後續核驗 責任與期限另行核定；缺資料時維持待追蹤。 
不得依單一未核定百分比自動宣稱不合格或已啟動 CAPA。任何內部門檻須先由有權者審議並留存正式依
據；本報告未取得此類決定。 
2.4 制度化機制與現狀之分際 
制度設計與現況界線 
本章流程與工具是供審議的候選設計。現有制度是否已發布、是否已建置相同系統或是否曾執行調查，
均無可核實來源，故標記 UNKNOWN／NOT PROVIDED；本文不推論其已存在或不存在。採用前應
由協會有權者確認權責、適用範圍、資料告知、工具版本及保存方式。 
 
3. 作業職能分工、權責分離與階段控制點規範 
3.1 職責分離（Segregation of Duties, SoD）設計矩陣 
角色均為候選職能名稱，非已核定職位或現有人員指派。若規模限制無法分工，須由有權者記錄替代控制；
不得將未確認的外部第三方或委員會寫成既有安排。 
候選職能 代碼 建議責任 控制邊界 
調查協調 ROLE-CRD 
界定對象與時點、備妥核定版工具、整
理邀請分母 
不代替受訪者填答，不修改原始分數 
中立收集 ROLE-COL 
說明自願參與、提供不受講師影響的填
答方式、記錄發放與回收數 
不要求正向評分，不檢視個別答案或施壓 
資料檢核與
分析 
ROLE-ANL 
依規則檢核、去識別化、登錄、分群計
算與記錄限制 
不補填缺漏、不把 N/A 當零、不合併群體
掩蓋差異 
授權審議 ROLE-DEC 
由正式授權者審閱結果、記錄決定及改
善責任 
實際人員／組織及授權依據未提供；未核定
前不宣稱決議或 CAPA 已成立

### PDF page 7

候選分析報告  DOCX 0095  /  I18-E02     •     第 7 頁 
3.2 流程作業標準表（SOP）與控制點 
以下為候選作業表，需經正式採用並依實際職責、工具及資料規範調整。所有存放欄位均只示意資料種類，不代表本會現行路徑或系統。 
步驟 輸入 候選操作與控制 產出 暫緩／退回條件 
P-01 界定母體 經核實的課程／對象資料 分別界定學員及目標客戶，記錄納入與排除口徑 邀請分母與來源註記 對象、來源或邀請分母不明則暫緩 
P-02 核定工具 問卷樣張、資料欄位字典 
核對題目中立、量尺、告知文字、版本及必要欄
位 
核定版本與發放紀錄欄
位 
未經授權核定或告知內容不清則不得發放 
P-03 邀請與填答 核定工具及對象清冊 
由中立角色說明自願填答、用途及退出方式；避
免講師或承辦人影響作答 
邀請／回收紀錄 無法確保自願或收集角色可能施壓時暫停 
P-04 回收 
填答表單、已送達邀請名冊與回
收方式 
將邀請發送、實際送達、截止時未回應及實際收
回分開登錄；未回應僅記於邀請／送達名冊。實
際收回每份表單只計一次 POP_RETURNED，後
續狀態另列 
邀請／送達名冊與回收
清冊 
送達狀態不明時不列入 POP_INVITED；回收數
與記錄不一致先查明，不逕行計算 
P-05 有效性檢核 
實際收回表單、候選處理狀態及
採用後核定規則 
先分列撤回、待補正、無效、有效；未回應不屬
表單狀態。只將符合事前核定規則之有效件納入 
POP_VALID；補正後狀態變更保留軌跡且不重
複計份 
回收處理狀態及有效性
檢核清冊 
規則未核定、處置理由缺失、變更無軌跡或原始
值被覆寫則退回 
P-06 登錄與核對 可追溯之有效原始資料 
保留來源列與登錄值；對不一致逐筆核對原件並
留下更正軌跡 
可重算資料表 分母、題碼或更正來源不清則暫緩分析 
P-07 分群分析 核對後資料及公式字典 
分開計算學員與目標客戶；標明 N/A、缺漏及樣
本限制 
分群分析表 公式、分母或樣本抑制規則不一致則重算 
P-08 審閱與決定 分析稿及限制說明 
由經核實的授權者記錄接受、退回、補件或改善
建議 
審閱／決策紀錄 權限來源不明時只列候選建議，不寫成核定決議

### PDF page 8

候選分析報告  DOCX 0095  /  I18-E02     •     第 8 頁 
步驟 輸入 候選操作與控制 產出 暫緩／退回條件 
P-09 後續驗證 已核定的改善事項及後續資料 
依核定的責任與時點比較可比資料，保留未完成
狀態 
追蹤結果或待辦記錄 沒有後續資料時維持 UNKNOWN／待追蹤 
P-10 保管與版本 核定工具、資料與適用規範 
由正式管理者設定存取、保存及銷毀規則；依核
定版本控管 
版本與調閱記錄 現行位置、期限或權限未確認前不宣稱已建置

### PDF page 9

候選分析報告  DOCX 0095  /  I18-E02     •     第 9 頁 
回收狀態與計數界線（候選設計，非本會現行政策；正式採用前待有權者核定）：邀請／送達名冊分開記
錄發出、可核實送達及截止時未回應；POP_INVITED 僅計可核實已送達／交付的對象。未回應沒有問卷表
單，不列為 POP_RETURNED，也不推定原因或評價。實際收回的每份問卷只計一次 POP_RETURNED；其回收
後狀態互斥標示為「撤回」「待補正之未完成」「無效」或「有效」。只有依事前核定規則判定有效者進
入 POP_VALID 與題項分母；補正後更改狀態須保留原狀態及變更軌跡，不重複計份。撤回後個別回答的留
存／移除方式、補正期限及採用規則仍待授權核定，現況為 UNKNOWN。 
建議資料路徑如需設計，應在正式採用後由授權管理者確定；本候選不提供協會現行檔案位置。 
4. 候選調查工具樣張與實務規範（雙軌量表） 
本提案附兩套可供審議的候選問卷樣張，分別面向參訓學員及目標客戶。建議學員於最後一堂與評量結束
後、離場前由非授課人員提供 5–10 分鐘自願填答；目標客戶問卷建議於結訓後 5 個工作日內送達，至第 3 
個工作日可中立提醒一次。採用前須由有權者核定題目、告知內容、施測時點及回收方式；本文不證明現
行機制已採用。量表方向與中立性須於試用前再次檢查。

### PDF page 10

候選分析報告  DOCX 0095  /  I18-E02     •     第 10 頁 
4.1 候選工具一：學員滿意度調查問卷（Learner Survey, Tool-A） 
【表單代號：SURVEY-TOOL-A-L】 
志工服務溝通與紀錄練習 課程學員滿意度調查表 
（SAMPLE／SYNTHETIC 候選樣張；非已施測之協會問卷） 
【填答前知情同意與隱私宣告】 
親愛的填答者您好： 
以下課程名稱、班次與日期均為 SAMPLE／SYNTHETIC 示範，不代表真實辦訓。 
本候選樣張供審議使用；若經授權採用，發放前須核定調查目的、使用範圍、 
資料處理與聯絡方式，並向填答者清楚說明。 
參與應為自願；拒答或中途退出不應影響受訓權益。請依實際經驗作答。 
本文件沒有提供已核定的協會告知文本或真實調查紀錄。 
【本表欄位分區說明】 
（一）示範值（SAMPLE／SYNTHETIC）：僅供樣張呈現，非真實紀錄， 
不得視為已核定、已核准或已施測。 
（二）REAL 空白欄位：每份表單各自填寫；本樣張一律留白，未填入任何真實值。 
（三）管理者專用欄位：由收集人於回收後填寫，填答者不得填寫。 
【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】 
下列「示範班次代號」為 SAMPLE／SYNTHETIC 合成值，僅供樣張識別使用， 
不是已核定或已核准之班次，不得作為正式紀錄引用。 
班次編號（REAL，空白欄位；正式施測時由收集人填列已核定之班次代號）：

### PDF page 11

候選分析報告  DOCX 0095  /  I18-E02     •     第 11 頁 
[                              ] 
示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）： 
SYN-TRN-01 
培訓日期（REAL，空白欄位；正式施測時填寫，格式 YYYY-MM-DD）： 
[                              ] 
示範培訓日期（SAMPLE／SYNTHETIC 合成值；非實際辦訓日期）： 
2026-07-11 
學員流水編號（由收集人黏貼）：[          ] 
實際填答日期（REAL，空白欄位；每份表單各自填寫，格式 YYYY-MM-DD）： 
[                              ] 
（填答說明：示範值與 REAL 欄位分列，不互相取代；本樣張刻意留白所有 REAL 欄位。 
正式施測時，「實際填答日期」由填答者當場填寫，或由收集人依發放當日填寫； 
不得回填示範日期，亦不得由管理者代填為擬定日期。） 
【第一部分：核心滿意度評估題項】 
請針對下列各項內容，於最適當之評分欄位打「V」。 
評分標準：[5]=非常滿意 [4]=滿意 [3]=普通/尚可 [2]=不滿意 [1]=非常不滿意 [N/A]=不適用 
（填答防護提示：本部分 5 題核心題項為有效問卷判定之必要條件，請勿遺漏） 
【跨頁填答提示】本頁為前置說明；L-01 至 L-05 題項矩陣及 Q-06、Q-07 意見欄接續於下一頁。兩頁須成套填寫與回收。

### PDF page 12

候選分析報告  DOCX 0095  /  I18-E02     •     第 12 頁 
題號 構面 題目 5 4 3 2 1 N/A 
L-01 任務關聯性 本次課程內容能切合志工服務日常實務之溝通需求。 [ ] [ ] [ ] [ ] [ ] [ ] 
L-02 目標與引導 課程學習目標與講師各單元之解說指引清晰易懂。 [ ] [ ] [ ] [ ] [ ] [ ] 
L-03 演練價值性 課程安排之溝通演練與紀錄操作對技能熟練有幫助。 [ ] [ ] [ ] [ ] [ ] [ ] 
L-04 講師支持度 講師及助教在課堂中能充分提供互動支持與回饋。 [ ] [ ] [ ] [ ] [ ] [ ] 
L-05 整體滿意度 
綜合考量整體教學設計，我對本次課程品質感到滿
意。 
[ ] [ ] [ ] [ ] [ ] [ ] 
【第二部分：質性意見與改進建議（自由填寫）】 
Q-06 您認為本次課程中，哪一個教學環節對您的日常實務助益最大？ 
答：_______________________________________________________________________________ 
續寫：_____________________________________________________________________________ 
Q-07 為提升後續辦訓品質，您認為本課程最需要檢討或加強之處為何？ 
答：_______________________________________________________________________________ 
續寫：_____________________________________________________________________________ 
【管理者專用：資格核對與完整性判定欄位】 
（由收集人於回收後填寫；填答者不得填寫本欄） 
本欄位為候選表單設計建議，不是本會現行作業政策；本文件未載明協會既有之 
資格核對或回收判定程序，相關規則狀態為 UNKNOWN。有效性判定規則以本文件 
§5.1 適用之規則為準；本表不另訂門檻。 
受評者是否實際參與本次課程（資格核對）：[ ] 是 [ ] 否

### PDF page 13

候選分析報告  DOCX 0095  /  I18-E02     •     第 13 頁 
資格核對依據（管理者註記）：[                              ] 
填答完整性核對：[ ] 五項核心題項（L-01～L-05）全部作答 [ ] 有缺漏題項 
缺漏題項代號（如有）：[                              ] 
回收後表單處理狀態（單選；僅適用於實際收回之表單）： 
未回應（NONRESPONSE）沒有單一問卷表單，請依 §3.2 登錄於邀請／送達名冊；不得在本欄選填，亦不得視為負面評價。 
[ ] 撤回（WITHDRAWN）：填答者主動撤回，已停止使用其作答。 
[ ] 待補正之未完成（INCOMPLETE_PENDING_CORRECTION）：已作答但有缺漏，待補正。 
[ ] 無效（INVALID）：不符合有效性規則者，依 §5.1 規則認定。 
[ ] 有效（VALID）：符合有效性規則，納入分母計算。 
（上述四類為互斥之單選分類；補正期限由採行者另行核定，本件未設定期限。） 
判定備註（管理者）：[                              ] 
管理者簽核（若經授權）：[                              ] 
（計數界線：未回應只在邀請／送達名冊登錄，不列為 POP_RETURNED。已實際收回的表單，不論後續撤回、待補正或判為無效，均只計一次 POP_RETURNED；上
述三種狀態不納入 POP_VALID 或題項分母，僅依 §5.1 規則判定為有效的表單納入 §6 計算。更正後狀態變更須留有軌跡，不重複計份。個別回覆資料之留存／移除方
式待正式授權核定；目前狀態 UNKNOWN。） 
感謝您的回饋。若經正式採用，請依已核定的中立回收方式交回；本樣張不指定或宣稱協會已有實際回收箱或收集人。 
4.2 候選工具二：目標客戶聯絡窗口滿意度調查問卷（Target-Customer Survey, Tool-B） 
【表單代號：SURVEY-TOOL-B-C】 
志工服務溝通與紀錄練習 目標客戶（派訓單位聯絡人）滿意度調查表 
（SAMPLE／SYNTHETIC 候選樣張；非已施測之協會問卷）

### PDF page 14

候選分析報告  DOCX 0095  /  I18-E02     •     第 14 頁 
【填答前知情同意與隱私宣告】 
致目標客戶填答者： 
以下課程名稱與班次均為 SAMPLE／SYNTHETIC 示範，不代表曾有委託或開課。 
本候選樣張供審議使用；若經授權採用，邀請前應核實對象、調查目的、使用範圍、 
資料處理與回收方式，並清楚說明自願參與及退出方式。 
是否已有相關機制、委託關係或專責部門，資料未提供，均為 UNKNOWN。 
【本表欄位分區說明】 
（一）示範值（SAMPLE／SYNTHETIC）：僅供樣張呈現，非真實紀錄， 
不得視為已委託、已核准或已施測。 
（二）REAL 空白欄位：每份表單各自填寫；本樣張一律留白，未填入任何真實值。 
（三）管理者專用欄位：由收集人於回收後填寫，填答者不得填寫。 
【未提供任何經核實並核定的真實班次識別碼；下列代碼僅為合成示範】 
下列「示範班次代號」為 SAMPLE／SYNTHETIC 合成值，僅供樣張識別使用， 
不是已核定或已核准之班次，不得作為正式紀錄引用。 
目標客戶／聯絡窗口代碼（REAL，空白欄位；由核實後的實際流程填列）： 
[                              ] 
示範班次代號（SAMPLE／SYNTHETIC 合成值；未核定，非正式班次）： 
SYN-TRN-01 
填答人角色（單選）： 
[ ] 派訓主管 [ ] 培訓聯絡人 [ ] 其他（請註明）：[          ]

### PDF page 15

候選分析報告  DOCX 0095  /  I18-E02     •     第 15 頁 
資格核對（由管理者或邀請單位填寫；填答者不得填寫）： 
本填答人是否為貴單位之指定目標客戶聯絡窗口或經授權代表：[ ] 是 [ ] 否 [ ] 待核 
提供評價之工作接觸（可複選；不以本人參訓為必要）：[ ] 課前需求／行政溝通 [ ] 訓後追蹤／回饋 [ ] 其他：[          ] 
資格核對依據（管理者註記）：[                              ] 
邀請發送日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ] 
送達日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ] 
示範填答日期（SAMPLE／SYNTHETIC 合成值，非真實施測結果）：2026-07-11 
實際填答日期（REAL，空白欄位；每份表單各自填寫；格式 YYYY-MM-DD）：[          ] 
回收日期（REAL，空白欄位；格式 YYYY-MM-DD）：[          ] 
（填答說明：邀請發送、送達、填答、回收四個時點分開記錄，俾對應 §1.1、§2.2 之 
候選流程時點控制（該時限設定屬候選內容，非本會現行實務紀錄）。 
本樣張尚未施測，亦不代表曾有委託或開課；上述四個 REAL 日期欄位於採用後由 
各該流程之執行人分別填寫，本版未填入任何真實日期，實際值一律 UNKNOWN； 
示範填答日期不得填入 REAL 欄位，亦不得回填示範班次代號。） 
【第一部分：目標客戶專屬滿意度評估題項】 
請針對下列辦訓合作各構面，勾選最符合 貴單位感受之評等。 
評分標準：[5]=非常滿意 [4]=滿意 [3]=普通/尚可 [2]=不滿意 [1]=非常不滿意 [N/A]=不適用 
【跨頁填答提示】本頁為前置說明；C-01 至 C-05 題項矩陣及 Q-06 意見欄接續於下一頁。兩頁須成套填寫與回收。

### PDF page 16

候選分析報告  DOCX 0095  /  I18-E02     •     第 16 頁 
題號 構面 題目 5 4 3 2 1 N/A 
C-01 目標需求契合 
本次培訓規劃與 貴單位所提出之志工服務需求目標契
合。 
[ ] [ ] [ ] [ ] [ ] [ ] 
C-02 辦訓安排明晰 本會在課前籌備、行政溝通與課務通知流程清楚明確。 [ ] [ ] [ ] [ ] [ ] [ ] 
C-03 實作演練價值 
課程設計之演練與實作環節符合 貴單位對工作技能之預
期。 
[ ] [ ] [ ] [ ] [ ] [ ] 
C-04 訓後溝通追蹤 本會於訓後所提供之溝通協調與出缺勤反饋及時且具體。 [ ] [ ] [ ] [ ] [ ] [ ] 
C-05 整體滿意度 
綜合整體辦訓服務與合作體驗，貴單位對本會整體表現滿
意。 
[ ] [ ] [ ] [ ] [ ] [ ] 
【第二部分：委託單位專屬回饋（選填）】 
Q-06 貴單位未來指派或委辦同類型志工訓練時，最希望本會增強何種專業支援？ 
答：_______________________________________________________________________________ 
續寫：_____________________________________________________________________________ 
【管理者專用：資格核對與完整性判定欄位】 
（由收集人於回收後填寫；填答者不得填寫本欄） 
本欄位為候選表單設計建議，不是本會現行作業政策；本文件未載明協會既有之 
資格核對或回收判定程序，相關規則狀態為 UNKNOWN。有效性判定規則以本文件 
§5.1 適用之規則為準；本表不另訂門檻。 
填答完整性核對：[ ] 五項題項（C-01～C-05）全部作答 [ ] 有缺漏題項 
缺漏題項代號（如有）：[                              ] 
回收後表單處理狀態（單選；僅適用於實際收回之表單）：

### PDF page 17

候選分析報告  DOCX 0095  /  I18-E02     •     第 17 頁 
未回應（NONRESPONSE）沒有單一問卷表單，請依 §3.2 登錄於邀請／送達名冊；不得在本欄選填，亦不得視為負面評價。 
[ ] 撤回（WITHDRAWN）：填答者主動撤回，已停止使用其作答。 
[ ] 待補正之未完成（INCOMPLETE_PENDING_CORRECTION）：已作答但有缺漏，待補正。 
[ ] 無效（INVALID）：不符合有效性規則者，依 §5.1 規則認定。 
[ ] 有效（VALID）：符合有效性規則，納入分母計算。 
（上述四類為互斥之單選分類；補正期限由採行者另行核定，本件未設定期限。） 
判定備註（管理者）：[                              ] 
管理者簽核（若經授權）：[                              ] 
（計數界線：未回應只在邀請／送達名冊登錄，不列為 POP_RETURNED。已實際收回的表單，不論後續撤回、待補正或判為無效，均只計一次 POP_RETURNED；上
述三種狀態不納入 POP_VALID 或題項分母，僅依 §5.1 規則判定為有效的表單納入 §6 計算。更正後狀態變更須留有軌跡，不重複計份。個別回覆資料之留存／移除方
式待正式授權核定；目前狀態 UNKNOWN。） 
如經採用，依正式核定的中立回收方式交回；本候選未指定或宣稱協會已有任何實際回收通道。 
4.3 量表欄位對映、防偏誤設計與不適用（N/A）防護處理 
表單題號 分析資料庫欄位名稱 構面中文定義 計分方向 量尺區間 正向判定規則 題項中立性檢核（Anti-bias Verification） 
L-01 LEARN_RELEVANCE 實務任務關聯性 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
避免「本課程極具實用性」等誇飾引導詞；平鋪
直述陳述需求切合度。 
L-02 LEARN_CLARITY 目標與引導清晰度 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
聚焦於客觀認知之清晰度，不使用讚美講師個人
魅力之情緒性詞彙。 
L-03 LEARN_PRACTICE 實作演練實用價值 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
檢視演練環節是否實用，無預設成效達成之壓迫
性字眼。

### PDF page 18

候選分析報告  DOCX 0095  /  I18-E02     •     第 18 頁 
表單題號 分析資料庫欄位名稱 構面中文定義 計分方向 量尺區間 正向判定規則 題項中立性檢核（Anti-bias Verification） 
L-04 LEARN_SUPPORT 講師互動與輔導支持 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 著重於「互動支持機制」，非主觀人氣打分。 
L-05 LEARN_OVERALL 學員整體綜合滿意度 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
整體檢驗核心題；空白使全卷無效，N/A 依下方
規則處理。 
C-01 CUST_GOAL_FIT 組織培訓目標契合度 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
檢核規劃與派訓需求之一致性，供機構客戶客觀
衡量合約交付。 
C-02 CUST_ARRANGE 行政與辦訓溝通明晰 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
針對前期作業與課務行政流程進行評量，切分教
學與行政責任。 
C-03 CUST_PRACTICE 演練環節符合組織預
期 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
評估實務演練是否貼近派訓單位實際志工服務情
境。 
C-04 CUST_COMM_CLAR 訓後聯繫與回饋明確
度 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 評量訓後續階溝通與配合度，確保服務延伸性。 
C-05 CUST_OVERALL 目標客戶整體滿意度 
正向計分（分高益
善） 
1～5 分 4～5 分為正向 
整體檢驗核心題；空白使全卷無效，N/A 依下方
規則處理。

### PDF page 19

候選分析報告  DOCX 0095  /  I18-E02     •     第 19 頁 
N/A（不適用）防護機制： 如工具與統計規則經核定允許選填 N/A，該份答卷該題不列入該題平均與分母；
N/A 不視為 0 分。這是候選計算規則，並非已建置的系統功能。 
兩套問卷的核心題有效性規則：Tool-A 的 L-01 至 L-05、Tool-B 的 C-01 至 C-05 均須有明確作答；任何
核心題空白即判該份問卷無效。N/A 是明確選項而非空白，可依核定口徑保留為有效問卷，但該題須標示 
N/A 並從該題分母剔除；若整體題 L-05／C-05 為 N/A，仍不得以其他題分數替代整體滿意度。

### PDF page 20

候選分析報告  DOCX 0095  /  I18-E02     •     第 20 頁 
5. 資料字典、計算公式與統計口徑規範｜5.1 母體、樣本與資料欄位字典 
為求統計口徑嚴密且完全重現，所有滿意度調查及後續追蹤指標均嚴格定義分母與分子邊界： 
欄位名稱代碼 指標名稱 
統計母數／分母界定
（Denominator） 
分子界定（Numerator） 資料來源表單 納入排除條件與資料限制說明 
POP_ELIGIBLE 
符合條件之對
象母體 
依事前核定納入條件界定的學員
或目標客戶。 
實際納入母體的人數；不等同已送達邀
請數。 
核實後的課程／客戶名
冊及納入排除紀錄 
條件或名冊不明則暫緩；不得自行排
除。 
POP_INVITED 
已送達／交付
邀請數 
實際收到或已交付邀請的對象數
（本公式的回收率分母）。 
已送達或交付之邀請數；如送達狀態不
明，分開記錄發出與送達數。 
邀請發放／送達紀錄
（如正式採用） 
無法核實實際邀請數時，回收率不得計
算；不以名冊母體代替。 
POP_RETURNED 
問卷回收總份
數 
已送達邀請數。 
截止時實際收回之紙本或數位問卷份
數。 
經核定方式產生的邀請
／回收紀錄 
未回覆原因如未取得來源，維持 
UNKNOWN；不得推測為拒絕或某種
滿意程度。 
POP_VALID 
有效問卷總份
數 
回收份數（POP_RETURNED）。 符合預先核定有效規則之問卷數。 
有效性檢核紀錄（如正
式採用） 
缺漏或矛盾的處置依預先核定規則；無
規則或無可核對來源時暫緩，不補填答
案。 
MISSING_ITEM 題項缺漏值 依核定工具應填答之題項數。 漏填或劃記不清而無法辨識的題數。 
有效性檢核紀錄（如正
式採用） 
核心題缺漏的處置應依事先核定的有效
規則；不得補造答案。 
NA_TREATMENT 
不適用題項標
記 
該題實際回答人數。 勾選 N/A 的人數。 
原始回答表（若正式採
用） 
僅在工具及統計規則核定後使用；N/A 
不視為 0 分。 
POS_RATING 
正向評價回答
數 
該題有效作答人數。 
若核定採用此口徑，評分 4 或 5 的有效
作答數。 
原始回答表（若正式採
用） 
1～3 分不列正向；此為候選定義，正
式使用前需核定量尺。 
EVAL_FOLLOWUP 
可評估配對追
蹤人數 
在指定時點具有可核對前、後測
的對象數。 
完成符合預先核定條件之配對評量人
數。 
追蹤評量表及原始分數
來源 
未配對、失聯或未提供者不補零；配對
條件不清則不得計算變化率。 
SUB_SUPPRESS 
小樣本抑制門
檻 
分群統計之各次分類樣本數。 
若次分群有效樣本數 n < 5，不呈現可
識別的細分結果；僅註記樣本不足，不
發布細分百分比、平均或個別值。 
分群分析表（若正式採
用） 
n < 5 時建議抑制細分百分比、平均、
次數分布及個別值；門檻需依正式授權
與資料風險核定。

### PDF page 21

候選分析報告  DOCX 0095  /  I18-E02     •     第 21 頁 
回收／有效狀態之候選計數口徑（與 §3.2、§4.1、§4.2 一致；非本會現行政策）：POP_RETURNED 為截止
前實際收回之表單數，每份只計一次，不因後續狀態改變而重複計數；「撤回」「待補正之未完成」「無
效」均不計入 POP_VALID 或題項分析分母，只有依事前核定規則判定「有效」的表單納入。未回應須記於
邀請／送達名冊，沒有表單，不列為  POP_RETURNED。補正與狀態更改須留軌跡；本候選未設定補正期限，
亦未主張協會已有任何現行處置規則。 
5.2 核心指標之數學公式庫（Explicit & Reproducible Formulae） 
1. 問卷回收率（Returned Rate, R_(ret)） 
R_(ret) = (回收問卷總份數  (N_(returned))) / (已送達／交付邀請數  (N_(invited))) × 100% 口徑說明：表
示實際回收份數相對於邀請數的比例；不能單獨解讀為配合程度或代表性。 
2. 回收有效率（Validity Rate among Returned, R_(val)） 
R_(val) = (有效問卷總份數  (N_(valid))) / (實際回收問卷總份數  (N_(returned))) × 100% 口徑說明：描述
回收問卷中符合預先核定有效規則的比例；此比例本身不能證明題目或填答說明的品質。 
3. 題項滿意度平均數（Mean Score, X̄_j） 
X̄_j = (Σ_(i=1)^(N_(valid, j)) X_(ij)) / (N_(valid, j)) 式中 X_(ij) 代表第 i 位有效填答者在第 j 個題項之得分（1
～5 分）；N_(valid, j) 為排除該題填寫 `N/A` 後之有效填答人數。四捨五入計算至小數點後第二位。 
4. 滿意度正向率（Positive Response Rate, P_j） 
P_j = (N_(positive, j)  (X_(ij) ∈ {4, 5})) / (N_(valid, j)) × 100% 式中分子為評等為 4 分或 5 分之有效人數。
四捨五入計算至小數點後第一位。 
5. 訓後成果達成率（Follow-up Outcome Rate, R_(outcome)） 
R_(outcome) = (符合成果門檻之人數  (N_(pass))) / (實際可評估之追蹤人數  (N_(evaluable))) × 100% 口
徑說明：僅能以完成追蹤實作評量之有效配對樣本人數為分母。未受測者不得設為 0 分納入，亦不得假設
其未達標。 
6. 成效相對變化率（Relative Change Rate, Δ_(rel)）與絕對差距（Absolute Difference, Δ_(abs)） 
Δ_(abs) = Ȳ_(post) - Ȳ_(pre) = (Σ Y_(post)) / (N_(paired)) - (Σ Y_(pre)) / (N_(paired)) Δ_(rel) = (Ȳ_(post) 
- Ȳ_(pre)) / (Ȳ_(pre)) × 100% = (Σ Y_(post) - Σ Y_(pre)) / (Σ Y_(pre)) × 100% 防護警示（N/A Guard）：
若前測基準均分 Ȳ_(pre) = 0，相對變化率無數學意義，系統輸出為 `N/A`，嚴禁標註為無窮大或虛構百分
比。 
統一精度與四捨五入規則：先保留完整原始分子、分母及未四捨五入中間值，再依下列位數呈現；採一般
四捨五入，禁止以已四捨五入的中間值再計算。R_ret、R_val、R_outcome、正向率及 Δ_rel 以百分比表
示時四捨五入至小數點後 1 位；題項平均數及 Δ_abs 四捨五入至小數點後 2 位。任何公式分母為 0 或資料
不足時輸出 N/A，並明列可計算樣本數；不得以 0 代替缺值。

### PDF page 22

候選分析報告  DOCX 0095  /  I18-E02     •     第 22 頁 
6. 合成示範案例完整數據展示與逐步計算驗證 
本章採用本寫作任務提供的 SAMPLE／SYNTHETIC 數據，示範資料流轉、驗證與計算。此案例未經官方或
協會核定，也不代表實際運作；各示範事實對應文末事實粒度替換清冊。 
• 示範班次案號：SYN-TRN-01（SAMPLE／SYNTHETIC，來源為本件寫作任務資料包） 
• 示範課程名稱：志工服務溝通與紀錄練習（SAMPLE / SYNTHETIC） 
• 課程教學時數：6 小時 
• 課程辦理日期：2026 年 07 月 11 日（示範日期） 
• 追蹤測評日期：2026 年 08 月 10 日（訓後 30 日示範追蹤）

### PDF page 23

候選分析報告  DOCX 0095  /  I18-E02     •     第 23 頁 
6.1 學員滿意度調查原始資料列（Learner Survey Raw Data） 
本 SAMPLE／SYNTHETIC 案例將 18 設為已送達或交付的邀請數，以符合欄位字典 POP_INVITED 的分母定義；單純發出但送達狀態不明的數量未提供，故不另列。
回收 15 份，另 3 人未回覆；未回覆原因未提供。15 份回收中有 1 份因整體滿意度核心題缺漏而無效，因此有效問卷為 14 份。缺漏表的其他題目值與個別識別碼未提
供，不臆造或展示；下表僅列 14 份提供的有效評分： 
填答索引代碼 
任務關聯性 
(Relevance) 
目標引導清晰 
(Clarity) 
演練操作價值 
(Practice) 
講師支持度 
(Support) 
整體滿意度 
(Overall) 
判定狀
態 
SYN-L01 5 4 5 5 5 
有效納
入 
SYN-L02 5 4 4 4 5 
有效納
入 
SYN-L03 4 5 4 4 4 
有效納
入 
SYN-L04 3 4 3 4 4 
有效納
入 
SYN-L05 5 5 4 5 5 
有效納
入 
SYN-L06 4 4 4 3 4 
有效納
入 
SYN-L07 4 3 4 4 4 
有效納
入 
SYN-L08 5 5 5 4 5 
有效納
入

### PDF page 24

候選分析報告  DOCX 0095  /  I18-E02     •     第 24 頁 
填答索引代碼 
任務關聯性 
(Relevance) 
目標引導清晰 
(Clarity) 
演練操作價值 
(Practice) 
講師支持度 
(Support) 
整體滿意度 
(Overall) 
判定狀
態 
SYN-L09 4 4 3 4 4 
有效納
入 
SYN-L10 4 3 4 3 4 
有效納
入 
SYN-L11 3 4 3 4 3 
有效納
入 
SYN-L12 5 4 5 5 5 
有效納
入 
SYN-L13 4 4 4 4 4 
有效納
入 
SYN-L14 2 3 3 3 2 
有效納
入 
6.2 目標客戶滿意度調查原始資料列（Target-Customer Raw Data） 
目標客戶聯絡對象的合成邀請數為 6，回收 5 份，另 1 人未回覆；未回覆原因、機構名稱及填答者真實角色未提供。5 份均有效。下表以合成代碼表示，不代表任何真
實第三方組織或人員： 
填答索引代碼 
目標需求契合 
(Goal Fit) 
辦訓安排明晰 
(Arrangement) 
實作演練價值 
(Practice) 
訓後溝通追蹤 
(Follow-up) 
整體滿意度 
(Overall) 
判定狀
態 
SYN-C01 5 5 4 5 5 
有效納
入

### PDF page 25

候選分析報告  DOCX 0095  /  I18-E02     •     第 25 頁 
填答索引代碼 
目標需求契合 
(Goal Fit) 
辦訓安排明晰 
(Arrangement) 
實作演練價值 
(Practice) 
訓後溝通追蹤 
(Follow-up) 
整體滿意度 
(Overall) 
判定狀
態 
SYN-C02 4 4 4 4 4 
有效納
入 
SYN-C03 5 4 5 5 5 
有效納
入 
SYN-C04 3 3 3 3 3 
有效納
入 
SYN-C05 4 4 4 4 4 
有效納
入

### PDF page 26

候選分析報告  DOCX 0095  /  I18-E02     •     第 26 頁 
6.3 逐步計算推導歷程（Step-by-Step Explicit Arithmetic） 
6.3.1 學員端滿意度指標計算推導 
1. 問卷回收率： 
R_(ret, Learner) = (15) / (18) = 83.333% → 83.3% 
2. 回收有效率： 
R_(val, Learner) = (14) / (15) = 93.333% → 93.3% 
3. 任務關聯性（Relevance）： 
• 總分總和：5+5+4+3+5+4+4+5+4+4+3+5+4+2 = 57 
• 平均分數：X̄ = (57) / (14) = 4.0714 → 4.07 分（滿分 5.00） 
• 正向評分個數（4～5 分）：共 11 人（SYN-L01, L02, L03, L05, L06, L07, L08, L09, L10, L12, L13） 
• 正向率：P = (11) / (14) = 78.571% → 78.6% 
4. 目標引導清晰度（Clarity）： 
• 總分總和：4+4+5+4+5+4+3+5+4+3+4+4+4+3 = 56 
• 平均分數：X̄ = (56) / (14) = 4.0000 → 4.00 分 
• 正向評分個數（4～5 分）：共 11 人（SYN-L01, L02, L03, L04, L05, L06, L08, L09, L11, L12, L13） 
• 正向率：P = (11) / (14) = 78.571% → 78.6% 
5. 演練操作價值（Practice）： 
• 總分總和：5+4+4+3+4+4+4+5+3+4+3+5+4+3 = 55 
• 平均分數：X̄ = (55) / (14) = 3.9285 → 3.93 分 
• 正向評分個數（4～5 分）：共 10 人（SYN-L01, L02, L03, L05, L06, L07, L08, L10, L12, L13） 
• 正向率：P = (10) / (14) = 71.428% → 71.4% 
6. 講師支持度（Support）： 
• 總分總和：5+4+4+4+5+3+4+4+4+3+4+5+4+3 = 56 
• 平均分數：X̄ = (56) / (14) = 4.0000 → 4.00 分 
• 正向評分個數（4～5 分）：共 11 人（SYN-L01, L02, L03, L04, L05, L07, L08, L09, L11, L12, L13） 
• 正向率：P = (11) / (14) = 78.571% → 78.6% 
7. 整體滿意度（Overall）： 
• 總分總和：5+5+4+4+5+4+4+5+4+4+3+5+4+2 = 58 
• 平均分數：X̄ = (58) / (14) = 4.1428 → 4.14 分 
• 正向評分個數（4～5 分）：共 12 人（SYN-L01～L10, L12, L13） 
• 正向率：P = (12) / (14) = 85.714% → 85.7% 
6.3.2 目標客戶端滿意度指標計算推導 
1. 問卷回收與有效率： 
R_(ret, Customer) = (5) / (6) = 83.333% → 83.3% R_(val, Customer) = (5) / (5) = 100.0%

### PDF page 27

候選分析報告  DOCX 0095  /  I18-E02     •     第 27 頁 
另列有效回收占邀請數：5/6=83.3%；此數為邀請母體中的有效份數比例，不是回收有效率。 
2. 目標需求契合（Goal Fit）： 
• 總分總和：5+4+5+3+4 = 21 
• 平均分數：X̄ = (21) / (5) = 4.2000 → 4.20 分 
• 正向評分個數：共 4 人（SYN-C01, C02, C03, C05） 
• 正向率：P = (4) / (5) = 80.000% → 80.0% 
3. 辦訓安排明晰（Arrangement Clarity）： 
• 總分總和：5+4+4+3+4 = 20 
• 平均分數：X̄ = (20) / (5) = 4.0000 → 4.00 分 
• 正向評分個數：共 4 人；正向率：P = (4) / (5) = 80.0% 
4. 實作演練價值（Practice Value）： 
• 總分總和：4+4+5+3+4 = 20 
• 平均分數：X̄ = (20) / (5) = 4.0000 → 4.00 分 
• 正向評分個數：共 4 人；正向率：P = (4) / (5) = 80.0% 
5. 訓後溝通追蹤（Follow-up Clarity）： 
• 總分總和：5+4+5+3+4 = 21 
• 平均分數：X̄ = (21) / (5) = 4.2000 → 4.20 分 
• 正向評分個數：共 4 人；正向率：P = (4) / (5) = 80.0% 
6. 整體滿意度（Overall）： 
• 總分總和：5+4+5+3+4 = 21 
• 平均分數：X̄ = (21) / (5) = 4.2000 → 4.20 分 
• 正向評分個數：共 4 人；正向率：P = (4) / (5) = 80.0% 
6.3.3 分軌呈現限制（不合併推論） 
學員與目標客戶的對象、問卷題意及構面不同。本報告分別列示兩群的送達、回收、有效份數、均分與
正向率；不得將分群結果加總成合併滿意度或正向率，也不得跨群比較高低。如需行政核對總件數，須
保留兩群各自的分母並分項列出，合計數不得作成效指標。

### PDF page 28

候選分析報告  DOCX 0095  /  I18-E02     •     第 28 頁 
6.4 補充追蹤案例：30 日實務演練成效檢核（Supplementary Skill Check） 
為示範滿意度調查（反應層次）如何與後續學習評估銜接，本案例引入一組 30 天實務紀錄操作評量（0～10 分量規）。本評量為補充性 SAMPLE／SYNTHETIC 衍生
範例，其測驗分數絕非滿意度評分，亦不得宣稱為訓練之必然因果實績。表內「7 分」只是假設示例的判讀規則，不是原始點協會已核定的合格門檻；實際採用須由有
權者另行核定量尺與標準。 
• 受測對象：14 位有效學員中，共 12 位學員具備完整之前測與 30 日後追蹤測評配對資料（SYN-L01 至 SYN-L12）。 
• 追蹤遺漏處理：提供的合成資料指出 14 位有效學員中有 12 組完整配對分數，另 2 組追蹤值不可得；不可得原因及前測分數未提供，故不臆造。缺值不以 0 分填
補，亦不納入配對統計分母。 
學員代碼 訓前實務測評基準 (Before, 0-10) 訓後 30 日實務評量 (30-day, 0-10) 個別分數差異值 (Δ = Post - Pre) 達標判定 (≥ 7 分) 
SYN-L01 4 7 +3 達標 
SYN-L02 5 8 +3 達標 
SYN-L03 6 8 +2 達標 
SYN-L04 3 6 +3 未達標 (6 分) 
SYN-L05 4 7 +3 達標 
SYN-L06 5 8 +3 達標 
SYN-L07 6 8 +2 達標 
SYN-L08 2 5 +3 未達標 (5 分) 
SYN-L09 4 7 +3 達標 
SYN-L10 5 8 +3 達標 
SYN-L11 3 6 +3 未達標 (6 分) 
SYN-L12 4 7 +3 達標

### PDF page 29

候選分析報告  DOCX 0095  /  I18-E02     •     第 29 頁 
6.4.1 配對成效指標推導歷程 
配對母數核對：14 位有效學員 = 12 位有完整前後測配對資料 + 2 位追蹤值不可得；後 2 位不納入配對成
效分母，也不視為未達標。 
1. 訓前平均分數（Baseline Mean, Ȳ_(pre)）： 
Σ Y_(pre) = 4+5+6+3+4+5+6+2+4+5+3+4 = 51 Ȳ_(pre) = (51) / (12) = 4.2500 → 4.25  分 
2. 訓後 30 日平均分數（Post Mean, Ȳ_(post)）： 
Σ Y_(post) = 7+8+8+6+7+8+8+5+7+8+6+7 = 85 Ȳ_(post) = (85) / (12) = 7.0833 → 7.08  分 
3. 平均絕對變化量（Absolute Mean Difference, Δ_(abs)）： 
Δ_(abs) = Ȳ_(post) - Ȳ_(pre) = 7.0833 - 4.2500 = (85 - 51) / (12) = (34) / (12) = 2.8333 → 2.83  分 
4. 相對描述性變化率（Relative Descriptive Change, Δ_(rel)）： 
Δ_(rel) = (85 - 51) / (51) = (34) / (51) = 0.6666... × 100% → 66.7% (防護檢核：基準值 51 不為 0，故算
式有效可解) 
5. 成果門檻達成率（Outcome Achievement Rate, ≥ 7 分）： 
達標人數  (N_(≥ 7)) = 9  人    (未達標者：L04 為 6 分, L08 為 5 分, L11 為 6 分) R_(outcome) = (9) / (12) 
= 75.000% → 75.0% 
7. 分群分析、品質限制與因果界線闡明

### PDF page 30

候選分析報告  DOCX 0095  /  I18-E02     •     第 30 頁 
7.1 分群報告核心原則：雙軌矩陣對照 
依據 TTQS 指標要求，調查報告必須分別凸顯「學員」與「目標客戶」之滿意度輪廓。兩者在認知重點與敏感度上展現顯著落差： 
比較面向 學員端 目標客戶端 
評估構面維度 學員端 (Learner, n=14) 目標客戶端 (Customer, n=5) 
核心關注焦點 課程實用度、講師引導、演練體驗 需求契合度、行政協調、後續追蹤 
正向率最高項目 整體滿意度 (85.7%) 五項並列 4/5＝80.0%（無相對最高項目） 
正向率最低項目 實作演練價值 (71.4%) 五項並列 4/5＝80.0%（無相對最低項目） 
平均得分最高項目 整體滿意度 (4.14 分) 目標需求契合 (4.20 分)、溝通追蹤 (4.20 分)、整體滿意度 (4.20 分) 
平均得分最低項目 實作演練價值 (3.93 分) 辦訓安排 (4.00 分)、實作演練 (4.00 分) 
7.2 視覺化就緒表格：指標差距與優先改善排序矩陣 
下表只按提供的合成數據描述各群體，不套用未經核定的內部門檻，也不推論成因。 
【群內排序規則（可重現）】 (1) 排序範圍限於同一群體內，學員端與目標客戶端分別計算，不合併、不加權、不跨群比較序位。 (2) 先以正向率由低到高排序。 (3) 
正向率相同者，再以平均分由低到高排序。 (4) 正向率與平均分皆相同者，並列同一序位；序位採不跳號之密集計法（P1、P2、P3…）。 (5) 差距之比較基準取各群體
「組內最高項目」，僅作描述性對照，不是核定的合格門檻、門檻值或績效目標。 (6) 「正向」係指評分 4 或 5（口徑見 §5.1）。 
【學員端（Learner，有效 n=14）】 比較基準（組內最高項目）：L-05 整體滿意度，正向率 85.7%、平均 4.14 分。 
序位 題號／構面 有效 N 
正向人數／有效 
N 
正向率 平均分 
與組內基準之正向率差距
（百分點） 
與組內基準之平均分差
距（分） 
描述性觀察 
P1 L-03 演練操作價值 14 10/14 71.4% 3.93 14.3 0.21 
本群體正向率與平均分皆最低；原因 
UNKNOWN

### PDF page 31

候選分析報告  DOCX 0095  /  I18-E02     •     第 31 頁 
序位 題號／構面 有效 N 
正向人數／有效 
N 
正向率 平均分 
與組內基準之正向率差距
（百分點） 
與組內基準之平均分差
距（分） 
描述性觀察 
P2 L-02 目標引導清晰 14 11/14 78.6% 4.00 7.1 0.14 
與 L-04 正向率與平均分並列（同序
位） 
P2 L-04 講師支持度 14 11/14 78.6% 4.00 7.1 0.14 
與 L-02 正向率與平均分並列（同序
位） 
P3 L-01 任務關聯性 14 11/14 78.6% 4.07 7.1 0.07 
正向率與 L-02／L-04 相同，僅平均
分較高 
P4 L-05 整體滿意度 14 12/14 85.7% 4.14 0.0 0.00 本群體比較基準（組內最高項目） 
【目標客戶端（Customer，有效 n=5）】 比較基準（組內最高項目）：C-01 目標需求契合、C-04 訓後溝通追蹤、C-05 整體滿意度，正向率 80.0%、平均 4.20 分
（三項並列）。 
序位 題號／構面 有效 N 
正向人數／有效 
N 
正向率 平均分 
與組內基準之正向率差距
（百分點） 
與組內基準之平均分差
距（分） 
描述性觀察 
P1 C-02 辦訓安排明晰 5 4/5 80.0% 4.00 0.0 0.20 
與 C-03 平均分並列最低；正向率與其
餘各項相同 
P1 C-03 實作演練價值 5 4/5 80.0% 4.00 0.0 0.20 
與 C-02 平均分並列最低；正向率與其
餘各項相同 
P2 C-01 目標需求契合 5 4/5 80.0% 4.20 0.0 0.00 
與 C-04、C-05 並列為組內最高項目
（比較基準） 
P2 C-04 訓後溝通追蹤 5 4/5 80.0% 4.20 0.0 0.00 
與 C-01、C-05 並列為組內最高項目
（比較基準） 
P2 C-05 整體滿意度 5 4/5 80.0% 4.20 0.0 0.00 
與 C-01、C-04 並列為組內最高項目
（比較基準）

### PDF page 32

候選分析報告  DOCX 0095  /  I18-E02     •     第 32 頁 
【目標客戶端序位之解讀界線】 五項構面正向率同為 4/5＝80.0%，彼此之正向率差距為 0 個百分點，故
本群體之序位差異完全來自平均分（4.00 對 4.20，差距 0.20 分）。C-02、C-03 之並列最低平均分，僅屬
本組描述性排序，不得解讀為該二項之滿意度較低、正向率較低或存在群體差異；亦不得據以認定任何構
面之優劣或成因。 
【低分回覆計數與敏感度註記（供改善議題之穩健性判讀）】 學員端（n=14；「正向」為 4 或 5 分）： 
• L-03 演練操作價值：有效 n=14、正向 10 份，非正向 4 份。已識別者包括 1 份 2 分回覆（合成回覆 
SYN-L14）與 2 份 3 分回覆（SYN-L04、SYN-L11），合計 3 份；另 1 份非正向回覆於本包件未逐筆
識別。 
• L-04 講師支持度：已識別 1 份 3 分回覆（SYN-L11）；其餘非正向回覆於本包件未逐筆識別。 
• 情境演算（非重新施測結果）：若僅自 L-03 排除 SYN-L14 之 2 分回覆，L-03 之有效 n 為 13、總分 
53、平均約 4.08、正向 10/13＝76.9%；與組內基準 L-05 之正向率差距由 14.3 個百分點收斂為 8.8 
個百分點，平均分差距由 0.21 分收斂為 0.07 分。依 (2)(3) 之規則，L-03 仍為本群體 P1 序位。該演算
僅顯示本差距對單一 2 分回覆具敏感度，不得據以推論成因、不得視為重新施測或重測結果、不得作為
排除該回覆之依據。 
目標客戶端（n=5）：每題各 1 份非正向回覆（5 份中 4 份為正向），其分數值於本包件未逐筆識別；
n=5 意味單一填答者之評等即對應 20 個百分點之正向率差異，故本群體任何正向率數值之描述力有限。 
讀表原則：學員組的演練價值分數在本組資料中相對較低，適合作為後續討論議題；資料沒有提供開放式
回饋或原因證據，不能推定問題成因。目標客戶五個構面的正向人數比例相同，不能因此推論其意見一致
或代表其他對象。 
7.2 附圖 A：圖表解讀—學員端／目標客戶端正向率分軌比較（SAMPLE／SYNTHETIC）

### PDF page 33

候選分析報告  DOCX 0095  /  I18-E02     •     第 33 頁 
圖 A 標題：學員端與目標客戶端各構面正向率比較（合成資料 SAMPLE／SYNTHETIC；雙面板、同一 0–
100% 橫軸刻度） 
圖 A 圖面內容（兩面板分軌呈現，不合併）： 
• 左面板（學員端，n=14）：L-01 任務關聯性 78.6%、L-02 目標引導清晰 78.6%、L-03 演練操作價值 
71.4%、L-04 講師支持度 78.6%、L-05 整體滿意度 85.7%。 
• 右面板（目標客戶端，n=5）：C-01 目標需求契合 80.0%、C-02 辦訓安排明晰 80.0%、C-03 實作演
練價值 80.0%、C-04 訓後溝通追蹤 80.0%、C-05 整體滿意度 80.0%。 
圖 A 呈現規則：兩面板使用同一 0–100% 之橫軸刻度與同一比例基準；每個柱狀標註百分比與該面板之 n；
兩軌以面板標題、位置與標註區分，不得僅以顏色作為區辨依據；不得於圖面加入門檻線、目標值或趨勢
線。 
圖 A 警示：學員端 n=14、目標客戶端 n=5，樣本數與母體不同，兩軌數值不得合併、不得加權、不得解
讀為同一母體之整體滿意度，亦不得跨軌比較高低；目標客戶端五項同為 80.0%，圖面不得以柱高差異暗
示其有高下之別。 
圖 A 資料界限：圖面全部數值為 SAMPLE／SYNTHETIC 合成值，非真實施測結果，不代表任何已核定之
門檻、門檻值或考核等第；本圖不得作為核可、績效認定、評比或改善成效之依據，詳見 §7.2 排序規則與
敏感度註記。 
圖 A 文字替代說明（alt text 草案，供整合端產出可存取圖表時使用）：合成資料之兩軌正向率柱狀比較圖，
分為左右兩個面板且共用 0–100% 橫軸刻度。學員端（n=14）五項正向率介於 71.4%（L-03 演練操作價
值）與 85.7%（L-05 整體滿意度），其餘 L-01、L-02、L-04 均為 78.6%。目標客戶端（n=5）C-01 至 
C-05 五項正向率皆為 80.0%。兩群樣本數不同，未合併或加權計算；全部數值為合成示範資料。 
7.3 調查品質限制與統計邊界分析 
解讀本示範時須保留以下限制： 
1. 小樣本限制：學員有效樣本為 14、目標客戶有效樣本為 5。單一評分即可改變比例；結果僅描述提供的
合成樣本，不推論至任何實際母體。 
2. 未回覆原因未知：學員與目標客戶各有未回覆者，但原因未提供。不得推測其冷漠、滿意或不滿意，也
不得判定偏誤方向。 
3. 次分群抑制：若任何次分群有效樣本 n<5，不呈現該分群的百分比、平均、次數分布或個別值，只標示
樣本不足。本文沒有提供進一步分群資料。 
4. 追蹤子集限制：配對技能評量只有 12 組，另 2 組不可得且原因未知。配對子集可能與其他對象不同，不
得推論為全體表現。 
7.4 因果歸因之嚴格防線（Causal Attribution Defense） 
本報告將問卷評價與技能追蹤分開呈現。滿意度只反映提供的主觀評分；配對分數變化只描述 12 組合成觀
察值。缺少真實來源、比較設計及其他影響因素資料時，不得稱為訓練造成的能力或組織績效改變，也不
得將示範結果寫成協會實績。

### PDF page 34

候選分析報告  DOCX 0095  /  I18-E02     •     第 34 頁 
8. 機制作業控制、資料治理與持續改善追蹤 
8.1 驗收、暫緩與退件控制標準（提案作業參數） 
以下是候選資料控制條件，不是 TTQS 官方分數線，也不是已核定的協會政策。 
判定 可操作條件 處置與留痕 
可計算 
DOCX 與 I18-E02 綁定正確；來源、對象與邀
請分母可追溯；核心題有效值及 N/A 分別記
錄；公式可重算 
先由資料檢核者確認，再分群計算；保留原始
來源與計算式 
暫緩 
授權或填答告知未核實；分母、題碼、回收數
或更正來源不明；必要題漏填規則尚未核定；
原始值互相矛盾 
暫不對外形成結論；列出缺項、來源與補正責
任 
排除單份 
核心題漏填、重複答案無法辨識或記錄經核定
規則判為無效 
記錄排除理由；不得補造答案；分母依事先核
定的有效性定義重算 
抑制次分群 有效樣本 n<5 
不發布次分群百分比、平均、次數分布或個別
值；標示樣本不足 
不得升格 REAL 
沒有原始問卷、可核實日期、授權與實際結果
等必要證據 
維持 SAMPLE／SYNTHETIC 或 UNKNOWN；
不得把候選提案寫成實績 
正式使用前，須由有權者核定上述規則及其適用版本。 
8.2 異常更正、稽核軌跡（Audit Trail）與版本控制 
1. 保留原始值：更正不得覆寫原始回答。記錄原值、修正值、原因、時間及執行者來源；若沒有可核對原
件，維持 UNKNOWN 並暫緩。 
2. 差異核對：如使用雙人登錄，對所有不一致逐筆回查原始問卷，直到差異有記錄地解決；不以任意百分
比門檻取代核對。 
3. 版本管理：表單標示候選版本及生效依據。正式採用、修訂或停用須由有權者核定並保留版本變更紀錄；
不得因版本更新刪除受保護的歷史原始證據。 
8.3 資料安全、隱私與保存期限待核實 
本報告未取得協會現行資料保管位置、存取權限、加密狀態或保存期限，以上均為 UNKNOWN／NOT 
PROVIDED，不自行指定法定年限或聲稱已有伺服器、備份及保管人。 
如經授權採用，應在收集前由正式管理者確認資料目的、最少必要欄位、可存取角色、傳輸及儲存方式、
調閱紀錄、保存期限與銷毀程序，並核實適用規範。分析資料宜去識別化；身分對照表若確有必要，應與
分析資料分開並限權存取。

### PDF page 35

候選分析報告  DOCX 0095  /  I18-E02     •     第 35 頁 
8.4 持續改善行動追蹤流程與閉環驗證責任（PDCA） 
提供的合成學員資料中，演練操作價值為本群體五項中相對較低的構面。資料沒有開放式意見、根因調查、
會議或改善紀錄，因此原因與任何已核定行動均為 UNKNOWN。下表只提供可供審議的候選閉環流程；
未取得資料授權、正式決定及後續可比資料前，不得宣稱已查明根因、已改課或改善完成。 
候選作業流程，非本會現行規則；實際角色、授權與時點待核定。 表內角色碼只代表本文件的候選職能，
不代表已任命人員。 
階段／啟動條件 候選職能 必要操作與應留紀錄 暫緩／結案判準 
1 資料核實｜僅於資料可追
溯且授權者核准啟動；本
次核准證據 UNKNOWN 
ROLE-ANL（計算核對） 
ROLE-CRD（分母與來源
確認） 
依同版問卷重算本構面均
分及正向率，核對題碼、
分母、N/A 與排除理由；
留存來源、版本及計算式 
來源、分母或版本不能追
溯，或漏答規則未核定：
維持 UNKNOWN 並暫
緩；合成資料不得當作真
實改善立案依據 
2 根因查證｜第一階段可重
算，且已核准資料用途與
回饋方式 
ROLE-CRD（協調與中立
收集） 
ROLE-ANL（紀錄與分類） 
僅查核授權範圍內的課程
設計、教材、教學紀錄及
中立回饋；記錄來源、限
制、候選原因與尚未排除
的替代解釋，不追問個人
分數 
未授權、範圍不清或回饋
有誘導：暫緩並標 
UNKNOWN；替代解釋未
查清前不得認定根因 
3 方案比較｜根因有可追溯
資料支持，並完成限制說
明 
ROLE-ANL（證據與方案評
估） 
ROLE-CRD（資源及時程
彙整） 
提出至少兩個可行方案，
比較所需資源、對課程與
學員的影響、風險及限
制；保留依據與不採其他
方案的理由 
少於兩個可行方案，或比
較缺少依據／資源資訊：
暫緩送審並補件；不得自
行選定方案 
4 決定與指派｜方案比較完
成，且決定權限來源已核
實 
ROLE-DEC（審議與決定） 
ROLE-CRD（後續協調） 
由核實的授權者記錄採
用、退回或不採及理由、
待辦職能與期限；姓名、
職稱及日期只在取得真實
核准紀錄後填入 
權限或決定紀錄未核實：
僅保留候選建議，維持待
審／UNKNOWN；不得寫
成協會決議或已執行事項 
5 成效核驗與閉環｜已有核
准行動，且取得可比的後
續資料 
ROLE-ANL（重算與比對） 
ROLE-DEC（核驗結案） 
依相同題項、量尺、有效
規則及計算式，選取條件
可比的對象重測；留存各
期分母、未回覆與排除紀
錄、限制及原始來源 
無可比對象／資料或方法
不一致：維持待追蹤／
UNKNOWN，不得結案或
宣稱已改善；不得將前後
差異直接歸因課程效果

### PDF page 36

候選分析報告  DOCX 0095  /  I18-E02     •     第 36 頁 
8.5 改善建議追蹤表（SAMPLE／SYNTHETIC） 
下表是候選改善追蹤欄位示例，不代表真實立案、決議、責任指派或執行。日期與授權均未提供。本表依「可直接填寫」形式設計：合成觀察與改善建議屬候選內容；
責任職能、負責人、期限與狀態拆為四個獨立欄位，於正式授權後由有權者逐欄填寫，本版一律保持空白或 UNKNOWN。 
合成觀察 成因狀態 可供審議的改善建議 後續核驗方式 
建議責任職能（待核
定） 
建議負責人（待指
派） 
預定期限（待核定） 狀態（待核定） 
學員演練操作價值：
10/14 正向、平均 
3.93/5；SAMPLE／
SYNTHETIC 
UNKNOWN；
未提供開放式
意見或根因證
據 
若經正式授權，可檢視
練習說明、演練參與機
會與課程安排，並記錄
審議依據 
核定後於可比課程使用
同一題項，記錄正向
率、平均分、有效 N 
及回收有效率；若無後
續資料則保持待追蹤，
並說明量測範圍限制 
＿＿＿＿＿＿ 
（候選職能代碼：
ROLE-CRD／ROLE-
ANL／ROLE-DEC，見 
§3.1；實際指派未核
定） 
＿＿＿＿＿＿ 
（姓名未提供；
UNKNOWN，不得
填入推定人選） 
＿＿＿＿＿＿ 
（YYYY-MM-DD；
期限未定；
UNKNOWN） 
＿＿＿＿＿＿ 
（未立案、未執
行；待有權者核
定） 
欄位填寫規則（候選）：①「建議責任職能」僅填候選職能代碼，未經核定不得視為已指派；②「建議負責人」在取得正式授權指派前保持空白，不得填入任何姓名或
推定人選；③「預定期限」由有權者核定後以 YYYY-MM-DD 填寫，未定前保持空白且狀態為 UNKNOWN；④「狀態」僅可填候選值「未立案／追蹤中／待驗證／已
完成（附證據）」，無可核實後續資料時不得填「已改善」。 
空白追蹤登錄表（每次立案或追蹤各填一列；欄位同上，本版未填入任何實際值） 
追蹤編號 合成觀察／現象 改善建議 責任職能 負責人 期限（YYYY-MM-DD） 狀態 驗證日期 驗證結果與證據位置 
TRK-＿＿ ＿＿＿＿＿＿ ＿＿＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ 
TRK-＿＿ ＿＿＿＿＿＿ ＿＿＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ 
TRK-＿＿ ＿＿＿＿＿＿ ＿＿＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿ ＿＿＿＿

### PDF page 37

候選分析報告  DOCX 0095  /  I18-E02     •     第 37 頁 
本表之責任人選、期限、採納與否、立案狀態與改善結果，在取得有權者核定與後續可比資料前，一律為 
UNKNOWN 或待核定；不得由本表推論協會已立案、已指派或已完成改善。 
9. 相鄰文件與工作物差異 
本節對照 I18-E02 與相鄰文件的官方文字及工作物差異，供確認本候選報告的專屬用途；不表示本件已獲 
TTQS 評核通過。 
9.1 四項相鄰文件之文類與職責對照表 
DOCX ID 要求代碼 官方參考佐證文字 本報告與其界線 
0093 
I17D-E07（內部索引；官方
原頁未於本件核驗） 
未核驗的額外近鄰，不作本件官方
需求引據。 
僅作分件提醒；0095 不代替或複製
其他文件內容。 
0094 I18-E01 
口述目標客戶及學員認為訓練有其
功能，僅有滿意度調查，但未有具
體紀錄及評量。 
口述紀錄與評量工具不同於本件系
統及流程分析報告。 
0095 I18-E02 
建立目標客戶及學員滿意度調查機
制（系統及流程面）。 
本件專屬於滿意度調查機制設計、
流程、工具及分析口徑。 
0096 I18-E03 感謝函。 
感謝函為另一獨立文件；其出具者
及原件狀態須依實際來源核實，
0095 不代製或取代。 
以上區分只依正式要求文字及 Blueprint 的文件分工，不推定鄰近文件的真實內容、出具者或執行情況。 
9.2 與 0093 I17D-E07 雇主調查表的差異 
內部來源對照索引將 DOCX 0093／I17D-E07 列為相鄰工作物；本件未附其官方來源頁，故此處只作未核
驗的額外分件提醒，不把該項文字當作正式需求證據。0095 則依 §1.2 所列 I18-E02 檢核框，提供候選系
統設計與合成分析，兩者內容不互相替代。 
9.3 與 0094 I18-E01 口述訪談紀錄的差異 
I18-E01 對應的官方文字為口述目標客戶及學員認為訓練有其功能，但只有滿意度調查且缺少具體紀錄及評
量。0095 則對應 I18-E02 的系統與流程機制。兩項各自成件；本報告不將訪談原話、訪談人或真實口述資
料冒充為本件調查結果。 
9.4 與 0096 I18-E03 感謝函的差異 
I18-E03 的參考佐證文字為「感謝函」。其實際出具者、內容與原件狀態須由合法來源核實。0095 是候選
機制分析報告，不得冒充、代製或填補 0096 的真實原件。

### PDF page 38

候選分析報告  DOCX 0095  /  I18-E02     •     第 38 頁 
9.5 升格真實（REAL）所需外部佐證路徑與索引清單 
本索引逐項對應 Unique Blueprint real_data_required 之升格類別（正式日期；真實人名／角色；核准／簽章；真實班次／課程；實際數字／比例；真實附件與檔
案位置），並就本件之實際需求細分為 8 個可核對項目。每列均載明所需真實來源、可對應之事實粒度清冊鍵，以及本次取得狀態；目前清冊鍵以 
qa/0095_R11_synthetic_replacement_register.csv 為準；R08 CSV／manifest 保留為歷史原件，不作為本版頁碼依據（R07 版清冊 
qa/0095_R07_synthetic_replacement_register.csv 為歷史標的，維持不變）。 
# 
升格核實項目（對應 Blueprint 
real_data_required 類別） 
需要的真實來源 對應清冊鍵 本次狀態 
1 
真實作者與覆核者姓名／角色（真實人名／角
色） 
協會編製者與正式覆核者之具名紀錄、職稱及授
權依據 
UNK-0095-
UNK_AUTHOR_REVIEWER_IDENTITY（R07 新
增）；PROP-0095-ROLE-CRD、PROP-0095-
ROLE-COL、PROP-0095-ROLE-ANL、PROP-
0095-ROLE-DEC 僅為候選職能標籤，非人名 
未提供；
UNKNOWN 
2 核准／簽章原件（核准／簽章） 
有權核准者之核定文件、簽章或會議決議原件及
其生效依據 
UNK-0095-UNK_APPROVAL_SIGNATURE
（R07 新增）；UNK-0095-
UNK_REAL_SYSTEM 
未提供；
UNKNOWN 
3 正式／生效日期（正式日期） 
制度或工具之核定發布日、生效日，以及真實問
卷之施測與回收日期 
UNK-0095-UNK_FORMAL_EFFECTIVE_DATE
（R07 新增；本版 REAL 日期欄位留白，Tool-
A／Tool-B REAL 空白日期欄位見 R11 PDF 
pp.11、15；本索引第 3 列見 R11 PDF 
p.38）；SYN-0095-COURSE_DATE、SYN-
0095-FOLLOWUP_DATE 為合成日期 
未提供；
UNKNOWN 
4 真實班次／課程／期別（真實班次／課程） 
經核實之課程計畫、辦訓名冊、期別／班次識別
與時數 
UNK-0095-UNK_REAL_COURSE_COHORT
（R07 新增）；SYN-0095-CASE_ID、SYN-
0095-COURSE_NAME、SYN-0095-
COURSE_HOURS 為合成值 
未提供；
UNKNOWN

### PDF page 39

候選分析報告  DOCX 0095  /  I18-E02     •     第 39 頁 
# 
升格核實項目（對應 Blueprint 
real_data_required 類別） 
需要的真實來源 對應清冊鍵 本次狀態 
5 
實際合格／邀請／回收／有效份數與原始問卷
（實際數字／比例） 
可核對之對象清冊、發放／送達紀錄、回收清
冊、有效性判定紀錄與原始問卷（如存在且有權
使用） 
SYN-0095-LEARNER_INVITED、SYN-0095-
LEARNER_RETURNED、SYN-0095-
LEARNER_VALID、SYN-0095-
CUSTOMER_INVITED、SYN-0095-
CUSTOMER_RETURNED、SYN-0095-
CUSTOMER_VALID、UNK-0095-
UNK_NONRESPONSE_REASON、UNK-0095-
UNK_INVALID_ID、UNK-0095-
UNK_INVALID_OTHER_SCORES、UNK-0095-
UNK_REAL_RESPONSES 
未提供；
UNKNOWN 
6 實際計算與分析（實際數字／比例） 
與原始回答可追溯連結之資料表、公式、計算過
程與分析覆核記錄 
L-01–L-05 與 C-01–C-05 各題 SUM／MEAN／
POSN／POSRATE，共 40 個題項鍵；另有 5 個
分軌分母／回收衍生鍵（SYN-0095-
LEARNER_RETURN_RATE、
LEARNER_VALID_RATE、
CUSTOMER_RETURN_RATE、
CUSTOMER_VALID_RATE、
CUSTOMER_VALID_RETURN_SHARE）及 8 個
訓後追蹤計算鍵。全清冊共 53 個 
DERIVED_SYNTHETIC_METRIC 鍵，完整鍵名
與值以 R11 CSV／manifest 為準；UNK-0095-
UNK_REAL_RESPONSES 
未提供；
UNKNOWN

### PDF page 40

候選分析報告  DOCX 0095  /  I18-E02     •     第 40 頁 
# 
升格核實項目（對應 Blueprint 
real_data_required 類別） 
需要的真實來源 對應清冊鍵 本次狀態 
7 實際改善決定、責任、期限與後續追蹤 
有權者之決定原件、責任指派、期限核定及後續
可比資料 
UNK-0095-
UNK_IMPROVEMENT_ORIGINALS（R07 新
增）；UNK-0095-UNK_REAL_RESPONSES；
§8.5 之責任／負責人／期限／狀態欄位現為空
白 
未提供；
UNKNOWN 
8 
真實附件與經授權之儲存／存取路徑（真實附件
與檔案位置） 
由正式資料管理者核實之檔案位置、存取權限、
調閱紀錄與保存規則 
UNK-0095-
UNK_ATTACHMENT_STORAGE_LOCATION
（R07 新增） 
未提供；
UNKNOWN

### PDF page 41

候選分析報告  DOCX 0095  /  I18-E02     •     第 41 頁 
不得以本報告虛構路徑、組織名稱、人員或簽章替代上述原件；亦不得以上表任一列之 UNKNOWN 狀態
推論該項目不存在或本會未曾辦理。必要來源未提供時，維持 UNKNOWN，不升格 REAL。本索引僅列示
升格路徑與所需來源，不對原始點協會評分，亦不宣稱任何項目已取得。 
R08 歷史版本補充說明（定位與完整性界線；不代表 R11 頁次）： (1) 定位：UNK-0095-
UNK_FORMAL_EFFECTIVE_DATE 之 document_location 已由「§4.2 Tool-B real response-date and 
return-date fields；PDF pp. 10–11, 32」更正為實際存在於本版表單之 REAL 空白日期欄位（§4.1 Tool-A
「實際填答日期」；§4.2 Tool-B「邀請發送日期」「送達日期」「實際填答日期」「回收日期」），並以 
§9.5 第 3 列對應之。該欄位皆為空白，本版未填入任何真實日期，不得聲稱已有既存日期值。 (2) 頁碼錨
點：此段只記錄歷史 R08 CSV 的定位基礎；R08 列位置僅以 R08 匯出為準，不得表示已對照 R10 或 R11。
R11 的列位置以新 R11 CSV、manifest 與最終 R11 Word 匯出 PDF 交叉核對。 (3) 完整性：R08 清冊共 
211 筆資料列、13 欄與唯一 register_key。R06 原有 208 鍵，移除 3 個不再使用的合併／合併正向率鍵後
保留 205 鍵，再新增 6 個 UNKNOWN 升格索引鍵，因此 208 − 3 + 6 = 211；205 = 208 − 3。R06、
R07 歷史 CSV 與 manifest 均維持原件，不回溯改寫；本版實際位元組與鍵集合以隨附 manifest 為準。 
10. 合成事實替換登錄表與文件版本 
本報告所用 SAMPLE／SYNTHETIC 資料附有事實粒度 CSV。R08 register（211 筆、13 欄；CSV SHA-
256 203583e4aa51f6c370b5dcee904922856c5d118b02d6184a5518b1174840202c；manifest SHA-
256 df1b2517385b9768e438e6c771552bffe6917e5d0abe20d8a1ca4071cf6717c0）為歷史原件，列
位置綁定 43 頁 R08 匯出，未核對 R10／R11 頁次。R11 current register 為 
qa/0095_R11_synthetic_replacement_register.csv（211 筆、13 欄；CSV SHA-256 
df25ec51db00707764cd488b7de44d0b686a956dd4df1433f6c159010ab3b3ee；manifest SHA-256 
45357ed001e8720a129883924630e9d8125f9dc9e0a9f7fd1cefc2d774008c28）。R11 頁碼清冊已逐
列依最終 44 頁 R11 PDF 校核；PDF exact SHA 見外部視覺 QA 收據；R08 原件與歷史鍵集合均不回溯改
寫。R06 原有 208 個鍵，R08 移除 3 個合併／合併正向率衍生鍵並保留 205 鍵，再新增 6 個 UNKNOWN 
升格索引鍵，合計 211 筆、13 欄。§6.3.3 分軌解讀學員與目標客戶；任一 CSV 或 manifest SHA 不符即停
止使用並重新取得完整套件。清冊不含個人真實資料。 
10.1 附件索引 
附件 檔案或來源 用途與核對方式 
A 
qa/0095_R08_synthetic_replacement_register.cs
v（歷史） 
211 筆、13 欄；CSV SHA-256 
203583e4aa51f6c370b5dcee904922856c5d118
b02d6184a5518b1174840202c（64 字元；R10 
多出 1 個尾碼 a）；manifest SHA-256 
df1b2517385b9768e438e6c771552bffe6917e5
d0abe20d8a1ca4071cf6717c0；綁定 43 頁 R08 
PDF，列位置未對 R10/R11 核驗。

### PDF page 42

候選分析報告  DOCX 0095  /  I18-E02     •     第 42 頁 
附件 檔案或來源 用途與核對方式 
A-1 
qa/0095_R08_synthetic_replacement_register_
manifest.json 
列數、欄數、唯一鍵、歷史鍵集合與來源 SHA；
SHA-256 
df1b2517385b9768e438e6c771552bffe6917e5
d0abe20d8a1ca4071cf6717c0。 
A-2 
qa/0095_R07_synthetic_replacement_register.cs
v 
R07 歷史標的（未回溯改寫）；214 筆、13 欄；
SHA-256 
ba5e5e1c8f0191e7298502976e5f9d02a164d4e7
99a1de2a7f1514f66a7fc3d4。 
A-3 
qa/0095_R07_synthetic_replacement_register_
manifest.json 
R07 歷史標的（未回溯改寫）；SHA-256 
7d90e5af2e2259c0a8e9ea4246ca3be848cd8c57
cf68962e751be4d90a0cb01c。 
A-4 
qa/0095_R11_synthetic_replacement_register.cs
v 與 manifest 
211 筆、13 欄；CSV SHA-256 
df25ec51db00707764cd488b7de44d0b686a95
6dd4df1433f6c159010ab3b3ee；manifest 
SHA-256 
45357ed001e8720a129883924630e9d8125f9dc
9e0a9f7fd1cefc2d774008c28；頁碼逐列依最終 
44 頁 R11 Word 匯出核對，PDF exact SHA 記於
外部視覺 QA 收據。 
B TTQS 查核佐證文件資料表—訓練機構版，第 6 頁 
I18-E02 檢核框原文；SHA-256 見 §1.2，官方下載
頁 type_id=5。 
C 
TTQS 人才發展品質管理評核表—訓練機構版，第 
4 頁 
指標 18 的 1 至 4 分評分標準；SHA-256 見 §1.3，
官方下載頁 type_id=4。 
D 0095_R11_CANDIDATE.pdf 
本 DOCX 的同版 Word 匯出全文；PDF SHA-256 
及頁數由外部 visual QA 收據綁定。 
E 
0095_R11 technical, visual and semantic review 
receipts 
R10 歷史獨立語意審查：OpenCode CLI v2.0.32，
requested route opencode/minimax-m3.1-
flash-free；reported model ID minimax-m3.1-
flash-free，provider model identity 
UNKNOWN；Reviewed DOCX SHA-256 
4c52fe99188b726f1e62754484aec8604abae83
d73643c46a263f7e6a7ee3630；結果 PARTIAL、
0 blocking、5 nonblocking。R10 為 packet-
only，未重算 DOCX、未渲染／目視；完整原始回
覆及收據見套件。R11 的技術、視覺及獨立語意結
論只以套件中綁定 R11 exact DOCX SHA 的收據為
準；本附件索引不自行宣告 PASS。

### PDF page 43

候選分析報告  DOCX 0095  /  I18-E02     •     第 43 頁 
10.2 文件版本與覆核紀錄 
版本 日期 變更與審查狀態 
R05 2026-10-20 
OpenCode CLI v2 exact-SHA 語意審查結果為 PARTIAL，無 
blocking finding；14 項低度／資訊性觀察已保留於 R05 原始審查回
覆。該審查未做獨立視覺或 DOCX 位元組驗證；模型供應端身分 
UNKNOWN。 
R06 2026-10-20 
依 R05 具體 finding 修正官方級距與證據界線、來源雜湊、施測時
點、核心題有效規則、計算精度、合併分母、客戶均分並列、附件索
引及版本紀錄；候選狀態，新的 exact-SHA 覆核依本版套件收據記
錄。 
R07 2026-10-20 
依 R06 review 修正官方來源、公式／分母、REAL 日期欄、清冊索引
及改善追蹤；修復跨頁版面。R07 exact-SHA 語意審查 PARTIAL、0 
blocking、10 findings；原始回覆：
review/0095_R07_opencode_minimax_R01_response.json。 
R08 2026-10-20 
依 R07 finding 修正 REAL 空白欄位與清冊定位；§6.3.3 改為分軌、不
合併推論，移除 3 項不再使用的合併計算；§8.4 增列候選 PDCA 五階
段及暫緩／結案判準。R08 清冊 211 筆；保留 R06、R07 歷史原件。
R08 exact-SHA 語意審查為 PARTIAL、無 blocking finding。 
R09 2026-10-20 
依 R08 exact-SHA review PARTIAL 精確修正 §1.4 導引及合成班次文
字；問卷、數據及 R08 register／manifest 不變。R08 NB-R08-02 經 
R06／R08 鍵集合核對為誤判。R09 exact-SHA OpenCode review 為 
PARTIAL、0 blocking、5 nonblocking；原始回覆及收據見外部套
件。provider model identity UNKNOWN；本件仍為 
CANDIDATE。 
R10 2026-10-20 
依 R09 exact-SHA review 精確修正 §1.4 頁次、R06→R08 清冊算式
及 §9.5 衍生鍵分類；R08 CSV／manifest、問卷及示範數值不變。
R10 DOCX SHA-256 
4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7
e6a7ee3630；技術與視覺檢查完成，獨立語意審查 PARTIAL、0 
blocking、5 nonblocking，provider model identity UNKNOWN；
不升格正式接受。 
R11 2026-10-20 
修正兩份官方來源的 parent PDF／精確頁擷取本 SHA 標示；更正 
Appendix A 的 R08 CSV 64 字元 SHA；另以 R11 register 取代其作
為 current page locator 清冊，R08 歷史原件不改寫；依 R10 finding 
修正 §1.4／§9.5 頁碼鏈結。保留問卷、示範資料、計算與政策內容不
變。R11 為候選；技術、視覺、獨立語意驗收以外部 exact-SHA 收據
為準。 
歷史覆核標的：R06 DOCX SHA 
71398b1095d2987a1e0064657a1f6b942fe6f875697b5f99443fb9002e82efa4；R07 SHA

### PDF page 44

候選分析報告  DOCX 0095  /  I18-E02     •     第 44 頁 
ba6100f3aaeb547ad9d3f5ecfa1f30f563424fc368c28015efb00ff076cb9394；R08 SHA 
e9322191eb70554311f506db2eedf0800c1e786012a6b854cbe4b31864ce31a1（OpenCode exact-SHA 
review PARTIAL、0 blocking、5 nonblocking；response 
review/0095_R08_opencode_minimax_R01_response.json，SHA 
914a9d8f34186b5f7bbfec0d8c1183d81ff4435bf3adb2ddc0261f42e5189a89）。R06–R08 原件及收據
均維持不變；R09 exact-SHA 審查結果 PARTIAL、0 blocking、5 nonblocking，provider model 
identity UNKNOWN；R10 exact DOCX SHA-256 
4c52fe99188b726f1e62754484aec8604abae83d73643c46a263f7e6a7ee3630 的 OpenCode CLI 
v2.0.32 語意審查為 PARTIAL、0 blocking、5 nonblocking，provider model identity UNKNOWN；
R10 原始 response SHA-256 
6fe4399f240b92cd7f19e742376ebe46eb139dfe175c0ba0f0b6ba5da85f8ffd；R11 結果以套件中綁定
最終 R11 exact DOCX SHA 的原始回覆及收據為準。 
本文件的協會編製者、正式覆核者、採用權責者及其簽署均未提供，狀態為 UNKNOWN；不得以工具路
由或系統輸出冒充協會人員、正式核准或簽章。獨立語意審查結果應以外部套件中綁定本版 DOCX SHA 的
原始回覆與收據為準，不得由本表替代。 
報告總結說明與覆核聲明 
 
候選狀態與使用界線 
本報告為 I18-E02 候選機制、問卷及 SAMPLE／SYNTHETIC 示例，不證明協會採納、實施或任何真實
調查／評核。真實資料與授權須依原件核實；未提供者維持 UNKNOWN。本文為 CANDIDATE；審查
僅對指定 DOCX exact SHA 有效，不代表協會核准或 TTQS 通過。

## Full 211-row synthetic replacement register

```csv
register_key,doc_id,requirement_id,official_checkbox,fact_status,fact_type,value,unit,document_location,source_or_formula,real_replacement_or_authorization_required,real_source_status,notes
SYN-0095-CASE_ID,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_case_id,SYN-TRN-01,identifier,§6 opening / case identifier；PDF p. 22,Provided by 0095 writer packet; SAMPLE/SYNTHETIC.,"If used for a real case, replace with authorized source case ID.",NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-COURSE_NAME,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_course_name,志工服務溝通與紀錄練習,text,§6 opening / course name；PDF p. 22,Provided synthetic scenario in writer packet.,Replace with verified course plan/records.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-COURSE_HOURS,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_course_duration,6,hours,§6 opening / duration；PDF p. 22,Provided synthetic scenario in writer packet.,Replace with approved attendance/course record.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-COURSE_DATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_date,2026-07-11,date,"§6 opening; §4.1 sample form; §4.2 sample form；PDF pp. 11, 15, 22",Provided synthetic scenario in writer packet.,Replace with verified course date and source record.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-FOLLOWUP_DATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_date,2026-08-10,date,§6 opening / follow-up date；PDF p. 22,Provided synthetic scenario; 30 days after 2026-07-11.,Replace with dated original follow-up records.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-LEARNER_INVITED,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_population_count,18,persons,§6.1 / learner sample description；PDF pp. 23–24,Writer packet provided n=18. SAMPLE/SYNTHETIC scenario interprets this as invitations delivered or handed over under POP_INVITED; dispatch-only count not provided.,Replace with eligible learner roster and dispatch/delivery log.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence. Delivered/handed-over count used for the return-rate denominator; dispatch-only count UNKNOWN/NOT PROVIDED.
SYN-0095-LEARNER_RETURNED,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_return_count,15,forms,§6.1 / learner sample description；PDF pp. 23–24,Writer packet provided 15 returns.,Replace with original return log and forms.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-LEARNER_NONRESPONSE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_nonresponse_count,3,persons,§6.1 / learner sample description；PDF pp. 23–24,18 invited minus 15 returned.,Replace with verified invitation and return logs; response reasons only if recorded.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-LEARNER_INVALID,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_invalid_count,1,forms,§6.1 / learner sample description；PDF pp. 23–24,Writer packet provided 1 invalid return.,Replace with original form and pre-approved validity review record.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-LEARNER_VALID,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_valid_count,14,forms,§6.1 / learner sample description；PDF pp. 23–24,15 returned minus 1 invalid.,Replace with verified return set and validity log.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-INVALID_REASON,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_invalid_reason,核心整體滿意度題 L-05 缺漏,text,§6.1 / invalid form narrative；PDF pp. 23–24,Writer packet provided one missing overall core item; identity and other item values not supplied.,Replace with source form and authorized exclusion rationale; do not infer person identity.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-CUSTOMER_INVITED,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_population_count,6,persons,§6.2 / target customer sample description；PDF pp. 24–25,Writer packet provided n=6. SAMPLE/SYNTHETIC scenario interprets this as invitations delivered or handed over under POP_INVITED; dispatch-only count not provided.,Replace with verified eligible target-customer roster and delivery log.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence. Delivered/handed-over count used for the return-rate denominator; dispatch-only count UNKNOWN/NOT PROVIDED.
SYN-0095-CUSTOMER_RETURNED,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_return_count,5,forms,§6.2 / target customer sample description；PDF pp. 24–25,Writer packet provided 5 returns.,Replace with original return log and forms.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-CUSTOMER_NONRESPONSE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_nonresponse_count,1,persons,§6.2 / target customer sample description；PDF pp. 24–25,6 invited minus 5 returned.,Replace with verified invitation and return logs; response reason only if recorded.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
SYN-0095-CUSTOMER_VALID,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,synthetic_valid_count,5,forms,§6.2 / target customer sample description；PDF pp. 24–25,Writer packet provided 5 valid returns.,Replace with verified return set and validity log.,NOT_PROVIDED,SAMPLE/SYNTHETIC only; not association evidence.
UNK-0095-UNK_ORG,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,target-customer organization not provided,status,§4.2 form and §6.2 narrative；PDF pp. 24–25,Explicitly marked UNKNOWN in candidate narrative.,Only replace with a source-authorized real organization name; otherwise remain UNKNOWN.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_RESPONDER_ROLE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,actual respondent roles not provided,status,§4.2 form; §6.2 data；PDF pp. 24–25,Explicitly marked UNKNOWN in candidate narrative.,Only replace from source records; do not infer role from survey code.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_NONRESPONSE_REASON,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,nonresponse reasons not provided,status,§6.1 and §6.2 narratives；PDF pp. 23–25,Explicitly marked UNKNOWN in candidate narrative.,Use only documented voluntary disclosure; otherwise UNKNOWN.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_INVALID_ID,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,invalid returned form identity not provided,status,§6.1 narrative；PDF pp. 23–24,Explicitly marked UNKNOWN in candidate narrative.,Do not add a person or key absent original source.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_INVALID_OTHER_SCORES,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,other values on invalid returned form not provided,status,§6.1 narrative；PDF pp. 23–24,Explicitly marked UNKNOWN in candidate narrative.,Do not reconstruct missing respondent scores.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_REAL_SYSTEM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,association current survey system/adoption/approval unknown,status,§1 and §2.4；PDF pp. 1–6,Explicitly marked UNKNOWN in candidate narrative.,Replace only with current authorized system/policy and approval source.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
UNK-0095-UNK_REAL_RESPONSES,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,"real survey population, forms, analysis and decisions not provided",status,"§6.1–§6.4 synthetic response examples; §9.5 rows 5–6；PDF pp. 23–29, 39",Explicitly marked UNKNOWN in candidate narrative.,Replace only with lawfully accessible primary records; keep sensitive originals protected.,NOT_PROVIDED,Not an invented value; listed to prevent inference.
SYN-0095-SYN-L01-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L01 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L01-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L01 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L01-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L01 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L01-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L01 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L01-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L01 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L02-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L02 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L02-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L02 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L02-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L02 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L02-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L02 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L02-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L02 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L03-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L03 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L03-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L03 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L03-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L03 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L03-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L03 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L03-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L03 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L04-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L04 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L04-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L04 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L04-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L04 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L04-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L04 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L04-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L04 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L05-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L05 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L05-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L05 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L05-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L05 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L05-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L05 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L05-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L05 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L06-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L06 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L06-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L06 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L06-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L06 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L06-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L06 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L06-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L06 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L07-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L07 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L07-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L07 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L07-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L07 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L07-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L07 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L07-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L07 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L08-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L08 / L-01 任務關聯性；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L08-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L08 / L-02 目標引導清晰；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L08-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L08 / L-03 演練操作價值；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L08-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L08 / L-04 講師支持度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L08-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L08 / L-05 整體滿意度；PDF p. 23,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L09-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L09 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L09-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L09 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L09-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L09 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L09-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L09 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L09-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L09 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L10-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L10 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L10-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L10 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L10-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L10 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L10-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L10 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L10-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L10 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L11-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L11 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L11-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L11 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L11-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L11 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L11-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L11 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L11-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L11 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L12-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L12 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L12-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L12 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L12-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L12 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L12-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L12 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L12-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,5,score (1-5),§6.1 learner table / SYN-L12 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L13-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L13 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L13-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L13 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L13-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L13 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L13-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L13 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L13-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,4,score (1-5),§6.1 learner table / SYN-L13 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L14-L-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,2,score (1-5),§6.1 learner table / SYN-L14 / L-01 任務關聯性；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L14-L-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L14 / L-02 目標引導清晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L14-L-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L14 / L-03 演練操作價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L14-L-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,3,score (1-5),§6.1 learner table / SYN-L14 / L-04 講師支持度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L14-L-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,learner_satisfaction_score,2,score (1-5),§6.1 learner table / SYN-L14 / L-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C01-C-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C01 / C-01 目標需求契合；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C01-C-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C01 / C-02 辦訓安排明晰；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C01-C-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C01 / C-03 實作演練價值；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C01-C-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C01 / C-04 訓後溝通追蹤；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C01-C-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C01 / C-05 整體滿意度；PDF p. 24,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C02-C-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C02 / C-01 目標需求契合；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C02-C-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C02 / C-02 辦訓安排明晰；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C02-C-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C02 / C-03 實作演練價值；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C02-C-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C02 / C-04 訓後溝通追蹤；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C02-C-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C02 / C-05 整體滿意度；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C03-C-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C03 / C-01 目標需求契合；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C03-C-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C03 / C-02 辦訓安排明晰；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C03-C-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C03 / C-03 實作演練價值；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C03-C-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C03 / C-04 訓後溝通追蹤；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C03-C-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,5,score (1-5),§6.2 target customer table / SYN-C03 / C-05 整體滿意度；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C04-C-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,3,score (1-5),§6.2 target customer table / SYN-C04 / C-01 目標需求契合；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C04-C-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,3,score (1-5),§6.2 target customer table / SYN-C04 / C-02 辦訓安排明晰；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C04-C-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,3,score (1-5),§6.2 target customer table / SYN-C04 / C-03 實作演練價值；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C04-C-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,3,score (1-5),§6.2 target customer table / SYN-C04 / C-04 訓後溝通追蹤；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C04-C-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,3,score (1-5),§6.2 target customer table / SYN-C04 / C-05 整體滿意度；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C05-C-01,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C05 / C-01 目標需求契合；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C05-C-02,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C05 / C-02 辦訓安排明晰；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C05-C-03,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C05 / C-03 實作演練價值；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C05-C-04,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C05 / C-04 訓後溝通追蹤；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-C05-C-05,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,target_customer_satisfaction_score,4,score (1-5),§6.2 target customer table / SYN-C05 / C-05 整體滿意度；PDF p. 25,Value supplied in writer packet; included in the displayed raw matrix.,Replace with legally accessible original questionnaire response and verified item mapping.,NOT_PROVIDED,
SYN-0095-SYN-L01-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,4,score (0-10),§6.4 paired table / SYN-L01 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L01-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,7,score (0-10),§6.4 paired table / SYN-L01 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L02-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,5,score (0-10),§6.4 paired table / SYN-L02 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L02-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,8,score (0-10),§6.4 paired table / SYN-L02 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L03-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,6,score (0-10),§6.4 paired table / SYN-L03 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L03-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,8,score (0-10),§6.4 paired table / SYN-L03 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L04-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,3,score (0-10),§6.4 paired table / SYN-L04 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L04-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,6,score (0-10),§6.4 paired table / SYN-L04 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L05-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,4,score (0-10),§6.4 paired table / SYN-L05 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L05-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,7,score (0-10),§6.4 paired table / SYN-L05 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L06-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,5,score (0-10),§6.4 paired table / SYN-L06 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L06-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,8,score (0-10),§6.4 paired table / SYN-L06 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L07-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,6,score (0-10),§6.4 paired table / SYN-L07 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L07-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,8,score (0-10),§6.4 paired table / SYN-L07 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L08-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,2,score (0-10),§6.4 paired table / SYN-L08 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L08-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,5,score (0-10),§6.4 paired table / SYN-L08 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L09-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,4,score (0-10),§6.4 paired table / SYN-L09 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L09-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,7,score (0-10),§6.4 paired table / SYN-L09 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L10-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,5,score (0-10),§6.4 paired table / SYN-L10 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L10-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,8,score (0-10),§6.4 paired table / SYN-L10 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L11-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,3,score (0-10),§6.4 paired table / SYN-L11 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L11-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,6,score (0-10),§6.4 paired table / SYN-L11 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L12-PRE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_pre_score,4,score (0-10),§6.4 paired table / SYN-L12 / pre；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original pre-assessment record.,NOT_PROVIDED,
SYN-0095-SYN-L12-POST30,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,SYNTHETIC_FACT,followup_30day_score,7,score (0-10),§6.4 paired table / SYN-L12 / 30-day；PDF p. 28,Writer packet supplied paired synthetic value.,Replace with dated and authorized original 30-day assessment record.,NOT_PROVIDED,
PROP-0095-SCALE_1_TO_5,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,rating scale,1–5,scale points,§4.1 Tool-A and §4.2 Tool-B sample tools；PDF pp. 10–17,Candidate questionnaire design.,Requires formal adoption/approval; not an association fact.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-POSITIVE_4_5,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,positive response definition,4–5,score values,"§4.3 and §5.2；PDF pp. 18–19, 21",Candidate calculation definition.,Requires formal adoption/approval; not an association fact.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-SUPPRESS_LT5,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,small subgroup suppression,n<5,sample-size rule,"§5.1, §7.3, §8.1；PDF pp. 20, 33–34",Candidate privacy/reporting control.,Requires documented authorization and risk review; not an association fact.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-FOLLOWUP_30D,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,follow-up interval,30,days,§6.4；PDF pp. 28–29,Synthetic worked example parameter from writer packet.,Replace with authorized real follow-up schedule; remains sample in this report.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-OUTCOME_THRESHOLD_7,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,illustrative follow-up threshold,>=7,score on 0-10,§6.4 and §6.4.1；PDF pp. 28–29,Writer packet supplied illustrative threshold.,Requires valid assessment rubric and authorization before real use.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-CORE_L05_VALIDITY,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,core-item validity rule,L-05 required,candidate rule,"§4.3, §5.1, §6.1；PDF pp. 18–20, 23",Candidate validity rule; one synthetic returned form has missing L-05.,Requires pre-approved validity criteria and source form before real use.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-NA_EXCLUDED,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_CONTROL,NA handling,N/A excluded from item denominator,candidate rule,"§4.3, §5.1, §5.2；PDF pp. 18–21",Candidate rule.,Requires tool/rule approval before real use.,NOT_PROVIDED,"Proposal, not a synthetic association practice."
PROP-0095-ROLE-CRD,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_ROLE,candidate_functional_role,調查協調,role label,§3.1 role matrix；PDF p. 6,Proposed role label; no person or appointment provided.,"If adopted, replace/confirm with authorized association role assignment; do not invent a named individual.",NOT_PROVIDED,
PROP-0095-ROLE-COL,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_ROLE,candidate_functional_role,中立收集,role label,§3.1 role matrix；PDF p. 6,Proposed role label; no person or appointment provided.,"If adopted, replace/confirm with authorized association role assignment; do not invent a named individual.",NOT_PROVIDED,
PROP-0095-ROLE-ANL,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_ROLE,candidate_functional_role,資料檢核與分析,role label,§3.1 role matrix；PDF p. 6,Proposed role label; no person or appointment provided.,"If adopted, replace/confirm with authorized association role assignment; do not invent a named individual.",NOT_PROVIDED,
PROP-0095-ROLE-DEC,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,PROPOSED_ROLE,candidate_functional_role,授權審議,role label,§3.1 role matrix；PDF p. 6,Proposed role label; no person or appointment provided.,"If adopted, replace/confirm with authorized association role assignment; do not invent a named individual.",NOT_PROVIDED,
SYN-0095-LEARNER-L-01-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,57,score points,§6.3.1 calculation / 任務關聯性；PDF p. 26,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-LEARNER-L-01-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.07,score / 5,§6.3.1 calculation / 任務關聯性；PDF p. 26,"57/14, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-01-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,11,responses,§6.3.1 calculation / 任務關聯性；PDF p. 26,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-01-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,78.6,percent,§6.3.1 calculation / 任務關聯性；PDF p. 26,"11/14*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-02-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,56,score points,§6.3.1 calculation / 目標引導清晰；PDF p. 26,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-LEARNER-L-02-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.00,score / 5,§6.3.1 calculation / 目標引導清晰；PDF p. 26,"56/14, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-02-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,11,responses,§6.3.1 calculation / 目標引導清晰；PDF p. 26,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-02-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,78.6,percent,§6.3.1 calculation / 目標引導清晰；PDF p. 26,"11/14*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-03-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,55,score points,§6.3.1 calculation / 演練操作價值；PDF p. 26,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-LEARNER-L-03-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,3.93,score / 5,§6.3.1 calculation / 演練操作價值；PDF p. 26,"55/14, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-03-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,10,responses,§6.3.1 calculation / 演練操作價值；PDF p. 26,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-03-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,71.4,percent,§6.3.1 calculation / 演練操作價值；PDF p. 26,"10/14*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-04-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,56,score points,§6.3.1 calculation / 講師支持度；PDF p. 26,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-LEARNER-L-04-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.00,score / 5,§6.3.1 calculation / 講師支持度；PDF p. 26,"56/14, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-04-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,11,responses,§6.3.1 calculation / 講師支持度；PDF p. 26,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-04-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,78.6,percent,§6.3.1 calculation / 講師支持度；PDF p. 26,"11/14*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-05-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,58,score points,§6.3.1 calculation / 整體滿意度；PDF p. 26,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-LEARNER-L-05-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.14,score / 5,§6.3.1 calculation / 整體滿意度；PDF p. 26,"58/14, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-05-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,12,responses,§6.3.1 calculation / 整體滿意度；PDF p. 26,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER-L-05-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,85.7,percent,§6.3.1 calculation / 整體滿意度；PDF p. 26,"12/14*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-01-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,21,score points,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-01-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.20,score / 5,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"21/5, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-01-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,4,responses,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-01-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,80.0,percent,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"4/5*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-02-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,20,score points,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-02-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.00,score / 5,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"20/5, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-02-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,4,responses,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-02-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,80.0,percent,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"4/5*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-03-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,20,score points,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-03-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.00,score / 5,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"20/5, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-03-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,4,responses,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-03-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,80.0,percent,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"4/5*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-04-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,21,score points,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-04-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.20,score / 5,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"21/5, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-04-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,4,responses,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-04-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,80.0,percent,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"4/5*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-05-SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_score_sum,21,score points,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Sum the displayed per-response scores for this item.,Recalculate from verified original questionnaires; do not carry synthetic value into REAL reporting.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-05-MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,item_mean,4.20,score / 5,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"21/5, rounded to 2 decimals.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-05-POSN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_count,4,responses,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,Count values 4 or 5 in the displayed valid responses.,Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-CUSTOMER-C-05-POSRATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,positive_rate,80.0,percent,§6.3.2 目標客戶端各題計算表（合計／平均／正向人數／正向率）；PDF p. 27,"4/5*100, rounded to 1 decimal.",Recalculate from verified original questionnaires.,NOT_PROVIDED,
SYN-0095-LEARNER_RETURN_RATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,rate,83.3,percent,§6.3.1 learner return rate；PDF p. 26,15/18*100=83.3; writer packet counts,Recalculate only from verified real source records; do not present as real association result.,NOT_PROVIDED,
SYN-0095-LEARNER_VALID_RATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,rate,93.3,percent,§6.3.1 learner validity rate；PDF p. 26,14/15*100=93.3; writer packet counts,Recalculate only from verified real source records; do not present as real association result.,NOT_PROVIDED,
SYN-0095-CUSTOMER_RETURN_RATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,rate,83.3,percent,§6.3.2 customer return rate；PDF p. 26,5/6*100=83.3; writer packet counts,Recalculate only from verified real source records; do not present as real association result.,NOT_PROVIDED,
SYN-0095-CUSTOMER_VALID_RATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,rate,100.0,percent,§6.3.2 customer validity rate；PDF p. 26,5/5*100=100.0; writer packet counts,Recalculate only from verified real source records; do not present as real association result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_PRE_SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,51,score points,§6.4.1；PDF p. 29,sum 12 displayed pre scores,Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_PRE_MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,4.25,score / 10,§6.4.1；PDF p. 29,"51/12, rounded to 2 decimals",Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_POST_SUM,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,85,score points,§6.4.1；PDF p. 29,sum 12 displayed post scores,Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_POST_MEAN,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,7.08,score / 10,§6.4.1；PDF p. 29,"85/12, rounded to 2 decimals",Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_ABS_CHANGE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,2.83,score points,§6.4.1；PDF p. 29,"(85-51)/12, rounded to 2 decimals",Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_REL_CHANGE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,66.7,percent,§6.4.1；PDF p. 29,"(85-51)/51*100, descriptive only",Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_PASS_COUNT,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,9,persons,§6.4.1；PDF p. 29,count displayed post scores >=7,Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-FOLLOWUP_PASS_RATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,followup_metric,75.0,percent,§6.4.1；PDF p. 29,9/12*100,Recalculate from verified paired records and authorized rubric; not a causal or REAL result.,NOT_PROVIDED,
SYN-0095-CUSTOMER_VALID_RETURN_SHARE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,DERIVED_SYNTHETIC_METRIC,rate,83.3,percent,§6.3.2 / valid target-customer returns as share of delivered invitations；PDF p. 27,5 valid returned forms / 6 invitations delivered or handed over * 100 = 83.3%; traces to SYN-0095-CUSTOMER_VALID and SYN-0095-CUSTOMER_INVITED.,Recalculate from verified delivered-invitation logs and the returned/valid-form ledger; keep delivered invitations distinct from dispatch-only counts.,NOT_PROVIDED,"SAMPLE/SYNTHETIC only; derivable from the displayed case, separately keyed for full replacement coverage."
UNK-0095-UNK_AUTHOR_REVIEWER_IDENTITY,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,real author and formal reviewer name/role not provided,status,"§9.5 REAL-promotion index row 1; §10.2 author/reviewer statement；PDF pp. 38, 44",Explicitly marked UNKNOWN in candidate narrative.,Replace only with an authorized record naming the author and the formal reviewer and their roles; do not infer identity from tool or route output.,NOT_PROVIDED,Not an invented value; listed to prevent inference. PROP-0095-ROLE-CRD/COL/ANL/DEC are candidate role labels only and do not name any person.
UNK-0095-UNK_APPROVAL_SIGNATURE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,approval and signature originals not provided,status,"§9.5 REAL-promotion index row 2; §8.1 不得升格 REAL row；PDF pp. 34, 38",Explicitly marked UNKNOWN in candidate narrative.,Replace only with the approver's original approval/signature document or an authorized meeting resolution; never fabricate approval or signature.,NOT_PROVIDED,Related key UNK-0095-UNK_REAL_SYSTEM records that no adopted or approved system is evidenced; the approval originals remain separately unprovided.
UNK-0095-UNK_FORMAL_EFFECTIVE_DATE,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,formal and effective dates not provided,status,"§4.1 Tool-A blank REAL date fields; §4.2 Tool-B blank REAL date fields; §9.5 row 3；PDF pp. 11, 15, 38",Explicitly marked UNKNOWN in candidate narrative; the §4.2 real date fields are left blank.,Replace with dated originals for the approval/effective date and for real survey administration/response/return dates.,NOT_PROVIDED,SYN-0095-COURSE_DATE and SYN-0095-FOLLOWUP_DATE are SAMPLE/SYNTHETIC dates and are not formal or real dates.
UNK-0095-UNK_REAL_COURSE_COHORT,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,real class/course/cohort roster and identifier not provided,status,"§9.5 REAL-promotion index row 4; §6 opening case description；PDF pp. 22, 38",Explicitly marked UNKNOWN in candidate narrative.,"Replace with a verified course plan, training roster and class/cohort identifier issued by an authorized source.",NOT_PROVIDED,SYN-0095-CASE_ID; SYN-0095-COURSE_NAME and SYN-0095-COURSE_HOURS are synthetic placeholders only.
UNK-0095-UNK_IMPROVEMENT_ORIGINALS,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,improvement decision/responsibility/deadline/follow-up originals not provided,status,"§8.5 tracking table responsibility/person/deadline/status fields; §9.5 row 7；PDF pp. 36–38, 40",Explicitly marked UNKNOWN in candidate narrative; the §8.5 fields are left blank or marked awaiting authorized designation.,Replace with the authorized decision original; the designated responsible function/person; the approved deadline and comparable follow-up data.,NOT_PROVIDED,No person/assignment/deadline/adoption is asserted; §8.5 keeps every such field UNKNOWN or awaiting authorized designation.
UNK-0095-UNK_ATTACHMENT_STORAGE_LOCATION,0095,I18-E02,建立目標客戶及學員滿意度調查機制（系統及流程面）。,UNKNOWN_NOT_PROVIDED,missing_real_source,real attachments and authorized storage/access path not provided,status,"§8.3; §9.5 row 8; §10.1 attachment index；PDF pp. 34–35, 40–42",Explicitly marked UNKNOWN in candidate narrative.,Replace with the storage path; access permissions; retrieval log and retention rules confirmed by the responsible data manager.,NOT_PROVIDED,§10.1 names R07 package artifacts only and does not assert a real archive location; no path is invented.
```
