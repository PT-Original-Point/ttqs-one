work_id: TTQS_ONE_0030_I06-E01_W1_INDEPENDENT_SEMANTIC_REVIEW_R05_ICEMAN_20261117
doc_id: 0030
requirement_id: I06-E01
reviewer_role: independent semantic/usability reviewer; fresh OpenCode plan context
candidate_file: 0030_I06-E01_R05.docx
candidate_sha256: e2531031233f137e4d222aca2da753c735a81314b77a2ab432cf176c89b11a27
ordered_body_sha256: 1cfe4f99a0f985b2bfa1f1cd8eccb7d789b959e21395122d247ed65434261448
ordered_body_han_count: 5319; exact requirement 5000-7000
requested_model: opencode/iceman-free
served_model: UNKNOWN unless CLI evidence states otherwise
base_candidate_sha256: c1bde91c1bb92407fd631a0692c6d2cab8a997f591a4cc8a4251ab73783e4a72
scope: official requirement fit, field/exception mechanics, new supplement safety and usefulness, 15 fixed synthetic keys/replacement register, SAMPLE/REAL boundary, negative neighbors 0029 I05-E03 and 0031 I06-E02; visual QA is separate.