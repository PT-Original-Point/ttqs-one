# W1 WORK PACKET｜0030｜I06-E01

work_id: `TTQS_ONE_0030_I06-E01_W1_WRITER_R01_20261117`  
doc_id: `0030`  
requirement_id: `I06-E01`  
role: Writer (W1 OpenCode v2 text only; use permitted free route)

## 權威來源與雜湊
- 官方 PDF SHA-256：`805386b77df045b396fabafed7a47d12491c25a0b5744edd9a04876caee34709`；官方佐證列位於第 2 頁，全文見 `OFFICIAL_SOURCE_PAGE2.txt`。
- Crosswalk SHA-256：`1ddfbb608bcad25170683ddb42a1dbb27bafa6f1f35ff0498f1b8d75b24f0679`；I06-E01 列 canonical SHA-256：`11fd13dd07099282e80f10b0171abc6b41c1e24de14e73dcdda685c580a79ed7`。
- Blueprint SHA-256：`406d0495365d0970dcf8113a42842663b8a54372a4e204cc492b7c3f8156ef3e`；0030 原始 JSON 第 30 列 SHA-256：`5887affbbdbb86e6fb5f45310d3d3b7119f924e78fbb288d7a9ed49ab2335bc4`。
- 精確 crosswalk 列：`{"deliverable_count":"1","deliverable_ids":"0030","document_titles":"工作經驗的相關受訓證明_可直接使用成品","requirement_id":"I06-E01","split_extra_count":"0"}`
- 精確 Blueprint 列：`{"deliverable_id":"0030","requirement_id":"I06-E01","final_filename":"0030__工作經驗的相關受訓證明_可直接使用成品.docx","document_genre":"專屬佐證紀錄｜工作經驗的相關受訓證明_可直接使用成品","document_purpose":"本件專屬焦點：工作經驗的相關受訓證明_可直接使用成品；需直接回應的官方佐證要求為：工作經驗的相關受訓證明。；產出一份可實際執行、可閱讀並可追溯的專屬成品；本分件職責與同要求其他分件清楚分開。","primary_user_or_reader":"供執行人員、主管與評核閱讀者追溯要求、事實、證據位置及覆核狀態。","evidence_role":"保存此項要求專屬的原始紀錄或證據索引；不代替第三方原件。 本文件只擁有 I06-E01 的直接紀錄／分析口徑；不得吞併其他要求的事實。","source_of_truth":"官方查核佐證表精確原文『工作經驗的相關受訓證明。』，表內頁次 2，讀取狀態 PDF_TEXT_EXACT_PAGE_MATCH；REQ_157_MAP 對應 I06-E01；本行文件名稱與 ID 以 R04 142 交付 crosswalk/seed 為準。Phase2 歷史 Blueprint 僅作需求拆解參考，絕非可複製正文或現行標題權威。","required_sections":"紀錄目的、責任及適用界線；官方要求拆解與證明路徑；來源、形成時點及納入規則；欄位定義及證據位置；完整合成紀錄示例；核對、計算與一致性判定；例外、缺證及更正軌跡；真實原件與合成示例的區別；覆核、保管及調閱規則；相關要求及文件交叉引用；真實資料替換清單；附件索引與版本","required_tables_or_figures":"欄位—定義—來源—填寫者—驗證規則；完整合成填寫列及欄位解說；問題／例外—修正—覆核及追蹤；官方要求—表單欄位—附件定位追溯表","required_fields_or_questions":"合成資料識別碼；日期欄位及合成標示；責任角色代碼；來源／附件位置欄位；判定、理由、覆核及後續行動","required_calculations_or_analysis":"若此表單有數量、金額、期間或比例，明列定義、分子分母與逐步算例；若沒有，明示不適用並提供至少一個欄位驗證／完整度判斷示例。","required_cross_references":"同要求分件 無；相鄰要求 I05-E03, I06-E02；共用原始來源時只引用核實結果，不複製別份文件正文。","real_data_required":"升格為 REAL 前逐項取得可核實來源：正式日期；真實人名/角色；核准/簽章；真實班次/課程；實際數字/比例；真實附件與檔案位置；第三方出具者；原件編號/日期；可回查聯絡/查證方式。在無原件時標示 SAMPLE/SYNTHETIC；合成事實須登錄 replacement register，不得宣稱機構實績。","third_party_evidence_required":"若結論依賴外部機關／第三方／真人正式簽章或證書，必須由合法來源取得可核對原件；本文件可提供清楚索引與合成流程示範，絕不代製、仿簽、補作或冒充第三方正式原件。","prohibited_fabrication":"不得把擬真工作稿標成REAL；不得偽造核准、簽章、真人參與、辦訓、成績、成果或不存在的外部事實。 不得代替第三方/政府/雇主/媒體/保險或證照機構製造「已出具」原件。；不得將舊檔內容、示範數據、未查證Drive候選或歷史草案標成 REAL；不得偽造核准、簽章、真人參與、辦訓、成績、成果、外部證據或來源定位。","title_blind_test":"遮蔽本件標題、檔名與編號，只讀正文應可由專屬機制辨認為『工作經驗的相關受訓證明_可直接使用成品』並證明『工作經驗的相關受訓證明。』；若可無修改移作其他要求即失敗。","negative_choice_neighbors":"0029《訓練規劃及達到客戶課程績效目標的證明資料_可直接使用成品》（I05-E03）：應證明不同工作物；本件不得代替、合併或複製其專屬事實。\n0031《專業訓練人員職能評估方法等證明_可直接使用成品》（I06-E02）：應證明不同工作物；本件不得代替、合併或複製其專屬事實。","acceptance_tests":"移除標題及檔名後，讀者可由正文專屬欄位、操作或分析辨認為『工作經驗的相關受訓證明_可直接使用成品』，且能指出直接回應『工作經驗的相關受訓證明。』的頁節／表格。\n逐項呈現官方要求、資料來源、記錄欄位、判定、證據定位及覆核；官方原文不被歷史草案改寫。\n依本文件文類實際可用：問卷含題目選項量尺；SOP含角色、輸入、判斷、控制點、異常和輸出；會議紀錄含議題、證據、決議、責任、期限；報告含資料、分母、公式、逐步計算、限制和決策。\n若沒有可驗證 REAL 資料，提供前後一致、完整填入的 SAMPLE/SYNTHETIC 案例；不得用空表、待填、待核或未來式充當完成品。\n每一項合成日期、角色、數字、比例、金額、決議、來源路徑與結果皆有逐事實替換簿記錄鍵、所在文件／頁表／欄位及真實替換方式。\n絕不偽造第三方原件、真人簽名、核准、出席、證書、政府、銀行、會計或外部機構事實；需要該等原件時只說明所需原件與取得路徑。\n所有公式可由展示數據重算；分母、單位、期間、四捨五入及N/A條件清楚，交叉引用不重複創造相異版本。\n對照負向鄰項，正文可拒絕至少兩個錯誤近鄰；指出可核對的差異欄位或章節。\n首頁30秒內說明目的、讀者、使用時點、操作、輸出和SAMPLE／REAL狀態；無評核工程內部術語。\n正文可供日常協會作業及評核閱讀；標題層級、欄位、步驟、表格能直接執行，無複製同儕 DOCX 正文。\n字體下限：正文至少10.5pt、表格至少9.5pt；資訊不足時加頁，不縮小字體。\n來源定位與交叉引用使用本 Blueprint 登錄的官方頁次／文件 ID；所有結論不超出來源支持範圍。","document_role":"evidence_record","official_requirement_text":"工作經驗的相關受訓證明。","official_checkbox_text":"工作經驗的相關受訓證明。","official_evidence_table_page":"2","official_source_readback_status":"PDF_TEXT_EXACT_PAGE_MATCH","official_visually_checked_pages":"","requirement_deliverable_siblings":"0030","docx_body_template_policy":"FROM_SOURCE_ONLY; old body is discovery evidence only and prohibited as rebuild template; Wave005 R3 0031-0040 quality-height references only; Wave001-004 tainted; old Wave005 invalid; Wave006 prohibited.","synthetic_population_rule":"缺 REAL 即生成完整連貫 SAMPLE/SYNTHETIC worked example；事實粒度一筆一列登錄 SYNTHETIC_REPLACEMENT_REGISTER，含值、類型、定位、替換原件與責任；不得留待填或冒充 REAL。","historical_blueprint_source":"d479a544b7cdf423220463223061423f9c4470a745c88d99d97a006e5ddb0d78","historical_body_use":"PROHIBITED","source_map_notes":"129 exact official requirement rows + reconciled 142-ID crosswalk; official source PDF and exact Drive readback evidence are recorded in runtime SOURCE/CONTROL maps."}`

## 任務
只輸出完整繁體中文 Markdown 正文，文類為「工作經驗的相關受訓證明」專屬佐證紀錄；官方原文必須精確呈現為：`工作經驗的相關受訓證明。`。文件要說明來源、範圍、工作經驗與受訓內容的關聯、證據索引、核對方法、例外/缺證紀錄及真實替換方式。

## SAMPLE 防偽界線
本例是完整的流程示例，不是虛構第三方證明。固定事實只用 `FIXED_SYNTHETIC_FACTS_0030.json`。每次呈現合成標籤、人物/課程指稱、技能關聯、證據定位或處置結果，緊鄰列出對應的 `SYN-0030-001` 至 `SYN-0030-015`。文末登錄表剛好 15 列，含 key、示例值、類型、定位、真實替換原件及 REAL 狀態 UNKNOWN。

不得虛構雇主名稱、工作起迄日、年資、職稱證明、證書號、簽章、雇主回覆、出席/訓練紀錄或主管核定。工作期間及雇主身份標 UNKNOWN。示例定位只是說明應存放何種原件，不代表附件真的存在。樣本核驗結果必須為 NOT_VERIFIED；不可把示例升格為真實經歷或資格判定。

## 必備章節
1. 紀錄目的、責任角色與適用界線；此件只對應 I06-E01。
2. 官方要求拆解與證明路徑；說明自述、原始任職證明、工作內容/職務說明與課程範圍如何逐項交叉核對。
3. 來源、形成時點及納入規則；說明原件來源、版本、定位、核驗狀態及更正軌跡欄位。不得創造固定保存年限或法律規則。
4. 欄位定義、證據位置和完整合成紀錄示例；對應三項可追溯的工作任務—受訓內容關聯。
5. 核對、計算與一致性判定；沒有真實日期/原件即不計年資、不判定合格。
6. 例外、缺證、更正軌跡及覆核步驟；用完成的示例狀態呈現「缺原件、未驗證、未作真實認定」及如何解除。
7. 真實原件與合成示例的區別；保管/調閱遵循機構實際現行管制政策，若未提供則標 UNKNOWN。
8. 交叉引用 I06-E01 only，列附件索引及版本用途。
9. 文末 15 列 SAMPLE 替換清冊。

## 長度/輸出
正文 5,000-7,000 個中文字，完整可操作但不冗長；正文樣本值全部由固定鍵支援；標題與頁首明示 SAMPLE/SYNTHETIC。不要引用未提供的法規、政策或機構事實。不要複製其他文件正文。只輸出 Markdown 正文，不呼叫工具或命令。
