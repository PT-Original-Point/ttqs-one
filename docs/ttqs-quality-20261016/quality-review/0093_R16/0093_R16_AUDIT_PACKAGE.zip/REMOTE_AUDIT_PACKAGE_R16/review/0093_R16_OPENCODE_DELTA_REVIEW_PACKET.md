# 0093 R16 exact-SHA delta review

Independent reviewer: inspect only the small R15→R16 delta and issue a verdict bound to the final exact candidate. Do not edit files or use tools. The full unchanged semantic body was reviewed in R15; this delta review must not pretend to repeat that full review.

Project TTQS_ONE; DOCX 0093; official requirement I17D-E07; final candidate SHA-256 `d12b256f2a0162749ff685235e90665a0d440a0f4c6365da00fbbe1c479707e5` (79800 bytes); source SHA `65507d4d412713304a0214a9073953620218da3a1a341ae5815a337f544d8b6f`; Word PDF SHA `9d46f524f68d73a5b21a199328c8ae99c03e5e9b548c802394e75bab5a5eec54`; static QA `a420f4a49b3b484d2aa731452f5edd8e69053bfea76a9aa5876f4adcd50cb3a5` `PASS`; layout receipt SHA `c9e4c8cbd6fdbc66a0de993eca7974ac1ba64fc2f8f8bb2786d81b6f62bcc5dc`. The R16 Word export has 34 pages; image-level comparison to R15 showed only pages 7 and 34 changed; both were visually inspected at full resolution. No formal acceptance is claimed.

R15 exact-SHA reviewer response (reviewed SHA `faafe2dc117cacaabd7d9dde5b71adec7efd6eb55d1a32efe924e0ed781f3b5b`) is the prior independent baseline, response file SHA `ccfd8ee5c2521cf5279a0485659077475705902bed633455b749a1aaebaf8e1c`. It returned PASS, fixed N1–N12, recalculated arithmetic and dates, and noted three minor items. Its full raw CLI response follows as historical evidence.
```text
{"type":"step_start","timestamp":1792477980244,"sessionID":"ses_ea7fcadf9ffeui0oP09Ofjc414","part":{"id":"prt_158036654001U69NOFgNKVMuAx","sessionID":"ses_ea7fcadf9ffeui0oP09Ofjc414","messageID":"msg_158035243001Kal1fYaNnxQPvw","type":"step-start"}}
{"type":"text","timestamp":1792478138299,"sessionID":"ses_ea7fcadf9ffeui0oP09Ofjc414","part":{"id":"prt_158035243001Kal1fYaNnxQPvw_text-0","sessionID":"ses_ea7fcadf9ffeui0oP09Ofjc414","messageID":"msg_158035243001Kal1fYaNnxQPvw","type":"text","text":"VERDICT: PASS\n\nReview bound to candidate DOCX SHA-256 `faafe2dc117cacaabd7d9dde5b71adec7efd6eb55d1a32efe924e0ed781f3b5b` (79799 bytes, 34-page Word-export PDF, sample/CANDIDATE). All statements below concern only that exact SHA. Evidence basis: the packet's complete page-numbered PDF text; the visual receipt is treated as context only — no visual or font-size inspection is inferred or claimed.\n\n## Prior findings N1–N12 (re-adjudicated)\n\n| ID | Status | Locator in candidate |\n|---|---|---|\n| N1 core Q1–Q5 mandatory rule empty stub | Fixed | §5.2, pp. 11–12, items 1–4 (Q0 gate; Q1 authorization/calculation; Q1–Q5 blank-count rule \"空白達 2 題…不完整資料\"; Q6/Q7 rules) |\n| N2 trainee code missing/mismatch → HOLD/pre-fill/codebook | Fixed | p. 4 Table 1 row 受訓人員代碼 (預填／缺漏或不符即 HOLD); p. 6 基本觀察背景; p. 3 §2.2-3; p. 19 §8.1 item 2 |\n| N3 who completes schedule/attendance/use fields; authorization constrains respondent | Fixed | p. 7 Q1 工作人員預核欄 (a,b)／受訪者本人 (d)／工作人員計算欄 (c,e,f); p. 8 行政代碼; p. 11 §5.1; p. 12 §6.1-3 |\n| N4 unrounded banding vs display rounding | Fixed | p. 7 Q1 (\"先以未四捨五入的 f 分帶，再…小數一位\"); p. 11 §5.1; p. 30 FACT-37 |\n| N5 HOLD closure and denominators | Fixed | p. 19 §8.1 items 10 + HOLD 結案 paragraph; p. 18 §7.2 identity N_returned=N_valid+N_excluded+N_stopped+N_hold, N_corecomplete ⊂ N_valid; p. 20 \"HOLD 卷不進有效分母\" |\n| N6 Q0 reason-code map | Fixed | p. 7 Q0 (01/02/03/04); p. 15 Table 2 row Q0 否原因代碼 |\n| N7 Q0=2 exclusion regardless of reason | Fixed | p. 2 §2.2-1; p. 7 Q0 note; p. 15 Table 2; p. 19 §8.1-2; p. 34 checklist |\n| N8 Q0=1 with Q1=99-A contradiction | Fixed | p. 12 §5.2-2; p. 19 §8.1 item 7; p. 20 §8.1-3 (\"Q0=1 與 99-A 矛盾…HOLD\") |\n| N9 Q4 only within comparable metric subgroups | Fixed | p. 11 §5.1 (指標、單位、判讀方向、期間窗口相同子群內呈現，不得合併平均); p. 21–22 Table 3 Q4 rows |\n| N10 artifact-only observers | Fixed | p. 2 §2.2-2 (只看成果物 → 本人選 Q0=3 或留白 → HOLD，不得推定); p. 7 Q0 instruction |\n| N11 Table 1 crosswalk/construct mapping | Fixed | pp. 4–5 Table 1 (題目—構面—作答方式—跳題／計算—用途); §3 構面 A–D; p. 32–33 Table 5 traceability |\n| N12 FACT-10/12/35 date references | Fixed | p. 26 FACT-10 (↔FACT-35); p. 27 FACT-12; p. 29 FACT-35 (↔FACT-10); dates internally consistent (see below) |\n\nCarried checks all hold: Q10 collects no contact data and 99 is administrative only (pp. 10, 13 §6.2, p. 17 Table 2); Table 3 contains both Q5 and Q10 paths (pp. 21–22); the 5–8 minute figure is explicitly \"未經真人試測的粗估\" (pp. 1, 13, 23); no fabricated pilot, approval, respondents, signatures, or third-party records (p. 24 §10.2 declares pilot status UNKNOWN).\n\n## New findings (minor only; no new material defect)\n\n1. **Minor — literal escape artifact.** p. 34, 發放前快速確認, 2nd→3rd checkbox: literal `\\n-` appears in the text (\"…缺漏或不符時 HOLD。`\\n`- ☐ Q0 只有本人明確選 2…\"), breaking bullet style. Smallest repair: replace `\\n- ` with a real paragraph break and the same `• ☐` bullet.\n2. **Minor — reason-code wording tension.** p. 7 Q0 option 2 says 原因代碼「擇一」while p. 2 §2.2-1 permits 原因碼「留白」. The exclusion rule itself is unambiguous (\"不論原因碼…或留白\"), so this is wording only. Smallest repair: on p. 7 write 「原因代碼擇一（可留白；不影響 Q0=2 判定）」.\n3. **Minor — Blueprint cross-reference IDs absent from body.** The doc cites 官方佐證資料表第 6 頁 (p. 32 Table 5) but nowhere states 文件編號 0093／需求 I17D-E07, nor neighbor IDs I17D-E06 / I18-E01. Smallest repair: one line in §12 preface logging 0093 / I17D-E07 and the two adjacent requirement IDs.\n\n## Independent recalculations and verifications\n\n- **Q1 recalculation:** a=5 d/wk, b=27, d=18 → c=b÷a=5.4 wk; e=d÷c=18÷5.4=3.3333… d/wk; f=e÷a=d÷b=18÷27=0.666666… = 66.666…%; display 66.7%; unrounded value falls in 60%≤f<100% → band **4**. Matches candidate (p. 7 computation, p. 13–14 demo, p. 16 Table 2, p. 30 FACT-37). Guards a>0, b>0, 0≤d≤b all satisfied; b=0 no-division rule present (pp. 7, 12).\n- **Q0/Q1 logic:** only personal Q0=2 excludes regardless of reason; Q0=3/blank → HOLD (never presumed \"no\"); Q0=1 with 99-A, a≤0, b=0, or d>b → stop and HOLD (pp. 2, 12, 19–20). 99-A/B/C counted separately, excluded from means (pp. 8, 11, 16, 19). No contradiction found.\n- **Dates:** 結訓 2026-08-10 + 30 d = 2026-09-09 ✓; + 66 d = 2026-10-15 ✓ (FACT-11 \"訓後第 66 日\" ✓); pre-baseline 2026-07-13→08-09 ends before 開訓 08-10 ✓; baseline 07-13→08-09 identical across p. 13–14, FACT-29/30 ✓.\n- **Denominators:** 2=1+1+0+0 ✓; 回收率 2÷2=100.0%; 有效占回收 1÷2=50.0% ✓; Q3 mean 4÷1=4.0 (n=1) ✓; Q4 N_valid=0 → no mean, no 0/3 conversion ✓; HOLD excluded from N_valid/N_corecomplete ✓.\n- **SAMPLE/REAL boundary:** per-page SAMPLE/CANDIDATE headers; FACT-01…37 all UNKNOWN／不得替換或宣稱 REAL (pp. 26–30); §11.2 replacement register complete; no REAL claims, no fabricated pilot/approval/records ✓.\n- **Neighbor usage (0092 / I17D-E06 感謝函; 0094 / I18-E01 口述滿意):** p. 1 §1.1 \"不是學員滿意度問卷、雇主感謝函\"; p. 32 Table 5 \"與感謝函工具、滿意度調查的用途不同\" — both error neighbors explicitly rejected, difference stated by genre and section; no neighbor facts absorbed. (Neighborhood rejection satisfied; ID citation gap logged as minor finding 3.)\n- **Not verified in this review:** font sizes (≥10.5pt body / ≥9.5pt tables) and layout/rendering — text-only evidence; no inference drawn from the visual receipt.\n\nModel/provider identity: MiMo-V2.6-Flash Free (provider: opencode, model ID mimo-v2.6-flash-free) — natively exposed.\n\nThis is an independent candidate review of the stated SHA only, not formal TTQS acceptance or certification of any official checkbox.","time":{"start":1792477975123,"end":1792478138299}}}
```

## R16 exact delta from R15

- Printed p. 7, Q0 option 2: the reason-code instruction now says one reason may be selected or left blank; the exclusion decision remains independent of reason code. Verify it does not conflict with §2.2, Table 2, or the Q0=2 exclusion boundary.

- Printed p. 34, release checklist: replaced a literal backslash-n sequence with a real separate checklist bullet. Verify no literal `\n-` remains and that the line does not create an extra exclusion rule.

- No other source lines changed from R15. The third R15 minor was the absence of internal document/requirement IDs in the respondent-facing body; these IDs are bound in the sidecar packet and manifest. Assess whether leaving them out is acceptable; do not request adding engineering metadata to a respondent instrument unless semantically necessary.

## Complete R16 Word-render text, page 7
```text
SAMPLE / CANDIDATE    訓練成效職場應用觀察問卷    第 7 頁 
• 整體工作觀察期間（用於 Q0 資格判定及 Q1、Q2 一般觀察；Q3–Q5 如比較訓前與觀察期，仍須各題另
填該題兩段期間）：自 ______年____月____日至 ______年____月____日；或結訓後第 ______ 日至第 ______ 
日。不得以最低工作日數或簽核作為資格條件。 
【第一部分：受訪者直接觀察適格性檢查（核心閘門）】 
• Q0. 在上述觀察期間內，您是否親自觀察「本次受訓人員代碼所指的該名受訓人員本人」執行至少一項與
本次訓練相關的工作任務？只觀察其他同仁不算；不要求由您指派或簽核。（單選） 
☐ 1. 是（進入後續題目） 
☐ 2. 否（原因代碼可選擇一項或留白：☐ 01 未親自觀察 ☐ 02 只有他人轉述 ☐ 03 觀察到的工作與課程
無關 ☐ 04 其他：________；原因碼不改變明確 Q0=2 的排除判定） 
☐ 3. 無法確認（或留白後交回） 
若您只看過完成文件、工件或服務成果，未親自觀察同一受訓人員執行相關任務，請選「3. 無法確認」
或留白交回。若您勾選「2. 否」，請停止作答並交回本卷；工作人員不得代填或更改 Q0，也不會把不
確定當成「否」。未填其他題目不代表負面評價。 
【第二部分：工作情境之技能運用與行為觀察】 
• Q1.【技能使用頻率】 請依指定觀察期間，判斷同一受訓人員執行相關任務的技能使用情形。受訪者只填
本人直接觀察到的不同出勤使用日數 d；不得自行查閱任何未授權紀錄。 
工作人員預核欄（僅由確認具相應授權者填寫）： 通常每週排班工作日數 (a)=____日；核實出勤工作日
數 (b)=____日；核准來源代碼、資料範圍與用途／核驗日期：________________。未確認授權或資料不可
核實時不得查閱，亦不填 a/b。 
受訪者本人填寫： 親自觀察到使用所學的不同出勤工作日數 d=____日。觀察不足以判斷 d 時可填「觀
察不足」，由工作人員登錄 99-C；不得估算。 
工作人員計算欄： 經核准的涵蓋工作週當量 (c)=b÷a=____週；每工作週當量平均使用日數 
(e)=d÷c=____日；比例 f=e÷a=d÷b=____%。僅當 a>0、b>0 及 0≤d≤b 時才計算；b=0 不得除法。
先以未四捨五入的 f 分帶，再將百分比呈現至小數一位。若 Q0=1 而 b=0、a≤0、d>b 或欄位矛盾，
停止計算並交回施測承辦人核對，不得自行修正或推算。 
☐ 1. 有相關工作任務及使用機會，但核實出勤工作日中未使用（d=0；f=0） 
☐ 2. 使用比例 0<f<20% 
☐ 3. 使用比例 20%≤f<60% 
☐ 4. 使用比例 60%≤f<100% 
☐ 5. 使用比例 f=100%（每個核實出勤工作日均使用） 
☐ 受訪者直接觀察不足以判斷：交回施測承辦人；工作人員按核准程序登錄99-C。
```

## Complete R16 Word-render text, page 34
```text
SAMPLE / CANDIDATE    訓練成效職場應用觀察問卷    第 34 頁 
發放前快速確認 
• ☐ 課程目標、技能選項與觀察期間已依真實來源核對；示範模組已替換，否則不發放。 
• ☐ 調查用途、受訪者說明、回收管道、資料存取及保存方式已由有權人員確認；未確認即暫停。 
• ☐ 受訓人員代碼依核准來源預填並核對；缺漏或不符時 HOLD。 
• ☐ Q0 只有本人明確選 2 才排除，不論原因；3／空白先 HOLD。 
• ☐ Q6 單元名稱已核實，且逐項核對 Q6 與 Q7a M1–M5 映射；未完成不得發放。 
• ☐ Q1 角色已分開：有授權工作人員核實 a/b，受訪者依直接觀察填 d，工作人員計算 c/e/f 及編碼；以
未四捨五入 f 分帶。 
• ☐ 查閱任何排班／出勤資料前，查閱者授權與用途範圍已確認；未獲授權不得查閱或估算。 
• ☐ 已在經核准的真人試填中記錄實際填答時間並檢討估計；未試填前5 至 8 分鐘僅為未驗證估計，不設
未驗證的時間上限。 
• ☐ Q10 僅在已核准且已告知聯絡安排時施測 1/2；否則跳過，99 只作工作人員行政狀態；不收聯絡資料。 
• ☐ 所有示範內容仍標示 SAMPLE/SYNTHETIC；未核實的真實資料維持 UNKNOWN。 
文件內部分工 
受訪者的「填答完成」文字已置於第四節問卷結尾。本文件其餘章節僅供工作人員核對操作方式與閱讀 
SAMPLE/SYNTHETIC 範例，不提供給受訪者。
```

## Required response (max 500 words)
Return `VERDICT: PASS | PARTIAL | FAIL | BLOCKED`, exact R16 SHA, precise page/section locator, whether each two repaired R15 minor is closed, any regression/new material issue, whether the sidecar ID mapping is sufficient for the respondent-facing form, model/provider only if natively exposed, and explicitly state R16 is still only a candidate. PASS means the R15 semantic PASS carries forward and both deltas are correct; do not claim review of unchanged pages beyond the R15 report.
