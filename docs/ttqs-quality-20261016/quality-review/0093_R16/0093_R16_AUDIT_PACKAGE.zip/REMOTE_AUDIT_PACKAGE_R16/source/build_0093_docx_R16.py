from pathlib import Path
import re
from docx import Document
from docx.enum.section import WD_ORIENT, WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "0093_R16_REVISED_CONTENT.md"
OUT = ROOT / "candidate" / "0093_R16_SYNTHETIC_CANDIDATE.docx"
OUT.parent.mkdir(parents=True, exist_ok=True)
lines = SOURCE.read_text(encoding="utf-8").splitlines()

doc = Document()
doc.core_properties.title = "訓練成效職場應用觀察問卷"
doc.core_properties.subject = "SAMPLE candidate questionnaire for employer and supervisor responses"
doc.core_properties.author = ""
doc.core_properties.keywords = "SAMPLE, SYNTHETIC, TTQS ONE"

BLUE = "234B69"
PALE = "EAF1F6"
ALT = "F5F8FA"
GRID = "B7C6D1"
INK = RGBColor(34, 46, 56)
FONT = "Microsoft JhengHei"

def set_run_font(run, size=None, bold=None, italic=None, color=None, name=FONT):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic
    if color is not None:
        run.font.color.rgb = RGBColor.from_string(color)

def set_cell_shading(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)

def set_cell_margins(cell, top=90, start=105, bottom=90, end=105):
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for m, v in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{m}"))
        if node is None:
            node = OxmlElement(f"w:{m}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(v))
        node.set(qn("w:type"), "dxa")

def set_cell_width(cell, inches):
    cell.width = Inches(inches)
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_w = tc_pr.find(qn("w:tcW"))
    if tc_w is None:
        tc_w = OxmlElement("w:tcW")
        tc_pr.append(tc_w)
    tc_w.set(qn("w:w"), str(int(inches * 1440)))
    tc_w.set(qn("w:type"), "dxa")

def set_repeat_table_header(row):
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)

def prevent_row_split(row):
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)

def set_table_borders(table):
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = "w:" + edge
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "5")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), GRID)

def add_page_field(paragraph):
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = " PAGE "
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = "1"
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    for node in (begin, instr, separate, text, end):
        run._r.append(node)
    set_run_font(run, 8, color="657784")

def set_page(section, landscape=False):
    section.orientation = WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    if landscape:
        section.page_width, section.page_height = Inches(11.69), Inches(8.27)
        section.left_margin = section.right_margin = Inches(0.42)
        section.top_margin = section.bottom_margin = Inches(0.48)
    else:
        section.page_width, section.page_height = Inches(8.27), Inches(11.69)
        section.left_margin = section.right_margin = Inches(0.66)
        section.top_margin, section.bottom_margin = Inches(0.62), Inches(0.58)
    section.header_distance = Inches(0.28)
    section.footer_distance = Inches(0.30)

set_page(doc.sections[0], False)

styles = doc.styles
normal = styles["Normal"]
normal.font.name = FONT
normal._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
normal.font.size = Pt(10.5)
normal.font.color.rgb = INK
normal.paragraph_format.space_after = Pt(5)
normal.paragraph_format.line_spacing = 1.12
for name, size, color in (("Title", 21, BLUE), ("Heading 1", 16, BLUE), ("Heading 2", 13, BLUE), ("Heading 3", 11.5, "355C78"), ("Heading 4", 10.5, "355C78")):
    st = styles[name]
    st.font.name = FONT
    st._element.rPr.rFonts.set(qn("w:eastAsia"), FONT)
    st.font.size = Pt(size)
    st.font.bold = name != "Title" or True
    st.font.color.rgb = RGBColor.from_string(color)
    st.paragraph_format.keep_with_next = True
    st.paragraph_format.space_before = Pt(13 if name != "Title" else 0)
    st.paragraph_format.space_after = Pt(6)
title_style_pr = styles["Title"]._element.pPr
if title_style_pr is not None:
    p_bdr = title_style_pr.find(qn("w:pBdr"))
    if p_bdr is not None:
        title_style_pr.remove(p_bdr)
styles["Title"].font.color.rgb = RGBColor(0, 0, 0)

# A compact, useful footer keeps SAMPLE status visible on every page.
footer = doc.sections[0].footer.paragraphs[0]
footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
footer.paragraph_format.space_before = Pt(0)
footer.paragraph_format.space_after = Pt(0)
r = footer.add_run("SAMPLE / CANDIDATE    訓練成效職場應用觀察問卷    第 ")
set_run_font(r, 8, color="657784")
add_page_field(footer)
r = footer.add_run(" 頁")
set_run_font(r, 8, color="657784")

def clean_inline(text):
    text = text.replace("<br>", "\n").replace("<br/>", "\n")
    text = text.replace("\\frac{N_{returned}}{N_{sent}}", "(N_returned ÷ N_sent)")
    text = text.replace("\\frac{N_{valid}}{N_{returned}}", "(N_valid ÷ N_returned)")
    text = text.replace("\\frac{\\sum X_{Q3}}{N_{Q3\\_valid}}", "(Σ X_Q3 ÷ N_Q3_valid)")
    text = text.replace("\\frac{2}{2}", "(2 ÷ 2)").replace("\\frac{1}{2}", "(1 ÷ 2)").replace("\\frac{4}{1}", "(4 ÷ 1)")
    text = text.replace("\\ge", "≥").replace("\\sum", "Σ").replace("\\_", "_").replace("\\%", "%")
    text = re.sub(r"_\{([A-Za-z0-9]+)\}", r"_\1", text)
    text = text.replace("$", "")
    text = re.sub(r"\[ \]", "☐", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    return text

def add_inline(paragraph, text, default_size=10.5, color=None):
    text = clean_inline(text)
    tokens = re.split(r"(\*\*.*?\*\*|\*[^*]+\*)", text)
    for token in tokens:
        if not token:
            continue
        if token.startswith("**") and token.endswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, default_size, bold=True, color=color)
        elif token.startswith("*") and token.endswith("*"):
            run = paragraph.add_run(token[1:-1])
            set_run_font(run, default_size, italic=True, color=color)
        else:
            parts = token.split("\n")
            for i, part in enumerate(parts):
                if i:
                    paragraph.add_run().add_break()
                if part:
                    run = paragraph.add_run(part)
                    set_run_font(run, default_size, color=color)

def add_text_paragraph(text, style=None, quote=False):
    p = doc.add_paragraph(style=style)
    if quote:
        p.paragraph_format.left_indent = Inches(0.22)
        p.paragraph_format.right_indent = Inches(0.12)
        p.paragraph_format.space_before = Pt(3)
        p.paragraph_format.space_after = Pt(7)
        p_pr = p._p.get_or_add_pPr()
        shd = OxmlElement("w:shd")
        shd.set(qn("w:fill"), "F1F5F8")
        p_pr.append(shd)
    add_inline(p, text, color="485D6A" if quote else None)
    p.paragraph_format.widow_control = True
    return p

def parse_table_row(line):
    return [cell.strip() for cell in line.strip().strip("|").split("|")]

def table_widths(col_count, heading=""):
    if "表一" in heading:
        return [0.75, 1.55, 2.1, 2.15, 4.1]
    if "表二" in heading:
        return [0.95, 1.05, 3.85, 1.55, 1.55, 1.85]
    if "表三" in heading:
        return [2.0, 3.6, 5.15]
    if "表四" in heading:
        return [1.65, 2.15, 4.55, 2.0]
    if "表五點一" in heading:
        return [0.85, 1.35, 4.6]
    if "表五" in heading:
        return [1.55, 2.1, 2.45, 4.65]
    if "10.2" in heading:
        return [1.25, 1.75, 2.85, 3.3, 1.6]
    if col_count == 2:
        return [2.0, 4.8]
    return [10.85 / col_count] * col_count

def add_markdown_table(raw_rows, heading=""):
    rows = []
    for row in raw_rows:
        cells = parse_table_row(row)
        if cells and all(re.fullmatch(r":?-{3,}:?", c.replace(" ", "")) for c in cells):
            continue
        if cells:
            rows.append(cells)
    if not rows:
        return
    cols = max(len(row) for row in rows)
    widths = table_widths(cols, heading)
    if len(widths) != cols:
        widths = [10.85 / cols] * cols
    table = doc.add_table(rows=len(rows), cols=cols)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    set_table_borders(table)
    for ri, cells in enumerate(rows):
        row = table.rows[ri]
        prevent_row_split(row)
        if ri == 0:
            set_repeat_table_header(row)
        for ci in range(cols):
            cell = row.cells[ci]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_width(cell, widths[ci])
            set_cell_margins(cell, top=85 if cols < 6 else 65, bottom=85 if cols < 6 else 65)
            if ri == 0:
                set_cell_shading(cell, BLUE)
            elif ri % 2 == 0:
                set_cell_shading(cell, ALT)
            cell.text = ""
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.line_spacing = 1.05
            p.paragraph_format.widow_control = True
            # Keep each header paragraph chained to the first data row so Word cannot strand a table header at a page bottom.
            if ri == 0:
                p.paragraph_format.keep_with_next = True
            # Table 3 is an eight-row decision matrix. Keep a deliberate, balanced
            # four-and-four split instead of leaving its final row alone on a page.
            if "表三" in heading and ri == 5 and ci == 0:
                p.paragraph_format.page_break_before = True
            add_inline(p, cells[ci] if ci < len(cells) else "", 9.2 if cols >= 4 else 9.6, "FFFFFF" if ri == 0 else None)
            if ri == 0:
                for run in p.runs:
                    run.bold = True

def new_orientation(landscape):
    sec = doc.add_section(WD_SECTION.NEW_PAGE)
    set_page(sec, landscape)

def is_wide_table_heading(line):
    return (line.startswith("### 表一：") or line.startswith("#### 表二：") or
            line.startswith("#### 表三：") or line.startswith("#### 表四：") or
            line.startswith("#### 表五：") or line.startswith("#### 10.2 "))

in_code = False
code_lines = []
quote_lines = []
landscape_active = False
restore_before_next = False
table_caption = ""
i = 0
while i < len(lines):
    raw = lines[i]
    line = raw.strip()
    if restore_before_next and line:
        new_orientation(False)
        landscape_active = False
        restore_before_next = False
    if line.startswith("```"):
        if not in_code:
            in_code = True
            code_lines = []
        else:
            p = doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.16)
            p.paragraph_format.right_indent = Inches(0.08)
            p.paragraph_format.space_before = Pt(3)
            p.paragraph_format.space_after = Pt(7)
            p.paragraph_format.keep_together = True
            pPr = p._p.get_or_add_pPr()
            shd = OxmlElement("w:shd")
            shd.set(qn("w:fill"), "F3F6F8")
            pPr.append(shd)
            for j, item in enumerate(code_lines):
                if j:
                    p.add_run().add_break()
                rr = p.add_run(item)
                set_run_font(rr, 8.5, name="Microsoft JhengHei")
            in_code = False
        i += 1
        continue
    if in_code:
        code_lines.append(raw.rstrip())
        i += 1
        continue
    if not line or line in ("---", "***"):
        i += 1
        continue
    if is_wide_table_heading(line) and not landscape_active:
        new_orientation(True)
        landscape_active = True
    if line.startswith("|"):
        table_rows = []
        while i < len(lines) and lines[i].strip().startswith("|"):
            table_rows.append(lines[i].strip())
            i += 1
        add_markdown_table(table_rows, table_caption)
        if landscape_active:
            restore_before_next = True
        table_caption = ""
        continue
    if line.startswith("# "):
        p = doc.add_paragraph(style="Title")
        add_inline(p, line[2:].strip(), 21, "000000")
        p_pr = p._p.get_or_add_pPr()
        p_bdr = p_pr.find(qn("w:pBdr"))
        if p_bdr is not None:
            p_pr.remove(p_bdr)
        p.paragraph_format.space_after = Pt(9)
        p.paragraph_format.keep_with_next = True
    elif line.startswith("##### "):
        p = doc.add_paragraph(style="Heading 4")
        add_inline(p, line[6:].strip(), 10.5, "355C78")
    elif line.startswith("#### "):
        text = line[5:].strip()
        p = doc.add_paragraph(style="Heading 3")
        add_inline(p, text, 11.5, "355C78")
        if any(x in text for x in ("表二：", "表三：", "表四：", "表五：", "表五點一：", "10.2 ")):
            table_caption = text
    elif line.startswith("### "):
        text = line[4:].strip()
        p = doc.add_paragraph(style="Heading 2")
        add_inline(p, text, 13, BLUE)
        if "表一：" in text:
            table_caption = text
    elif line.startswith("## "):
        p = doc.add_paragraph(style="Heading 1")
        add_inline(p, line[3:].strip(), 16, BLUE)
    elif line.startswith("> "):
        add_text_paragraph(line[2:].strip(), quote=True)
    elif re.match(r"^\d+\.\s+", line):
        match = re.match(r"^(\d+)\.\s+(.*)$", line)
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.28)
        p.paragraph_format.first_line_indent = Inches(-0.28)
        add_inline(p, f"{match.group(1)}. {match.group(2)}")
    elif re.match(r"^[*+-]\s+", line):
        content = re.sub(r"^[*+-]\s+", "", line)
        p = doc.add_paragraph(style="List Bullet")
        add_inline(p, content)
    else:
        p = doc.add_paragraph()
        add_inline(p, line)
        p.paragraph_format.widow_control = True
        if line.startswith("只有存在同一觀察構面或同一品質指標"):
            p.paragraph_format.keep_together = True
        if line.startswith("**【") or line.startswith("**開始前"):
            p.paragraph_format.keep_together = True
    i += 1

if in_code and code_lines:
    p = doc.add_paragraph()
    for j, item in enumerate(code_lines):
        if j:
            p.add_run().add_break()
        rr = p.add_run(item)
        set_run_font(rr, 8.5)

doc.save(OUT)
print(f"DOCX={OUT}")
print(f"BYTES={OUT.stat().st_size}")
