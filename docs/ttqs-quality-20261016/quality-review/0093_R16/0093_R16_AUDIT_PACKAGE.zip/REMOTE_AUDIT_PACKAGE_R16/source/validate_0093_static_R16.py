from pathlib import Path
from zipfile import ZipFile
import hashlib, json, re
from docx import Document

root = Path(__file__).resolve().parent
docx_path = root / "candidate" / "0093_R16_SYNTHETIC_CANDIDATE.docx"
src_path = root / "0093_R16_REVISED_CONTENT.md"
data = docx_path.read_bytes()
doc = Document(docx_path)
parts = [p.text for p in doc.paragraphs]
for table in doc.tables:
    for row in table.rows:
        parts.extend(cell.text for cell in row.cells)
full = "\n".join(parts)
with ZipFile(docx_path) as z:
    bad = z.testzip()
    document_xml = z.read("word/document.xml").decode("utf-8")
    repeat_header_count = document_xml.count('w:tblHeader')
    cant_split_count = document_xml.count('w:cantSplit')
section_specs = []
for sec in doc.sections:
    section_specs.append({"width_twips": sec.page_width.twips, "height_twips": sec.page_height.twips,
                          "orientation": "landscape" if sec.page_width > sec.page_height else "portrait"})
checks = {
    "zip_crc_clean": bad is None,
    "title_present": any(p.style.name == "Title" and p.text.strip() for p in doc.paragraphs),
    "official_quote_absent_from_body": "I17D-E07" not in full and "DOCX 0093" not in full,
    "internal_control_ids_absent": all(x not in full for x in ("Blueprint", "SHA-256", "runtime", "queue", "0092", "0094")),
    "sample_boundary_present": "SAMPLE / CANDIDATE" in "\n".join(p.text for p in doc.sections[0].footer.paragraphs)
        and "SAMPLE/SYNTHETIC" in full,
    "q8_self_report_limitation_present": "不代表資料已核實" in full,
    "q10_no_contact_data": "不收聯絡資料" in full and "99" in full,
    "hold_before_use": "不發放、不收集資料" in full and "HOLD" in full,
    "all_sample_register_facts": all(f"FACT-{i:02d}" in full for i in range(1, 38)),
    "table1_has_five_columns_no_blank_header": len(doc.tables[1]._tbl.tblGrid.gridCol_lst) == 5 and all(c.text.strip() for c in doc.tables[1].rows[0].cells),
    "checklist_no_literal_escape": r"\n- [ ]" not in full,
    "q0_reason_code_may_be_blank": "原因代碼可選擇一項或留白" in full,
    "q0_targets_same_trainee": "受訓人員代碼所指的該名受訓人員本人" in full and "只觀察其他同仁不算" in full,
    "q0_blank_holds": "Q0=3" in full and "3. 無法確認" in full and "暫停待核（HOLD）" in full,
    "respondent_code_and_date_fields": "受訪者代碼" in full and "填答日期" in full,
    "q3_q5_baseline_capture": all(x in full for x in ("比較的工作項目", "比較的工作情境", "訓前觀察期間", "觀察期間")),
    "q4_same_metric_direction_and_values": all(x in full for x in ("指標名稱", "單位", "判讀方向", "訓前值", "觀察期值", "98. 沒有可比的訓前基線", "99. 有基線但資料無法判讀")),
    "q7_related_unit_captured": "Q7a" in full and "相關單元" in full and "M1（對應Q6-A）" in full and "98 跨多單元／無法拆分" in full,
    "q6_q7_choice_rules_present": all(x in full for x in ("Q6單選", "Q7單選", "98表示課程單元清單未提供", "98表示有觀察但證據不足")),
    "q8_observation_only_exclusive": "06與01–05互斥" in full and "不得與01–05並選" in full,
    "training_dates_do_not_overlap_baseline": all(x in full for x in ("開訓及結訓日均為 2026-08-10", "2026-08-09，完全早於開訓日")),
    "respondent_role_and_observation_period_in_dictionary": "受訪者職務類別" in full and "用於Q0資格判定及Q1、Q2一般觀察" in full,
    "consent_and_quote_permission_rules": all(x in full for x in ("C1 參與同意", "C2 資料使用同意", "C3 去識別化文字摘錄", "未作答時，不得摘錄文字")),
    "respondent_form_has_clear_end": "受訪者問卷至此結束" in full and "以下各節僅供工作人員使用" in full,
    "q9_confidence_uses_observation_not_signoff": "持續直接觀察，且能說明多次具體工作事例" in full and "每日密集督導並核簽成果" not in full,
    "q1_opportunity_distinction": "有相關工作任務及使用機會，但核實出勤工作日中未使用" in full and "99-A. 已核實無相關工作機會" in full,
    "synthetic_baselines_are_date_bounded": all(x in full for x in ("2026-07-13", "2026-08-09", "2026-09-09", "2026-10-15")),
    "table_headers_repeated": repeat_header_count >= 5,
    "table_header_rows_keep_with_first_data_row": all(all(cell.paragraphs[0].paragraph_format.keep_with_next is True for cell in table.rows[0].cells) for table in doc.tables if len(table.rows) > 1),
    "rows_marked_no_split": cant_split_count >= 40,
    "expected_landscape_tables": sum(s["orientation"] == "landscape" for s in section_specs) >= 3,
    "sample_math_reconciles": (2 / 2 == 1.0 and 1 / 2 == 0.5 and 4 / 1 == 4.0 and "100.0%" in full and "50.0%" in full and "= 4.0" in full),
    "no_template_tag_placeholders": re.search(r"<[^>]{1,80}>", full) is None,
    "no_old_disposition_or_contact_claims": all(x not in full for x in ("免測之有效排除樣本", "本機構透過獨立管道", "建立後續深度個案訪談之意願名冊")),
    "disposition_categories_complete": all(x in full for x in ("停止（C1或C2不同意）", "不完整資料", "五題完整摘要")),
    "q0_codebook_matches_form_reasons": all(x in full for x in ("只有他人轉述", "觀察到的工作與課程無關", "3. 無法確認")),
    "respondent_form_no_staff_only_directives": all(x not in (full.split("受訪者表單開始",1)[1].split("受訪者問卷至此結束",1)[0] if "受訪者表單開始" in full and "受訪者問卷至此結束" in full else "") for x in ("發放指引", "依第八節", "HOLD")),
    "q1_frequency_bands_are_defined": all(x in full for x in ("0<f<20%", "20%≤f<60%", "60%≤f<100%", "f=100%")),
    "q7_q6e_mapping_m5": "M5（對應Q6-E已填寫且可辨識的其他單元名稱）" in full and "M5=Q6-E填寫且可辨識的其他單元" in full,
    "c3_blank_distinct_from_disagreement": "2=不同意；空白=未表態或未作答（2與空白均不得摘錄）" in full,
    "q0_codebook_covers_hearsay_and_unrelated_work": all(x in full for x in ("只有他人轉述", "觀察到的工作與課程無關", "3. 無法確認")),
    "sim_pre_01_registered_as_fact36": "FACT-36" in full and "SIM-PRE-01" in full,
    "fact20_maps_to_m3": "相關單元M3（對應Q6-C）" in full,
    "fact26_is_scale_label_not_quote": "量尺錨點標籤，不是受訪者自由文字" in full,
    "overall_period_distinct_from_comparison_periods": "Q3–Q5若比較訓前與觀察期，須另填各題專屬的兩段期間" in full,
    "old_editorial_errors_removed": "本次施工" not in full and "資格不符排除（資格不符排除）" not in full,
    "q0_any_explicit_no_is_excluded": "只有受訪者明確勾選Q0=2才列候選資格不符排除" in full and "Q0選「3. 無法確認」或空白" in full,
    "q0_blank_remains_hold": "Q0選「3. 無法確認」或空白" in full and "不得推定為否" in full and "暫停待核（HOLD）" in full,
    "q0_old_narrow_check_removed": "Q0=2，未觀察本次受訓人員本人？" not in full,
    "q1_workweek_equivalent_fields": all(x in full for x in ("通常每週排班工作日數 (a)", "核實出勤工作日數 (b)", "涵蓋工作週當量 (c)=b÷a", "每工作週當量平均使用日數 (e)=d÷c", "f=e÷a=d÷b")),
    "q1_sample_arithmetic_reconciles": all(x in full for x in ("27÷5=5.4", "18÷5.4=3.333...", "18÷27=66.7%", "FACT-37", "60%≤f<100%")),
    "q1_calendar_week_formula_removed": "觀察期間日數÷7為涵蓋週數" not in full,
    "q1_unverified_schedule_routes_to_99": "未獲授權查閱" in full and "99-B" in full and "不得自行查閱未授權紀錄" in full,
    "q7a_multimodule_98_defined": "涉及多個單元且無法單獨區分選98" in full,
    "missing_intake_fields_hold_and_supplement": all(x in full for x in ("觀察期間缺漏", "補件程序", "核實前不逕行排除或納入")),
    "pilot_time_is_unverified": all(x in full for x in ("填答時間5至8分鐘僅為未經真人試測的粗估", "實地記錄實際填答時間並據以修訂", "不得設定未經驗證的硬性時間上限")),
    "module_replacement_checks_q6_q7a_mapping": "核驗Q6選項與Q7a之M1–M5映射" in full,
    "fact37_registered_and_indexed": "FACT-37" in full and "FACT-01至FACT-37" in full and all(f"FACT-{i:02d}" in full for i in range(1, 38)),
    "stale_section_8_2_reference_removed": "第八節 8.1、8.2" not in full,
    "q0_option3_and_blank_hold": "3. 無法確認" in full and "Q0=3或空白" in full and "不得推定為否" in full,
    "q0_only_explicit_no_excludes": "只有受訪者明確勾選Q0=2才列候選資格不符排除" in full,
    "q1_reason_subcodes_distinct": all(x in full for x in ("99-A", "99-B", "99-C", "三者分開計數")),
    "q1_ratio_scale_and_formula": all(x in full for x in ("f=d÷b", "0<f<20%", "20%≤f<60%", "60%≤f<100%", "f=100%")),
    "q1_denominator_and_consistency_hold": all(x in full for x in ("b=0不得除法", "a≤0", "d>b", "列HOLD核查")),
    "q1_no_unauthorized_record_access": all(x in full for x in ("未獲授權不得查閱", "不得自行查閱未授權紀錄", "資料範圍與用途")),
    "q1_codebook_inputs_and_reason_codes": all(x in full for x in ("Q1計算欄 (a)–(f)", "Q1的99原因子碼", "c=b÷a", "e=d÷c", "f=e÷a=d÷b")),
    "q1_respondent_form_has_no_internal_hold": "HOLD" not in (full.split("受訪者表單開始",1)[1].split("受訪者問卷至此結束",1)[0] if "受訪者表單開始" in full and "受訪者問卷至此結束" in full else "MISSING FORM BOUNDARY"),
    "release_checklist_mapping_authority_and_pilot": all(x in full for x in ("Q6與Q7a M1–M5映射", "查閱者授權與用途範圍", "記錄實際填答時間")),
    "sample_normalized_ratio_math": all(x in full for x in ("b=27日", "d=18日", "f=e÷a=d÷b=18÷27=66.7%", "故候選編碼4")),
}
receipt = {
    "artifact": str(docx_path),
    "sha256": hashlib.sha256(data).hexdigest(),
    "bytes": len(data),
    "source_markdown_sha256": hashlib.sha256(src_path.read_bytes()).hexdigest(),
    "paragraphs": len(doc.paragraphs),
    "tables": len(doc.tables),
    "sections": section_specs,
    "repeat_header_elements": repeat_header_count,
    "cant_split_elements": cant_split_count,
    "checks": checks,
    "result": "PASS" if all(checks.values()) else "FAIL",
}
receipt_path = root / "candidate" / "0093_R16_STATIC_QA.json"
receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(receipt, ensure_ascii=False, indent=2))

