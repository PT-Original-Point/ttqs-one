from pathlib import Path
import csv, hashlib, json, sys
from pypdf import PdfReader

root=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME")
out=root/"WORK"/"QUALITY_REBUILD_20261016"/"0141_I19-E31_SOURCE_PREP_R01_20261025"
out.mkdir(parents=True, exist_ok=True)

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_text(name, text):
    p=out/name
    p.write_text(text, encoding="utf-8", newline="")
    return p

official_pdf=root/"INPUTS"/"R04"/"06_OFFICIAL_SOURCES"/"TTQS查核佐證文件資料表-訓練機構版 (2).pdf"
crosswalk=root/"CONTROL"/"TTQS_ONE_129_REQUIREMENT_TO_142_DELIVERABLE_CROSSWALK_R01.csv"
recon=root/"SOURCES"/"REQUIREMENT_SOURCE_RECONCILIATION.csv"
official_full=root/"MASTER"/"ASSESSMENT_SELECTION_20261005"/"official_full_text.txt"
pdf=PdfReader(str(official_pdf))
if len(pdf.pages)!=9:
    raise SystemExit(f"Unexpected official source page count: {len(pdf.pages)}")
page9=pdf.pages[8].extract_text() or ""
write_text("OFFICIAL_SOURCE_PAGE9_EXCERPT.txt",
    "Source: TTQS查核佐證文件資料表-訓練機構版 (2).pdf, physical page 9 of 9.\n"
    "This is extracted text for locator support; consult the cited PDF page for the visual source.\n\n"+page9)

def read_csv(path):
    with open(path,encoding="utf-8-sig",newline="") as f:
        rows=list(csv.DictReader(f))
        fields=list(rows[0].keys()) if rows else []
    return fields,rows

cw_fields,cw_rows=read_csv(crosswalk)
rec_fields,rec_rows=read_csv(recon)
cw=[r for r in cw_rows if r.get("requirement_id")=="I19-E31" or r.get("doc_id")=="0141"]
rr=[r for r in rec_rows if r.get("requirement_id")=="I19-E31" or r.get("doc_id")=="0141"]
if len(cw)!=1 or len(rr)!=1:
    raise SystemExit(f"Expected exactly one mapping row; crosswalk={len(cw)}, recon={len(rr)}")
neighbors=[r for r in cw_rows if r.get("requirement_id") in ("I19-E30","I19-E31","I19-E32")]
write_text("OFFICIAL_REQUIREMENT_ROW_I19-E31.json",json.dumps({
 "requirement_id":"I19-E31","indicator":"19","points":"4分",
 "criterion":"顧客滿意度提升。","source_document_type":"official TTQS scoring evidence-table PDF; physical page 9",
 "source_pdf":str(official_pdf),"source_pdf_sha256":sha(official_pdf),
 "physical_pdf_page":9,"page9_extraction_sha256":hashlib.sha256(page9.encode("utf-8")).hexdigest(),
 "reconciliation_row":rr[0],"reconciliation_csv_sha256":sha(recon)
},ensure_ascii=False,indent=2)+"\n")
write_text("CROSSWALK_ROW_0141_AND_NEIGHBORS.json",json.dumps({
 "crosswalk_csv":str(crosswalk),"crosswalk_csv_sha256":sha(crosswalk),
 "target_row":cw[0],"neighbor_rows_I19_E30_E31_E32":neighbors
},ensure_ascii=False,indent=2)+"\n")
write_text("BLUEPRINT_157_INDEX_153_TO_156_EXCERPT.txt",
 "Current GitHub source: docs/ttqs-quality-20261016/03_157_CHECKBOX_BLUEPRINTS.md\n"
 "Git blob SHA: 8c2bbe7ca9dcbb03088a48934b9e57e7147ede63\n"
 "Lines 367-373 from the current branch copy:\n"
 "153｜高考照/就業率：追蹤分母與時期。必須包含特定來源定位、核心正文/示範、決策或結果、與其他文件的事實連結；第三方原件索取型文件以外不得用空白欄位交差。\n"
 "154｜資訊系統普及率：定義/期間/數據。必須包含特定來源定位、核心正文/示範、決策或結果、與其他文件的事實連結；第三方原件索取型文件以外不得用空白欄位交差。\n"
 "155｜顧客滿意度上升：多期同量尺統計。必須包含特定來源定位、核心正文/示範、決策或結果、與其他文件的事實連結；第三方原件索取型文件以外不得用空白欄位交差。\n"
 "156｜三年營業額增長：真實財報合法核實。必須包含特定來源定位、核心正文/示範、決策或結果、與其他文件的事實連結；第三方原件索取型文件以外不得用空白欄位交差。\n")

items=["Q1需求符合","Q2內容適切","Q3講師教學","Q4教材資源","Q5行政溝通","Q6學習環境","Q7整體滿意"]
base=[
 [3,3,4,3,3,4,3],[3,4,3,3,4,3,3],[4,3,4,3,3,4,4],[3,3,3,4,3,3,3],
 [4,4,3,4,4,3,4],[4,3,4,4,3,4,4],[3,4,3,3,4,3,3],[4,4,4,4,3,4,4],
 [3,3,4,3,4,3,3],[4,3,3,4,3,4,4],[4,3,4,4,4,3,4],[3,4,3,4,4,3,4]
]
rows=[]
months=[1,2,3,4,5,6,7,8,9,10,11,12]
for year in (2023,2024,2025):
    for ri,vec in enumerate(base):
        vals=list(vec)
        if year==2024:
            if ri%2==0: vals[4]+=1
            if ri%3==0: vals[6]+=1
        elif year==2025:
            if ri%4!=1: vals[4]+=1
            if ri%3!=1: vals[6]+=1
            if ri%2==0: vals[1]+=1
        vals=[min(5,v) for v in vals]
        rid=f"SYN-0141-{year}-{ri+1:03d}"
        month=months[ri]
        rows.append({
          "record_state":"SAMPLE_SYNTHETIC","period_year":year,
          "service_cohort_id":f"SYN-COURSE-{year}-01","sample_case_id":rid,
          "response_date_synthetic":f"{year}-{month:02d}-20",
          "customer_segment":"TRAINING_PARTICIPANT_SYNTHETIC",
          "Q1_need_fit":vals[0],"Q2_content_applicability":vals[1],
          "Q3_instructor_support":vals[2],"Q4_materials_resources":vals[3],
          "Q5_admin_communication":vals[4],"Q6_learning_environment":vals[5],
          "Q7_overall_satisfaction":vals[6],
          "Q8_open_comment":"SAMPLE_ONLY; no actual respondent text"
        })
with open(out/"SAMPLE_SURVEY_RESPONSES_0141_R01.csv","w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
with open(out/"SAMPLE_REPLACEMENT_REGISTER_0141_R01.csv","w",encoding="utf-8-sig",newline="") as f:
    w=csv.DictWriter(f,fieldnames=["sample_case_id","field_group","real_source_required","real_source_id","replacement_state"])
    w.writeheader()
    for r in rows:
        w.writerow({"sample_case_id":r["sample_case_id"],"field_group":"customer satisfaction response",
                    "real_source_required":"authorized original survey/export; preserve access control",
                    "real_source_id":"UNKNOWN","replacement_state":"SAMPLE_NOT_REAL"})
summary=[]
for year in (2023,2024,2025):
    yr=[r for r in rows if r["period_year"]==year]
    core=[f"Q{i}_" for i in range(1,7)]
    item_means={}
    for key in ["Q1_need_fit","Q2_content_applicability","Q3_instructor_support","Q4_materials_resources","Q5_admin_communication","Q6_learning_environment","Q7_overall_satisfaction"]:
        item_means[key]=round(sum(int(r[key]) for r in yr)/len(yr),4)
    core_vals=[int(r[k]) for r in yr for k in ["Q1_need_fit","Q2_content_applicability","Q3_instructor_support","Q4_materials_resources","Q5_admin_communication","Q6_learning_environment"]]
    overall=[int(r["Q7_overall_satisfaction"]) for r in yr]
    summary.append({"period_year":year,"SAMPLE_invited_n":15,"SAMPLE_valid_n":12,"SAMPLE_return_rate_pct":80.0,
      "core_item_valid_n":len(core_vals),"six_item_mean_1_to_5":round(sum(core_vals)/len(core_vals),4),
      "overall_Q7_mean_1_to_5":round(sum(overall)/len(overall),4),
      "overall_Q7_top2_n":sum(x>=4 for x in overall),"overall_Q7_top2_pct":round(100*sum(x>=4 for x in overall)/len(overall),2),
      "same_scale":"1-5","all_records":"SAMPLE_SYNTHETIC","item_means":item_means})
with open(out/"SAMPLE_PERIOD_SUMMARY_0141_R01.csv","w",encoding="utf-8-sig",newline="") as f:
    fields=["period_year","SAMPLE_invited_n","SAMPLE_valid_n","SAMPLE_return_rate_pct","core_item_valid_n","six_item_mean_1_to_5","overall_Q7_mean_1_to_5","overall_Q7_top2_n","overall_Q7_top2_pct","same_scale","all_records","item_means"]
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
    for s in summary:
        z=dict(s); z["item_means"]=json.dumps(z["item_means"],ensure_ascii=False,sort_keys=True); w.writerow(z)
def delta(field,a,b): return round(b[field]-a[field],4)
qa={
 "doc_id":"0141","requirement_id":"I19-E31","status":"SOURCE_AND_SAMPLE_READY_FOR_MANUSCRIPT",
 "dataset_rows":len(rows),"unique_case_ids":len({r["sample_case_id"] for r in rows}),
 "periods":[s["period_year"] for s in summary],"valid_scale_values":sorted({v for r in rows for k,v in r.items() if k.startswith("Q") and isinstance(v,int)}),
 "all_records_sample_synthetic":all(r["record_state"]=="SAMPLE_SYNTHETIC" for r in rows),
 "replacement_register_rows":sum(1 for _ in csv.DictReader(open(out/"SAMPLE_REPLACEMENT_REGISTER_0141_R01.csv",encoding="utf-8-sig"))),
 "invited_and_valid_by_period":[[s["period_year"],s["SAMPLE_invited_n"],s["SAMPLE_valid_n"],s["SAMPLE_return_rate_pct"]] for s in summary],
 "six_item_mean_by_period":[[s["period_year"],s["six_item_mean_1_to_5"]] for s in summary],
 "overall_Q7_mean_by_period":[[s["period_year"],s["overall_Q7_mean_1_to_5"]] for s in summary],
 "Q7_top2_by_period":[[s["period_year"],s["overall_Q7_top2_n"],s["overall_Q7_top2_pct"]] for s in summary],
 "mean_change_2025_vs_2023_points":delta("six_item_mean_1_to_5",summary[0],summary[2]),
 "Q7_mean_change_2025_vs_2023_points":delta("overall_Q7_mean_1_to_5",summary[0],summary[2]),
 "no_real_association_data":"All generated rows are SAMPLE/SYNTHETIC. No evidence of real association performance is represented."
}
if len(rows)!=36 or qa["dataset_rows"]!=qa["replacement_register_rows"] or len(qa["unique_case_ids"]) if False else False:
    raise SystemExit("unreachable guard")
if qa["unique_case_ids"]!=36 or not qa["all_records_sample_synthetic"] or qa["valid_scale_values"]!=[3,4,5]:
    raise SystemExit("Sample integrity assertion failed")
if not (summary[0]["six_item_mean_1_to_5"]<summary[1]["six_item_mean_1_to_5"]<summary[2]["six_item_mean_1_to_5"]):
    raise SystemExit("Synthetic six-item trend is not increasing")
if not (summary[0]["overall_Q7_mean_1_to_5"]<summary[1]["overall_Q7_mean_1_to_5"]<summary[2]["overall_Q7_mean_1_to_5"]):
    raise SystemExit("Synthetic Q7 trend is not increasing")
(out/"SAMPLE_DATA_VALIDATION_0141_R01.json").write_text(json.dumps(qa,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")

source_packet="""# 0141 I19-E31 來源包 R01

## 定位與證據層級
- 文件編號：0141。
- 官方具名要求：I19-E31；指標 19「目標市場與顧客價值」；官方評分列記載 4 分權重，這是權重資訊，不是本協會得分。
- 157 方框索引：155。157 索引、I19-E31 requirement ID、文件 0141 是三套不同識別；印刷版 checkbox serial 未由目前資料證明，寫 UNKNOWN。
- 交付文類：顧客滿意度趨勢調查與分析報告。不能用空白問卷或管理辦法替代實際可操作報告。

## 正式來源
- 官方佐證文件資料表（訓練機構版），PDF 實體第 9 頁；正式要求列原文「顧客滿意度提升。」。
- 文件名稱「顧客滿意度趨勢調查與分析報告」取自 129→142 交付 crosswalk 的 I19-E31／0141 列，不是官方 PDF 第 9 頁原文。
- GitHub 目前 03_157_CHECKBOX_BLUEPRINTS.md blob 8c2bbe7ca9dcbb03088a48934b9e57e7147ede63，索引 155：顧客滿意度上升、多期同量尺統計；需特定來源定位、核心正文/示範、決策或結果、與其他文件的事實連結，不可只留空欄位。
- GitHub 目前 02_GENRE_WRITING_MANUAL.md blob 4ff863d9f534b6359fc1c7c1685bd8cce02da886，調查類要求完整題目、抽樣方法、SAMPLE 原始例答、資料清理、統計、限制及用途；比率需明確分母，示例需有 case_id/fact_id。

## 相鄰要求的排除
- 0140 / I19-E30 / 157 索引 154 是資訊系統普及率；不是本文件的顧客滿意度。
- 0142 / I19-E32 / 157 索引 156 是三年營業額增長，涉及真實財報合法核實；不是顧客滿意度。
- 0139 / I19-E29 / 157 索引 153 是考照/就業率，不可拿就業率當滿意度。
- 官方 4 分是評分權重，不能轉述成協會得分或已達成結果。

## 專屬 SAMPLE 基礎
本包的 36 筆年度回覆、15 份邀請/年、12 份有效回覆/年及所有分數都是 SYNTHETIC。示範對象為虛構訓練服務參與者；不代表本協會真實客群、課程、回收率或績效。三期使用相同題目、同一 1–5 量尺和相同分母口徑，以展示趨勢計算。真實作業前須由協會確認顧客定義、實際服務清單、抽樣框和合法取得的原始問卷。不得將學員樣本代表所有委託單位；若委託單位是顧客，須另分層呈現。

## 報告要回答的問題
1. 三個年度如何界定同一項服務及其顧客；三期問卷、量尺、回收窗口是否一致。
2. 邀請、回覆、有效回覆及各題有效 n 的實際分子分母是多少；未回覆及無效件如何處理。
3. 整體滿意與六個服務構面各期變化為何；哪些項目較弱，哪些變化需要查證。
4. 問卷結果支持何種改善假設；哪些是樣本內觀察，哪些因樣本小、構成差異或無對照組而不能作因果結論。
5. 下一輪要採取什麼措施、由哪個建議角色負責、何時回查、用何指標判斷有效；凡未經授權的決定標示「SAMPLE 擬議、尚待核准」。

## 資料與計算口徑
- 回收率 = 有效問卷數 / 已發出邀請數；示例每年 12/15 = 80.00%。不可用有效問卷數除以全體會員、全體學員等未證實母體。
- 六構面均值 = 該構面有效 1–5 分總和 / 該構面有效回答數；不把 Q7 整體題混進六構面合成均值。
- 整體滿意均值另列 Q7；Top-2 比率 = Q7 評分 4 或 5 人數 / Q7 有效回答數。
- 跨年差以量尺點數列示，例如 2025 均值減 2023 均值；不得把 Likert 均值差誤寫成百分比成長。
- N/A 和空白不得計成 0；不臆補；逐題列有效 n。若受訪者少於 5/6 個構面有效答案，不計個人合成值，但仍保留該題可用答案作項目分析。
- 客群混合時先分層；若要彙總，需事先明示固定權重並另外報告各層，不可因樣本組成改變而誤讀為滿意度趨勢。
- 含少樣本的真實結果須遵守協會個資與小樣本揭露規則；本合成示範不包含真實識別資料。

## 問卷核心題目（擬議測量工具，並非官方核定問卷）
量尺：1 非常不滿意、2 不滿意、3 普通、4 滿意、5 非常滿意；另可選「不適用/不知道」，不計入該題分母。
1. 本次訓練服務內容符合我在報名前表達的需求。
2. 課程內容能對應我預計運用的工作、志工或學習情境。
3. 講師的說明、示範與回應有助於我理解課程。
4. 教材與學習資源容易取得，並能支持我完成學習。
5. 報名、課前通知與行政回覆清楚且及時。
6. 學習場地或線上環境與設備適合本次服務。
7. 整體而言，我對本次訓練服務感到滿意。（獨立總體題）
8. 本次最有幫助的是什麼？下一次最希望改善什麼？（開放題，SAMPLE 回答不得冒充真人引言）

## 來源檔及本包產物
以 SOURCE_PREP_RECEIPT_0141_R01.json 的 SHA-256 表為準。正式 PDF 頁面摘錄、交付 crosswalk 原列、需求 reconciliation 原列、157 索引鄰列與合成資料分開保存。
"""

blueprint="""# 0141 I19-E31 專屬 Blueprint R01

## A. 唯一命題與文件用途
本件只處理「顧客滿意度提升」：用相同服務定義、固定問卷核心題、相同 1–5 量尺、可核對的有效分母與多期統計，呈現訓練服務顧客評價的變化，分析限制，並形成下一輪待核准改善建議。它是調查與分析報告，不是評分表、資訊系統使用報告、考照/就業成效報告或營收證明。

## B. 正式對應
- doc_id 0141
- requirement_id I19-E31
- indicator 19, criterion 「顧客滿意度提升。」, weight 4 points (weight only; never claim score)
- 157 blueprint index 155: 「顧客滿意度上升：多期同量尺統計」
- official source locator: training-institution scoring evidence table, physical PDF page 9, criterion 「顧客滿意度提升。」 The 0141 deliverable title comes from the separate 129-to-142 crosswalk row.
- printed checkbox serial: UNKNOWN.
- Neighbor guard: 0139/I19-E29/index153 = licensing/employment; 0140/I19-E30/index154 = information-system uptake; 0142/I19-E32/index156 = revenue. All are different proof constructs.

## C. Intended reader and use
Training administration prepares, fields, cleans and summarizes surveys; responsible officers review customer groups and draft responses; an authorized association role decides whether any proposed change may be adopted. The document must be usable before launch: the questions, scale, timing, invitation denominator, nonresponse treatment, segment fields, analysis formulas, actions, follow-up and hold criteria are visible. Sample decisions are proposals only.

## D. Document structure and required content
1. Cover and status: document identity, report purpose, period, version; label the whole demonstration SAMPLE/SYNTHETIC and REAL evidence UNKNOWN/HOLD.
2. One-page executive finding: exact three-period sample means, response denominator, observed lowest service dimension, interpretation and limits; distinguish sample arithmetic from association performance.
3. Scope and comparability protocol: customer/participant definition, service cohort, sampling frame, invitation unit, response window, eligibility, segment policy, privacy and small-cell controls.
4. Reusable survey administration protocol: dispatch timing, reminder limit, collection channel, coding, invalid/duplicate exclusion, missing/N/A rules, file custody and audit trail.
5. Complete questionnaire: eight exact questions from the source packet, item type, response options, skip/NA handling, respondent segment and service-period metadata. Keep the seven 1–5 items unchanged across periods; Q8 is qualitative and excluded from numeric means.
6. Results: period-level invitation/valid/response counts; six domain-item means and valid n; separate Q7 overall mean and Top-2 rate; customer segment results if supplied; a multi-period table and readable line chart using the same axis. No cross-SHA or cross-construct metrics.
7. Interpretation: compare 2023→2024, 2024→2025 and baseline→final; identify the weakest item, check for scale/response/composition shifts, and state that a small synthetic sample cannot establish causal impact or represent all customers.
8. SAMPLE improvement loop: two hypothetical actions and measurable follow-up, each tied to the observed synthetic item, proposed responsible role, check date/window, success measure and explicit NOT_ADOPTED/NOT_EXECUTED status. Do not describe a proposal as a meeting decision or actual result.
9. Limitations and next-cycle decision table: continue/change/hold choices with explicit evidence required; if valid n, scale, service definition or denominator changed, mark trend not comparable and hold.
10. Appendices: blank reusable capture form plus filled SAMPLE example; data dictionary; 36 response-level SYNTHETIC records; replacement register; formula sheet; source locator and revision record.

## E. Survey protocol and scoring
- Core scale: 1 very dissatisfied, 2 dissatisfied, 3 neutral, 4 satisfied, 5 very satisfied; N/A/not known excluded per item.
- Six domain items are Q1–Q6. Q7 overall satisfaction is separate. Q8 is open text.
- Return rate = valid completed returns / issued invitations. Sample design: 15 invited and 12 valid per year (80%). This is a fictional teaching dataset, not actual sampling.
- Per-item mean = valid response score total / valid answers for that item.
- Six-item index = sum of valid Q1–Q6 scores / number of valid Q1–Q6 answers; only compute respondent-level index when at least 5 of 6 answered. Report item Ns and do not impute.
- Q7 Top-2 = respondents scoring 4 or 5 / valid Q7 answers.
- Trend = later-period value minus earlier-period value on the same five-point scale, reported in points. Do not call it percent improvement. If customer composition, question wording, channel or service changes materially, compare strata only or mark HOLD.
- No causal claim without a verified intervention log and a design supporting attribution.

## F. Canonical synthetic case and item alignment
Canonical SAMPLE fact ID: FACT-SYN-0141-SAT-TREND-R01. Case IDs SYN-0141-YYYY-NNN; 12 complete respondents/year, 3 years; 36 unique IDs; 15 invitations/year; no real personal information. Q5 admin communication is illustrated as improving after a hypothetical notification redesign; Q2 needs/content fit is illustrated as improving after a hypothetical pre-course clarification step; Q7 overall item rises in the sample. These are deliberately synthetic trajectories and cannot support a claim that the association performed either action.
Use the same data file, item wording, scale, period summary and replacement register in the DOCX and its sidecar receipts.

## G. Shared-fact / cross-document boundary
Cross-reference I19-E29/0139, I19-E30/0140, I19-E32/0142 only to distinguish constructs and prevent substitution. Do not reuse their generated narrative, datasets, rates, respondents or claims. Until a verified shared fact source exists, 0141 uses only its own synthetic fact ID and does not assert that the same actual trainees, years, or cohorts appear in adjacent deliverables.

## H. SAMPLE / REAL and authority restrictions
Every generated respondent, date, score, action and narrative is SAMPLE/SYNTHETIC. Real responses require authorized original forms or exports, auditable period and item mapping, protected identity matching, and permission to analyze. Do not invent actual members, instructors, clients, survey returns, approvals, committee decisions, signatures, causal findings, score attainment or formal acceptance. If real data are absent, the example remains complete but visibly synthetic; the real-performance conclusion is UNKNOWN/HOLD.

## I. Exact reject / hold criteria
Reject or hold if: (1) official IDs are conflated; (2) only a blank survey is supplied; (3) periods use different questions/scales without a comparability warning; (4) denominator or valid n is absent; (5) N/A/blank is treated as zero or imputed; (6) Likert point delta is mislabeled as percent growth; (7) nonrespondents disappear without response-rate handling; (8) customer segments are blended despite composition changes; (9) synthetic figures/actions are presented as real; (10) satisfaction is substituted for learning, employment, licensing, revenue or system-use results; (11) a causal claim lacks evidence; (12) no actionable follow-up, owner role, checkpoint or hold rule is provided; (13) no source locator or exact-SHA QA is attached.

## J. Pre-build acceptance gates
- Confirm the official source, row mapping, index 155 and neighbor guard.
- Recompute all sample aggregates from the canonical CSV; response counts and replacement-register IDs must match exactly.
- Confirm exact questionnaire wording, scale and missing-data rules match across manuscript and DOCX.
- Independent semantic reviewer assesses the exact candidate SHA for requirement fit, usefulness, completeness, claims and negative-neighbor distinction.
- Word-native render and all-page visual inspection are separate from semantic review.
- Candidate remains CANDIDATE until exact-SHA independent semantic PASS and any formal Human acceptance; SAMPLE never converts into REAL by formatting.
"""

write_text("SOURCE_PACKET_0141_I19-E31_R01.md",source_packet)
write_text("UNIQUE_BLUEPRINT_0141_I19-E31_R01.md",blueprint)

# Fixed protocol sheet for the author/build lane.
questionnaire="""doc_id,requirement_id,item_id,item_type,question,scale
0141,I19-E31,Q1,LIKERT,本次訓練服務內容符合我在報名前表達的需求,1-5
0141,I19-E31,Q2,LIKERT,課程內容能對應我預計運用的工作志工或學習情境,1-5
0141,I19-E31,Q3,LIKERT,講師的說明示範與回應有助於我理解課程,1-5
0141,I19-E31,Q4,LIKERT,教材與學習資源容易取得並能支持我完成學習,1-5
0141,I19-E31,Q5,LIKERT,報名課前通知與行政回覆清楚且及時,1-5
0141,I19-E31,Q6,LIKERT,學習場地或線上環境與設備適合本次服務,1-5
0141,I19-E31,Q7,LIKERT_OVERALL,整體而言我對本次訓練服務感到滿意,1-5
0141,I19-E31,Q8,OPEN_TEXT,本次最有幫助的是什麼下一次最希望改善什麼,NOT_SCORED
"""
write_text("QUESTIONNAIRE_ITEMS_0141_R01.csv",questionnaire)

action="""action_id,period_transition,basis,proposed_action,owner_role,checkpoint,measure,status
SAMPLE-ACT-0141-01,2023_to_2024,Q5 synthetic baseline,Standardize a pre-course message and provide one contact route,Training administration role,Next comparable survey after 2024,Same Q5 wording and scale with item n and mean,SAMPLE_HYPOTHETICAL_NOT_ADOPTED
SAMPLE-ACT-0141-02,2024_to_2025,Q2 synthetic trend,Add a pre-course needs confirmation and map practice to stated needs,Course coordination role,Next comparable survey after 2025,Same Q2 wording and scale with item n and mean,SAMPLE_HYPOTHETICAL_NOT_ADOPTED
"""
write_text("SAMPLE_ACTION_LOG_0141_R01.csv",action)

# CSV QA and source-prep receipt.
files=[p for p in out.iterdir() if p.is_file() and p.name!="SOURCE_PREP_RECEIPT_0141_R01.json"]
receipt={
 "project_id":"TTQS_ONE","doc_id":"0141","requirement_id":"I19-E31","stage":"READY_SOURCE_PACKET_AND_UNIQUE_BLUEPRINT",
 "candidate_status":"NO_DOCX_YET","sample_real_boundary":"ALL_SAMPLE_SYNTHETIC_REAL_UNKNOWN_HOLD",
 "source":{"official_pdf":str(official_pdf),"official_pdf_sha256":sha(official_pdf),"physical_page_count":len(pdf.pages),
  "reconciliation_csv_sha256":sha(recon),"crosswalk_csv_sha256":sha(crosswalk),
  "github_branch":"work/ttqs-one-document-quality-contract-20261016","github_head_at_preparation":"6992dd35a18e48bb1b55e3da4459021bbb60adb5",
  "blueprint_157_blob_sha":"8c2bbe7ca9dcbb03088a48934b9e57e7147ede63","genre_manual_blob_sha":"4ff863d9f534b6359fc1c7c1685bd8cce02da886"},
 "sample_qa":qa,
 "outputs":[{"name":p.name,"bytes":p.stat().st_size,"sha256":sha(p)} for p in sorted(files,key=lambda p:p.name)]
}
(out/"SOURCE_PREP_RECEIPT_0141_R01.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"out":str(out),"files":len(list(out.iterdir())),"sha256":{p.name:sha(p) for p in sorted(out.iterdir())},"sample_qa":qa},ensure_ascii=False))