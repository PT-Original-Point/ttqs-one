import json,hashlib,subprocess,sys,datetime,os
from pathlib import Path
out=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\R12_20261027\0136_CANDIDATE_R02\review_r05_antigravity_gemini_full")
request=out/"REVIEW_REQUEST_R05.md"
manifest_path=out/"INPUT_MANIFEST_R05.json"
candidate=Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0136_I19-E26_CANDIDATE_R02_20261025\0136_I19-E26_R02_CANDIDATE_20261025.docx")
agy=Path(r"C:\Users\J\AppData\Local\agy\bin\agy.exe")
h=lambda b:hashlib.sha256(b).hexdigest()
def now(): return datetime.datetime.now().astimezone().isoformat()
m=json.loads(manifest_path.read_text(encoding="utf-8"))
packet=request.read_bytes()
cb=candidate.read_bytes()
if h(packet)!=m["request_sha256"]: raise SystemExit("REQUEST_SHA_MISMATCH")
if h(cb)!=m["candidate_sha256"]: raise SystemExit("CANDIDATE_SHA_MISMATCH")
if not agy.exists(): raise SystemExit("AGY_CLI_NOT_FOUND")
if m["requested_model"]!="gemini-3.8-flash-high": raise SystemExit("MODEL_PIN_MISMATCH")
workspace=out/"empty_cli_workspace"
workspace.mkdir(exist_ok=True)
args=[str(agy),"--input-format","stream-json","--output-format","stream-json","--model","gemini-3.8-flash-high","--effort","high","--mode","plan","--sandbox","--disable-slash-commands","--print-timeout","5m"]
message=json.dumps({"event":"user","message":{"content":packet.decode("utf-8-sig")}},ensure_ascii=False,separators=(",",":"))+"\n"
started=now()
(out/"DISPATCH_START_R05.json").write_text(json.dumps({"schema":"TTQS_ONE_ANTIGRAVITY_DISPATCH_START_V1","work_id":m["work_id"],"doc_id":"0136","candidate_sha256":m["candidate_sha256"],"request_sha256":m["request_sha256"],"requested_model":m["requested_model"],"args":args[1:],"start_local":started,"console":"hidden","computer_use":"forbidden","permission_bypass":False},ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
(out/"DISPATCH_STATE_R05.json").write_text(json.dumps({"state":"RUNNING","work_id":m["work_id"],"started_local":started,"candidate_sha256":m["candidate_sha256"]},indent=2)+"\n",encoding="utf-8")
proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=str(workspace),creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
(out/"PID_R05.txt").write_text(str(proc.pid),encoding="ascii")
timed=False
try:
    stdout,stderr=proc.communicate(message.encode("utf-8"),timeout=310)
except subprocess.TimeoutExpired:
    timed=True
    try:
        subprocess.run(["taskkill","/PID",str(proc.pid),"/T","/F"],capture_output=True,timeout=10)
    except Exception:
        proc.kill()
    stdout,stderr=proc.communicate(timeout=15)
ended=now()
(out/"RAW_STDOUT_R05.jsonl").write_bytes(stdout)
(out/"RAW_STDERR_R05.txt").write_bytes(stderr)
events=[]; parse_errors=[]
for n,line in enumerate(stdout.decode("utf-8","replace").splitlines(),1):
    try: events.append(json.loads(line))
    except Exception as e: parse_errors.append({"line":n,"error":str(e),"sample":line[:200]})
init_event=next((e for e in events if e.get("event")=="init"),{})
init_obj=init_event.get("init",{}) if isinstance(init_event.get("init"),dict) else {}
result_event=next((e for e in reversed(events) if e.get("event")=="result"),{})
result=result_event.get("result",{}) if isinstance(result_event.get("result"),dict) else {}
response=result.get("response","")
response_bytes=response.encode("utf-8") if isinstance(response,str) else json.dumps(response,ensure_ascii=False).encode("utf-8")
(out/"RESPONSE_R05.txt").write_bytes(response_bytes)
step_events=[e.get("step_update",{}) for e in events if e.get("event")=="step_update"]
tools=[{"tool_name":s.get("tool_name"),"state":s.get("state"),"step_type":s.get("step_type")} for s in step_events if s.get("step_type")=="tool"]
all_text=json.dumps(events,ensure_ascii=False).lower()
fallback_observed=any(k in all_text for k in ["fallback","model switched","model_switch","fallbackmodel"])
candidate_after=candidate.read_bytes()
receipt={
 "schema":"TTQS_ONE_ANTIGRAVITY_DISPATCH_TERMINAL_V1","project_id":"TTQS_ONE","work_id":m["work_id"],"doc_id":"0136","requirement_id":"I19-E26",
 "worker":"Antigravity CLI","cli_binary":str(agy),"cli_version":"UNKNOWN","requested_model":m["requested_model"],
 "cli_init_model_reported":init_obj.get("model"),"backend_serving_model_identity":"UNKNOWN","fallback_observed":("OBSERVED" if fallback_observed else "UNKNOWN_NOT_EXPOSED"),
 "model_fallback_allowed":False,"pid":proc.pid,"start_local":started,"end_local":ended,"duration_seconds":round((datetime.datetime.fromisoformat(ended)-datetime.datetime.fromisoformat(started)).total_seconds(),3),
 "exit_code":proc.returncode,"timed_out":timed,"terminal_status":result.get("status","NO_TERMINAL_RESULT"),"conversation_id":result.get("conversation_id"),
 "request_sha256":h(packet),"request_bytes":len(packet),"candidate_sha256_before":h(cb),"candidate_sha256_after":h(candidate_after),"candidate_unchanged":h(cb)==h(candidate_after),
 "stdout_bytes":len(stdout),"stdout_sha256":h(stdout),"stderr_bytes":len(stderr),"stderr_sha256":h(stderr),
 "response_bytes":len(response_bytes),"response_sha256":h(response_bytes),"response_received":bool(response_bytes.strip()),
 "usage":result.get("usage","NOT_REPORTED"),"error":result.get("error"),"tool_steps":tools,"computer_use_called":any("computer" in str(t.get("tool_name","")).lower() for t in tools),
 "permissions_bypassed":False,"parse_errors":parse_errors,"auto_retry":"UNKNOWN_NOT_EXPOSED",
 "reviewer_reported_verdict":"NOT_ADJUDICATED","formal_acceptance":"NOT_GRANTED","real_evidence":"UNKNOWN/HOLD"
}
(out/"DISPATCH_TERMINAL_R05.json").write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
(out/"DISPATCH_STATE_R05.json").write_text(json.dumps({"state":"TERMINAL","work_id":m["work_id"],"started_local":started,"ended_local":ended,"pid":proc.pid,"exit_code":proc.returncode,"response_bytes":len(response_bytes)},indent=2)+"\n",encoding="utf-8")
print(json.dumps({k:receipt[k] for k in ["pid","exit_code","duration_seconds","timed_out","cli_init_model_reported","backend_serving_model_identity","fallback_observed","terminal_status","usage","response_bytes","response_sha256","tool_steps","computer_use_called","candidate_unchanged","parse_errors"]},ensure_ascii=False))
