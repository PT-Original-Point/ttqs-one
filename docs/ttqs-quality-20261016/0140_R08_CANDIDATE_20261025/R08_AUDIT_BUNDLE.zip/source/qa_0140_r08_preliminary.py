from pathlib import Path
from docx import Document
import csv, json, hashlib
from decimal import Decimal, ROUND_HALF_UP

root = Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_SOURCE_PREP_R01_20261025")
outdir = root.parent / "0140_I19-E30_CANDIDATE_R08_20261025"
docx_path = outdir / "0140__訓練資訊系統使用普及率盤點與分析表_R08.docx"
manifest_path = outdir / "DOCX_BUILD_RECEIPT_0140_R08.json"
md_path = root / "worker" / "MANUSCRIPT_0140_R08.md"
dataset_path = root / "SYNTHETIC_USER_DATASET_0140_R01.csv"
register_path = root / "SYNTHETIC_REPLACEMENT_REGISTER_0140_R07.csv"
r07_path = root.parent / "0140_I19-E30_CANDIDATE_R07_20261025" / "0140__訓練資訊系統使用普及率盤點與分析表_R07.docx"
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()

build = json.loads(manifest_path.read_text(encoding="utf-8"))
doc = Document(str(docx_path))
paragraphs = [p.text for p in doc.paragraphs]
tables = [[[" ".join(c.text.split()) for c in row.cells] for row in t.rows] for t in doc.tables]
full = "\n".join(paragraphs + ["\n".join(" | ".join(r) for r in t) for t in tables])
checks = {}
def check(name, ok, evidence):
    checks[name] = {"result":"PASS" if ok else "FAIL","evidence":evidence}

doc_sha = sha(docx_path)
check("docx_hash_matches_build_receipt", doc_sha == build["docx_sha256"], {"docx_sha256":doc_sha,"receipt_sha256":build["docx_sha256"]})
check("official_binding", all(x in full for x in ["DOCX 0140","I19-E30","157 項清單索引 154"]), "DOCX 0140 / I19-E30 / index 154; printed checkbox serial UNKNOWN")
check("section_4_heading_keeps_sample_qualifier", "第四部分：年度系統盤點表（SAMPLE 示範）" in paragraphs, "rendered heading text")
check("section_7_heading_keeps_chinese_punctuation", "第七部分：資料整理、隱私與例外處理" in paragraphs, "rendered heading text")
check("section_10_heading_keeps_qualifier", "第十部分：示範改善行動計畫（SAMPLE 提案，尚未核定）" in paragraphs, "rendered heading text")
check("decision_table_explicit_sample_boundary", "5.3 判定示例（SAMPLE / SYNTHETIC）" in paragraphs and "SAMPLE/SYNTHETIC 情境" in full, "heading and first column label")
check("annual_comparison_explicit_sample_years", all(x in full for x in ["2023 年（SAMPLE）","2024 年（SAMPLE）","2025 年（SAMPLE）"]), "8.3 table year headings")
check("completion_rate_denominator_named", "合格應使用者全任務完成率" in full, "cover and 8.3 measure label")
check("association_system_claim_removed_from_disclaimer", "屏東縣原始點關懷協會已實際建置" not in full and "任何特定機構已實際建置、採購或部署該系統" in full, "disclaimer no longer makes association-specific unsupported system claim")
internal_terms = ["exact-SHA","exact SHA reviewer","視覺QA收據","組版與視覺QA","分页","所有页面","reviewer"]
found_internal = [t for t in internal_terms if t.casefold() in full.casefold()]
check("human_facing_checklist_avoids_internal_production_terms", not found_internal, {"found":found_internal})
check("candidate_and_real_state_kept_distinct", "CANDIDATE" in full and "REAL = UNKNOWN / HOLD" in full and "NOT_GRANTED" in full, "candidate; real UNKNOWN/HOLD; formal acceptance NOT_GRANTED")
check("chart_embedded_and_captioned", len(doc.inline_shapes) >= 1 and "合格應使用者全任務完成率" in full, {"inline_shapes":len(doc.inline_shapes),"caption_present":"合格應使用者全任務完成率" in full})
a1 = [t for t in tables if len(t[0]) > 1 and t[0][1] == "SAMPLE user-year ID"]
a2 = [t for t in tables if len(t[0]) > 1 and t[0][1] == "SAMPLE user-year ID" and "已完成必要任務" in t[0][2] if len(t[0]) > 2]
check("two_80_row_appendix_tables", len(a1)==2 and all(len(t)==81 for t in a1), {"matches":len(a1),"row_counts":[len(t) for t in a1]})
# Recompute year rates from the canonical 80-row source, preserving the specified half-up rule.
with dataset_path.open("r",encoding="utf-8-sig",newline="") as f: records=list(csv.DictReader(f))
groups={}
for rec in records:
    y=rec["period_year"]
    g=groups.setdefault(y,{"eligible":0,"active":0,"complete":0})
    g["eligible"] += int(rec["eligible_unique_user"])
    g["active"] += int(rec["active_user"])
    g["complete"] += int(rec["all_required_tasks_complete"])
def pct(n,d):
    return str((Decimal(n)*Decimal(100)/Decimal(d)).quantize(Decimal("0.01"),rounding=ROUND_HALF_UP))+"%"
expected = {
    "2023":["60.00%","45.00%","75.00%"],
    "2024":["78.57%","64.29%","81.82%"],
    "2025":["87.50%","78.13%","89.29%"],
}
observed={}
for y,g in groups.items():
    observed[y]=[pct(g["active"],g["eligible"]),pct(g["complete"],g["eligible"]),pct(g["complete"],g["active"])]
math_ok = len(records)==80 and observed==expected
check("canonical_80_row_rates_recomputed", math_ok, {"rows":len(records),"annual_rates":observed,"expected":expected})
check("replacement_register_reused_unchanged", sha(register_path)=="9a207c162cc36b08896d4f1ad04ccdcfdefa62bd2b038be31dc715702982e19f", {"register_sha256":sha(register_path),"rows":sum(1 for _ in register_path.open(encoding="utf-8-sig"))-1})
check("R07_preserved_unchanged", sha(r07_path)=="7343688549e213f26ab22e58436a8d6915a679b72d75803a3c25566f94829ebe", {"R07_sha256":sha(r07_path)})
result = {
    "doc_id":"0140","requirement_id":"I19-E30","official_checklist_index":154,"printed_checkbox_serial":"UNKNOWN",
    "candidate_revision":"R08","candidate_status":"CANDIDATE","real_data_status":"UNKNOWN/HOLD","formal_acceptance":"NOT_GRANTED",
    "docx_path":str(docx_path),"docx_sha256":doc_sha,"docx_bytes":docx_path.stat().st_size,
    "manuscript_sha256":sha(md_path),"dataset_sha256":sha(dataset_path),"replacement_register_sha256":sha(register_path),
    "source_content_and_calculation_checks":checks,
    "status":"PASS" if all(v["result"]=="PASS" for v in checks.values()) else "FAIL",
    "scope_limitations":["No native Word page render or visual inspection yet; 0141 Word COM render is active and free RAM is limited.",
                         "No independent exact-SHA semantic review of R08 yet.",
                         "Builder and deterministic checks do not constitute formal acceptance."]
}
qa_path=outdir/"R08_PRELIMINARY_CONTENT_QA_0140.json"
qa_path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
print(json.dumps({"qa_path":str(qa_path),"qa_sha256":sha(qa_path),"candidate_sha256":doc_sha,"status":result["status"],"checks":{k:v["result"] for k,v in checks.items()},"scope_limitations":result["scope_limitations"]},ensure_ascii=True,indent=2))
