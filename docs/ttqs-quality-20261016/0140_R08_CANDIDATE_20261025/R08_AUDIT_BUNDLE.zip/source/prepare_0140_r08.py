from pathlib import Path
import json, re, hashlib

root = Path(r"E:\TTQS\TTQS_ONE_CODEX_RUNTIME\WORK\QUALITY_REBUILD_20261016\0140_I19-E30_SOURCE_PREP_R01_20261025")
worker = root / "worker"
source_md = worker / "MANUSCRIPT_0140_R07.md"
source_builder = root / "build_0140_docx_r07.py"
out_md = worker / "MANUSCRIPT_0140_R08.md"
out_builder = root / "build_0140_docx_r08.py"
outdir = root.parent / "0140_I19-E30_CANDIDATE_R08_20261025"
outdocx = outdir / "0140__訓練資訊系統使用普及率盤點與分析表_R08.docx"
if outdir.exists() or outdocx.exists():
    raise FileExistsError(f"Refusing to overwrite R08 path: {outdir}")

md = source_md.read_text(encoding="utf-8")
repls = [
    ("關鍵工作完成率亦由 45.00% 提升至 78.13%", "合格應使用者全任務完成率亦由 45.00% 提升至 78.13%"),
    ("不代表屏東縣原始點關懷協會已實際建置、採購或部屬該特定系統", "不代表任何特定機構已實際建置、採購或部署該系統"),
    ("### 5.3 判定示例（均為 SAMPLE）", "### 5.3 判定示例（SAMPLE / SYNTHETIC）"),
    ("| 情境 | 分母 | 活躍 | 全任務完成 | 判定理由 |", "| SAMPLE/SYNTHETIC 情境 | 分母 | 活躍 | 全任務完成 | 判定理由 |"),
    ("| 指標項目 | 2023 年基準 | 2024 年進展 | 2025 年後期（SAMPLE） |", "| 指標項目 | 2023 年（SAMPLE） | 2024 年（SAMPLE） | 2025 年（SAMPLE） |"),
    ("| **關鍵任務全數完成人數** |", "| **全任務完成人數** |"),
    ("| **全體合格者完成率 (%)** |", "| **合格應使用者全任務完成率 (%)** |"),
    ("| **活躍者中之完成率 (%)** |", "| **實質活躍者全任務完成率 (%)** |"),
    ("SAMPLE 數值已做確定性重算；尚非獨立語意驗收", "示範數值與附錄資料一致；正式使用前須以授權的真實資料重新計算"),
    ("來源列、重算收據、exact SHA reviewer", "原始資料列、重算工作底稿、覆核日期"),
    ("文中已有項目界線；獨立審查待做", "文件已說明範圍界線；真實案件仍需核實共同資料來源鍵"),
    ("字體、分页、所有页面及 exact-SHA review 是否通過？", "頁碼、表格可讀性、附件與另一位覆核者的檢查紀錄是否齊全？"),
    ("由組版與視覺QA收據填寫；本檔不代稱 PASS", "本示範文件尚未完成逐頁檢視與正式核定"),
    ("Word 原生 render、全頁檢查、獨立 exact-SHA 收據", "逐頁檢視紀錄、核定紀錄、附件清單"),
    ("來源與公式經本機逐項核對後，才交獨立 exact-SHA reviewer；本表自身不核定正式評分、不取代 Human 正式接受。", "來源與公式核對後，應由未參與填表的人員再行檢查；本表不核定正式評分，也不取代機構正式接受。"),
    ("### 8.3 三個合成年度之比率變化表", "### 8.3 三個合成年度之比率變化表（SAMPLE / SYNTHETIC）"),
    ("## 第十部分：示範改善行動計畫（尚未核定）", "## 第十部分：示範改善行動計畫（SAMPLE 提案，尚未核定）"),
]
for old, new in repls:
    if old not in md:
        raise ValueError(f"Expected source phrase missing: {old}")
    md = md.replace(old, new, 1)
for token in ["exact-SHA", "exact SHA reviewer", "視覺QA收據", "組版與視覺QA", "分页", "所有页面"]:
    if token in md:
        raise ValueError(f"Internal-production term remains in target manuscript: {token}")
out_md.write_text(md, encoding="utf-8", newline="\n")

builder = source_builder.read_text(encoding="utf-8")
builder_repls = [
    ('OUTDIR = ROOT.parent / "0140_I19-E30_CANDIDATE_R07_20261025"', 'OUTDIR = ROOT.parent / "0140_I19-E30_CANDIDATE_R08_20261025"'),
    ('OUTDOCX = OUTDIR / "0140__訓練資訊系統使用普及率盤點與分析表_R07.docx"', 'OUTDOCX = OUTDIR / "0140__訓練資訊系統使用普及率盤點與分析表_R08.docx"'),
    ('MANUSCRIPT = WORKER / "MANUSCRIPT_0140_R07.md"', 'MANUSCRIPT = WORKER / "MANUSCRIPT_0140_R08.md"'),
    ('CHART = OUTDIR / "SAMPLE_RATE_TREND_0140_R07.png"', 'CHART = OUTDIR / "SAMPLE_RATE_TREND_0140_R08.png"'),
    ('RECEIPT = OUTDIR / "DOCX_BUILD_RECEIPT_0140_R07.json"', 'RECEIPT = OUTDIR / "DOCX_BUILD_RECEIPT_0140_R08.json"'),
    ('def clean_heading(s):\n    s=re.sub(r"（[^）]*）|\\([^)]*\\)","",s)\n    s=re.sub(r"[：:；;，,。！？!?、|/]", " ",s)\n    return re.sub(r"\\s+"," ",s).strip()', 'def clean_heading(s):\n    s=re.sub(r"^#{1,6}\\s*", "", s)\n    s=re.sub(r"[*_\\x60]+", "", s)\n    return re.sub(r"\\s+"," ",s).strip()'),
    ('if heading.startswith("第六部分 SAMPLE 角色與必要任務矩陣"):', 'if heading.startswith("第六部分"):'),
    ('d.text((120, 40), "資訊系統使用普及率與關鍵任務完成率", font=titlef, fill="#172B4D")', 'd.text((120, 40), "資訊系統普及率與合格應使用者全任務完成率", font=titlef, fill="#172B4D")'),
    ('add_inline(p,"圖 1  SAMPLE 普及率與合格者全任務完成率（2023–2025）",10.5,MUTED,True)', 'add_inline(p,"圖 1  SAMPLE 普及率與合格應使用者全任務完成率（2023–2025）",10.5,MUTED,True)'),
    ('"doc_id":"0140","requirement_id":"I19-E30"', '"candidate_revision":"R08","doc_id":"0140","requirement_id":"I19-E30"'),
    ('"Wide tables use landscape pages; 13.1 intake form is split into two readable five-column tables.",', '"Wide tables use landscape pages; 13.1 intake form is split into two readable five-column tables.",\n               "The replacement register is reused unchanged from R07 because the 80-row SAMPLE dataset and mapping are unchanged.",'),
]
for old, new in builder_repls:
    if old not in builder:
        raise ValueError(f"Expected builder phrase missing: {old[:100]}")
    builder = builder.replace(old, new, 1)
out_builder.write_text(builder, encoding="utf-8", newline="\n")

report = {
    "source_manuscript_sha256": hashlib.sha256(source_md.read_bytes()).hexdigest(),
    "source_builder_sha256": hashlib.sha256(source_builder.read_bytes()).hexdigest(),
    "r08_manuscript_sha256": hashlib.sha256(out_md.read_bytes()).hexdigest(),
    "r08_builder_sha256": hashlib.sha256(out_builder.read_bytes()).hexdigest(),
    "register_sha256": hashlib.sha256((root / "SYNTHETIC_REPLACEMENT_REGISTER_0140_R07.csv").read_bytes()).hexdigest(),
    "output_docx": str(outdocx),
    "changed_content_count": len(repls),
}
print(json.dumps(report, ensure_ascii=False, indent=2))
